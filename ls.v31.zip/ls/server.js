const express = require("express");
const cors = require("cors");
const path = require("path");
const dotenv = require("dotenv");
dotenv.config();
const bcrypt = require("bcryptjs");
const { randomUUID } = require("crypto");
const { initDb } = require("./db/init");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const db = initDb();
const MAX_COPY_COUNT_PER_BOOK = 5000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.resolve(__dirname)));

const SEMAPHORE_API_KEY = process.env.SEMAPHORE_API_KEY || "";
const SEMAPHORE_SENDER_NAME = process.env.SEMAPHORE_SENDER_NAME || "GGC Library";
const SMS_ENABLED = process.env.SMS_ENABLED === "true";
const CONTACT_REASONS = [
  "Borrowing concern",
  "Returning books",
  "Account or profile issue",
  "Book availability",
  "Technical problem",
  "General inquiry",
];
const SMS_TEMPLATE_TYPES = new Set([
  "Borrow Confirmation",
  "Due Date Reminder",
  "Overdue Notice",
  "OTP (Account Creation)",
  "OTP (Change Password)",
  "Visitor Account Creation",
  "Account Creation Approval",
  "Reservation Approval",
]);

const otpStore = new Map();
const passwordResetTokens = new Map();
const sessions = new Map();

function splitContactMessage(message) {
  const value = String(message || "");
  const separatorIndex = value.indexOf(": ");
  if (separatorIndex > 0) {
    const reason = value.slice(0, separatorIndex);
    if (CONTACT_REASONS.includes(reason)) {
      return { reason, body: value.slice(separatorIndex + 2) };
    }
  }
  return { reason: "Message", body: value };
}

function normalizePhone(phone) {
  const raw = String(phone || "").trim().replace(/[^\d+]/g, "");
  if (raw.startsWith("+")) return raw;
  if (raw.startsWith("09") && raw.length === 11) return `+63${raw.slice(1)}`;
  if (raw.startsWith("639") && raw.length === 12) return `+${raw}`;
  return raw;
}

function registrationDuplicateFields({ username, email, phone, schoolId, role }) {
  const duplicateFields = {};
  const normalizedUsername = String(username || "").trim().toLowerCase();
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const normalizedPhone = normalizePhone(phone);
  const normalizedSchoolId = String(schoolId || "").trim().replace(/\s+/g, "").toUpperCase();

  if (normalizedUsername && db.prepare("SELECT id FROM users WHERE lower(username) = ? LIMIT 1").get(normalizedUsername)) {
    duplicateFields.username = "Username (the part of your email before @) is already in use. Use a different email address.";
  }
  if (normalizedEmail && db.prepare("SELECT id FROM users WHERE lower(email) = ? LIMIT 1").get(normalizedEmail)) {
    duplicateFields.email = "Email address is already registered.";
  }
  if (normalizedPhone) {
    const existingPhones = db.prepare("SELECT phone FROM users WHERE phone IS NOT NULL").all();
    if (existingPhones.some((user) => normalizePhone(user.phone) === normalizedPhone)) {
      duplicateFields.phone = "Phone number is already registered.";
    }
  }
  if (role !== "visitor" && normalizedSchoolId && db.prepare(
    "SELECT id FROM users WHERE role <> 'visitor' AND school_id IS NOT NULL AND replace(upper(school_id), ' ', '') = ? LIMIT 1",
  ).get(normalizedSchoolId)) {
    duplicateFields.schoolId = "School ID number is already registered.";
  }

  return duplicateFields;
}

function registrationAccountType(userType, role) {
  const value = String(userType || (role === "visitor" ? "Visitor" : "Student")).trim();
  const type = value.toLowerCase();
  if (!["student", "faculty", "teacher", "visitor"].includes(type)) return null;
  return { userType: value, role: type === "visitor" ? "visitor" : "member" };
}

function createOtpCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function renderSmsTemplate(templateType, values) {
  const template = db.prepare("SELECT body FROM sms_templates WHERE template_type = ?").get(templateType);
  if (typeof template?.body !== "string" || !template.body.trim()) {
    throw new Error(`The ${templateType} SMS template is missing or empty.`);
  }
  return Object.entries(values).reduce(
    (body, [placeholder, value]) => body.split(`[${placeholder}]`).join(String(value ?? "")),
    template.body,
  );
}

async function sendSms(to, body) {
  if (!SMS_ENABLED) return { mock: true, sid: "mock-sid" };
  if (!SEMAPHORE_API_KEY) {
    throw new Error("Semaphore API key is missing.");
  }

  const response = await fetch("https://api.semaphore.co/api/v4/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      apikey: SEMAPHORE_API_KEY,
      number: to,
      message: body,
      sendername: SEMAPHORE_SENDER_NAME,
    }),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = result.message || result.error || `Semaphore request failed (${response.status})`;
    throw new Error(detail);
  }
  return { mock: false, sid: result.message_id || result.id || null };
}

function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    email: row.email,
    name: row.name,
    phone: row.phone,
    schoolId: row.school_id,
    userType: String(row.user_type || "").toLowerCase() === "staff" ? "Library Staff" : row.user_type,
    course: row.course,
    role: row.role,
    status: row.status,
    freshAccount: Number(row.fresh_account) === 1,
    createdAt: row.created_at || null,
  };
}

function requireSession(req, res) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  const session = token ? sessions.get(token) : null;
  if (!session) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return session;
}

function addDaysMMDDYYYY(days) {
  if (!isValidDurationDays(days)) {
    throw new Error("Returning duration must result in a supported due date.");
  }
  const d = new Date();
  d.setDate(d.getDate() + days);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${mm}/${dd}/${d.getFullYear()}`;
}

function isValidDurationDays(days) {
  if (!Number.isSafeInteger(days) || days < 1) return false;
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + days);
  return !Number.isNaN(dueDate.getTime()) && dueDate.getFullYear() <= 9999;
}

function todayMMDDYYYY() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${mm}/${dd}/${d.getFullYear()}`;
}

function activityUserType(user) {
  if (user.role === "librarian") return "Librarian";
  if (user.role === "staff") return "Library Staff";
  if (user.role === "visitor") return "Visitor";

  const userType = String(user.user_type || "").trim().toLowerCase();
  if (userType === "teacher" || userType === "faculty") return "Faculty";
  if (userType === "staff") return "Library Staff";
  if (userType === "student") return "Student";
  return userType ? `${userType[0].toUpperCase()}${userType.slice(1)}` : "Member";
}

function logActivity(userId, action, details) {
  const user = db.prepare("SELECT id, name, user_type, role FROM users WHERE id = ?").get(userId);
  if (!user || user.role === "admin") return;

  const name = String(user.name || "").trim();
  const userType = activityUserType(user);
  db.prepare(
    "INSERT INTO activity_log (librarian_name, actor_name, actor_type, action, details) VALUES (?, ?, ?, ?, ?)",
  ).run(name, name, userType, action, details);
}

function getBorrowingDurationDays(settingKey = "borrowing_duration_days") {
  const setting = db
    .prepare("SELECT setting_value FROM library_settings WHERE setting_key = ?")
    .get(settingKey);
  const duration = Number(setting?.setting_value);
  const fallback = settingKey === "faculty_borrowing_duration_days" ? 7 : 4;
  return isValidDurationDays(duration) ? duration : fallback;
}

function getReservationWalkInMinimumCopies() {
  const value = Number(
    db.prepare("SELECT setting_value FROM library_settings WHERE setting_key = ?")
      .get("reservation_walk_in_minimum_copies")?.setting_value ?? 1,
  );
  return [1, 2, 3].includes(value) ? value : 1;
}

function getReservationHoldDays() {
  const value = Number(
    db.prepare("SELECT setting_value FROM library_settings WHERE setting_key = ?")
      .get("reservation_hold_days")?.setting_value ?? 7,
  );
  return Number.isSafeInteger(value) && value >= 1 && value <= 30 ? value : 7;
}

function getPenaltyCostPerDay() {
  const value = Number(
    db.prepare("SELECT setting_value FROM library_settings WHERE setting_key = ?")
      .get("penalty_cost_per_day")?.setting_value ?? 10,
  );
  return Number.isFinite(value) && value >= 0 && value <= 1000000
    ? Math.round(value * 100) / 100
    : 10;
}

function dateInManila(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Manila",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function addManilaDays(days) {
  const [year, month, day] = dateInManila().split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  return date.toISOString().slice(0, 10);
}

function isValidPickupDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ""))) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day &&
    value >= dateInManila();
}

function getReservationExpiryUtc(pickupDate, holdDays) {
  const pickupDeadline = Date.parse(`${pickupDate}T23:59:59.999+08:00`);
  const holdDeadline = Date.now() + holdDays * 24 * 60 * 60 * 1000;
  const expiry = new Date(Math.min(pickupDeadline, holdDeadline));
  return `${expiry.getUTCFullYear()}-${String(expiry.getUTCMonth() + 1).padStart(2, "0")}-${String(expiry.getUTCDate()).padStart(2, "0")} ${String(expiry.getUTCHours()).padStart(2, "0")}:${String(expiry.getUTCMinutes()).padStart(2, "0")}:${String(expiry.getUTCSeconds()).padStart(2, "0")}`;
}

function formatManilaDeadline(utcDateTime) {
  const parsed = new Date(`${utcDateTime.replace(" ", "T")}Z`);
  return new Intl.DateTimeFormat("en-PH", {
    timeZone: "Asia/Manila",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(parsed);
}

function transactionConflict(err) {
  return /Expected \d+ affected row\(s\) at transaction step/.test(String(err?.message || err));
}

function expireVisitorReservations() {
  const overduePending = db.prepare(
    `SELECT id, user_id, book_id, status FROM visitor_reservations
     WHERE status = 'pending' AND pickup_date < ?`,
  ).all(dateInManila());
  const overdueHolds = db.prepare(
    `SELECT id, user_id, book_id, status FROM visitor_reservations
     WHERE status = 'approved' AND expires_at <= UTC_TIMESTAMP()`,
  ).all();
  for (const reservation of [...overduePending, ...overdueHolds]) {
    const status = reservation.status;
    const steps = [
      {
        sql: "UPDATE visitor_reservations SET status = 'expired', active_key = NULL WHERE id = ? AND status = ?",
        values: [reservation.id, status],
        expectAffectedRows: 1,
      },
    ];
    if (status === "approved") {
      steps.push({
        sql: "UPDATE books SET available = available + 1 WHERE id = ?",
        values: [reservation.book_id],
        expectAffectedRows: 1,
      });
    }
    steps.push({
      sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
            VALUES (?, 'Reservation Expired', ?, ?, 'Library System')`,
      values: [
        reservation.user_id,
        status === "approved"
          ? "Your reservation hold has expired. Its copy is now available to other library users."
          : "Your reservation request expired because the selected pickup date passed before approval.",
        todayMMDDYYYY(),
      ],
    });
    try {
      db.transaction(steps);
    } catch (err) {
      if (!transactionConflict(err)) throw err;
    }
  }
}

function getDurationForUser(user) {
  const userType = String(user?.user_type || "").toLowerCase();
  const isFaculty = userType === "faculty" || userType === "teacher";
  return getBorrowingDurationDays(isFaculty ? "faculty_borrowing_duration_days" : "borrowing_duration_days");
}

function addDaysToMMDDYYYY(dateString, days) {
  const [month, day, year] = String(dateString).split("/").map(Number);
  const date = new Date(year, month - 1, day);
  date.setDate(date.getDate() + days);
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  return `${mm}/${dd}/${date.getFullYear()}`;
}

/* ---------- Auth ---------- */

app.post("/api/auth/login", (req, res) => {
  const { identifier, password, role } = req.body;
  if (!identifier || !password) {
    return res.status(400).json({ error: "Credentials required." });
  }

  const id = String(identifier).trim().toLowerCase();
  let user = db
    .prepare(
      `SELECT * FROM users WHERE lower(email) = ? OR lower(username) = ? OR lower(name) = ? OR replace(upper(school_id),' ','') = replace(upper(?),' ','')`,
    )
    .get(id, id, id, id);

  const storedPassword = user && String(user.password || "");
  const isBcryptHash = /^\$2[aby]\$\d{2}\$/.test(storedPassword);
  const passwordMatches = user && (
    isBcryptHash
      ? bcrypt.compareSync(String(password), storedPassword)
      : storedPassword === String(password)
  );

  if (!passwordMatches) {
    return res.status(401).json({ error: "Invalid credentials." });
  }

  if (role && user.role !== role) {
    return res.status(401).json({ error: `Invalid credentials for ${role} role.` });
  }

  if (user.role !== "admin" && user.role !== "librarian" && user.status !== "active") {
    const error = user.status === "deactivated"
      ? "The account you're trying to access is deactivated. Please contact the Administrator."
      : "The account you're trying to access is still pending for approval. Wait for the Administrator to approve it.";
    return res.status(403).json({ error });
  }

  if (!isBcryptHash) {
    db.prepare("UPDATE users SET password = ? WHERE id = ?").run(bcrypt.hashSync(String(password), 10), user.id);
  }

  const token = `tok_${user.id}_${Date.now()}`;
  sessions.set(token, { userId: user.id, role: user.role });

  logActivity(user.id, "Login", "Logged in successfully");

  return res.json({ ok: true, token, user: publicUser(user) });
});

app.post("/api/auth/profile", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(session.userId);
  if (!user) return res.status(404).json({ error: "User account not found." });

  const name = String(req.body.name || "").trim();
  const email = String(req.body.email ?? user.email ?? "").trim().toLowerCase();
  const username = user.role === "staff"
    ? email.split("@")[0]
    : String(req.body.username ?? user.username ?? "").trim();
  const phone = String(req.body.phone ?? user.phone ?? "").trim();
  const currentPassword = String(req.body.currentPassword || "");
  const newPassword = String(req.body.newPassword || "");

  if (!name || !username || !email) {
    return res.status(400).json({
      error: user.role === "staff" ? "Name and email are required." : "Name, username, and email are required.",
    });
  }
  if (username.length > 255) return res.status(400).json({ error: "Username must be 255 characters or fewer." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }
  if (newPassword) {
    if (!currentPassword) return res.status(400).json({ error: "Current password is required." });
    if (newPassword.length < 8) return res.status(400).json({ error: "New password must be at least 8 characters." });
    const storedPassword = String(user.password || "");
    const isBcryptHash = /^\$2[aby]\$\d{2}\$/.test(storedPassword);
    const passwordMatches = isBcryptHash
      ? bcrypt.compareSync(currentPassword, storedPassword)
      : currentPassword === storedPassword;
    if (!passwordMatches) {
      return res.status(401).json({ error: "Current password is incorrect." });
    }
  }

  const duplicateUsername = db
    .prepare("SELECT id FROM users WHERE lower(username) = ? AND id <> ?")
    .get(username.toLowerCase(), user.id);
  if (duplicateUsername) {
    return res.status(409).json({
      error: user.role === "staff"
        ? "The part of this email address before @ is already in use as a username."
        : "Username already in use.",
    });
  }

  const duplicate = db
    .prepare("SELECT id FROM users WHERE lower(email) = ? AND id <> ?")
    .get(email, user.id);
  if (duplicate) return res.status(409).json({ error: "Email already registered." });

  if (newPassword) {
    db.prepare("UPDATE users SET name = ?, username = ?, email = ?, phone = ?, password = ? WHERE id = ?")
      .run(name, username, email, phone || null, bcrypt.hashSync(newPassword, 10), user.id);
  } else {
    db.prepare("UPDATE users SET name = ?, username = ?, email = ?, phone = ? WHERE id = ?")
      .run(name, username, email, phone || null, user.id);
  }

  logActivity(user.id, "Profile Update", "Updated profile information");
  return res.json({ ok: true, user: publicUser(db.prepare("SELECT * FROM users WHERE id = ?").get(user.id)) });
});

app.post("/api/auth/register/check", (req, res) => {
  const { email, phone, schoolId, userType, role } = req.body;
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const accountType = registrationAccountType(userType, role);
  if (!normalizedEmail || !phone || !schoolId) {
    return res.status(400).json({ error: "Required fields missing." });
  }
  if (!accountType) return res.status(400).json({ error: "Select a valid account type." });

  const fieldErrors = registrationDuplicateFields({
    username: normalizedEmail.split("@")[0],
    email: normalizedEmail,
    phone,
    schoolId,
    role: accountType.role,
  });
  if (Object.keys(fieldErrors).length > 0) {
    return res.status(409).json({
      error: "Some account information is already in use.",
      fieldErrors,
    });
  }
  return res.json({ ok: true });
});

app.post("/api/auth/register", async (req, res) => {
  const { name, email, phone, schoolId, password, userType, course, role } = req.body;
  if (!name || !email || !password || !phone || !schoolId) {
    return res.status(400).json({ error: "Required fields missing." });
  }
  if (typeof password !== "string" || password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const normalizedSchoolId = String(schoolId).trim().replace(/\s+/g, "").toUpperCase();
  const accountType = registrationAccountType(userType, role);
  if (!accountType) return res.status(400).json({ error: "Select a valid account type." });
  const { userType: normalizedUserType, role: userRole } = accountType;
  const fieldErrors = registrationDuplicateFields({
    username: normalizedEmail.split("@")[0],
    email: normalizedEmail,
    phone,
    schoolId: normalizedSchoolId,
    role: userRole,
  });
  if (Object.keys(fieldErrors).length > 0) {
    return res.status(409).json({
      error: "Some account information is already in use.",
      fieldErrors,
    });
  }

  const isFaculty = ["faculty", "teacher"].includes(normalizedUserType.toLowerCase());
  const accountStatus = userRole === "visitor" ? "active" : "pending";
  const result = db
    .prepare(
      `INSERT INTO users (username, email, password, name, phone, school_id, user_type, course, role, status, fresh_account)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
    )
    .run(
      normalizedEmail.split("@")[0],
      normalizedEmail,
      bcrypt.hashSync(password, 10),
      String(name).trim(),
      normalizePhone(phone),
      normalizedSchoolId,
      normalizedUserType,
      userRole === "visitor" || isFaculty ? null : course || null,
      userRole,
      accountStatus,
    );

  const registrationMessage = userRole === "visitor"
    ? "Visitor account created. You may now sign in."
    : "Registration submitted. Await account approval.";
  logActivity(
    result.lastInsertRowid,
    "Account Registration",
    userRole === "visitor" ? "Created a visitor account" : "Submitted an account registration for approval",
  );
  let sms = "not_sent";
  let smsError;
  if (userRole === "visitor") {
    try {
      const message = renderSmsTemplate("Visitor Account Creation", {
        Name: String(name).trim(),
      });
      const smsResult = await sendSms(normalizePhone(phone), message);
      sms = smsResult.mock ? "demo" : "sent";
    } catch (err) {
      sms = "failed";
      smsError = err.message || "SMS delivery failed.";
      console.error(`Visitor account creation SMS failed for user ${result.lastInsertRowid}:`, smsError);
    }
  }
  return res.json({
    ok: true,
    userId: result.lastInsertRowid,
    message: registrationMessage,
    ...(userRole === "visitor" ? { sms, ...(smsError ? { smsError } : {}) } : {}),
  });
});

app.post("/api/auth/logout", (req, res) => {
  const token = req.headers.authorization?.replace("Bearer ", "");
  const session = token ? sessions.get(token) : null;
  if (session) {
    logActivity(session.userId, "Logout", "Logged out of the system");
    sessions.delete(token);
  }
  return res.json({ ok: true });
});

/* ---------- SMS ---------- */

app.post("/api/sms/send-otp", async (req, res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const name = String(req.body.name || "Member").trim();
    if (!phone) return res.status(400).json({ error: "Phone number is required." });
    const templateType = String(req.body.templateType || "OTP (Account Creation)");
    if (!["OTP (Account Creation)", "OTP (Change Password)"].includes(templateType)) {
      return res.status(400).json({ error: "Invalid OTP SMS template type." });
    }

    const code = createOtpCode();
    const message = renderSmsTemplate(templateType, {
      Name: name,
      OTP: code,
      "Expiration Time": "5 minutes",
    });
    otpStore.set(`${phone}:signup`, { code, expiresAt: Date.now() + 5 * 60 * 1000 });
    const smsResult = await sendSms(phone, message);

    return res.json({
      ok: true,
      message: "OTP sent.",
      mock: smsResult.mock,
      ...(smsResult.mock ? { devCode: code } : {}),
    });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Failed to send OTP." });
  }
});

app.post("/api/sms/verify-otp", (req, res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || "").trim();
  if (!phone || !code) return res.status(400).json({ error: "Phone and code are required." });

  const entry = otpStore.get(`${phone}:signup`);
  if (!entry) return res.status(400).json({ error: "OTP not found. Request a new one." });
  if (Date.now() > entry.expiresAt) {
    otpStore.delete(`${phone}:signup`);
    return res.status(400).json({ error: "OTP expired. Request a new one." });
  }
  if (entry.code !== code) return res.status(400).json({ error: "Invalid OTP code." });

  otpStore.delete(`${phone}:signup`);
  return res.json({ ok: true, message: "OTP verified." });
});

app.post("/api/auth/password-reset/request", async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  if (!phone) return res.status(400).json({ error: "Phone number is required." });
  const users = db.prepare(
    "SELECT id, name, phone FROM users WHERE status = 'active' AND phone IS NOT NULL",
  ).all();
  const user = users.find((candidate) => normalizePhone(candidate.phone) === phone);
  if (!user) return res.json({ ok: true });
  const otpKey = `${phone}:password-reset`;
  const existingOtp = otpStore.get(otpKey);
  if (existingOtp && Date.now() <= existingOtp.expiresAt) {
    return res.json({ ok: true });
  }

  try {
    const code = createOtpCode();
    const message = renderSmsTemplate("OTP (Change Password)", {
      Name: user.name,
      OTP: code,
      "Expiration Time": "5 minutes",
    });
    const smsResult = await sendSms(phone, message);
    otpStore.set(otpKey, {
      code,
      userId: user.id,
      expiresAt: Date.now() + 5 * 60 * 1000,
      attempts: 0,
    });
    return res.json({
      ok: true,
      mock: smsResult.mock,
      ...(smsResult.mock ? { devCode: code } : {}),
    });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Failed to send password reset code." });
  }
});

app.post("/api/auth/password-reset/verify", (req, res) => {
  const phone = normalizePhone(req.body.phone);
  const code = String(req.body.code || "").trim();
  if (!phone || !code) return res.status(400).json({ error: "Phone and code are required." });

  const key = `${phone}:password-reset`;
  const entry = otpStore.get(key);
  if (!entry) return res.status(400).json({ error: "OTP not found. Request a new one." });
  if (Date.now() > entry.expiresAt) {
    otpStore.delete(key);
    return res.status(400).json({ error: "OTP expired. Request a new one." });
  }
  if (entry.code !== code) {
    entry.attempts = (entry.attempts || 0) + 1;
    if (entry.attempts >= 5) otpStore.delete(key);
    return res.status(400).json({
      error: entry.attempts >= 5
        ? "Too many incorrect attempts. Request a new code."
        : "Invalid OTP code.",
    });
  }

  otpStore.delete(key);
  const resetToken = randomUUID();
  passwordResetTokens.set(resetToken, {
    userId: entry.userId,
    expiresAt: Date.now() + 5 * 60 * 1000,
  });
  return res.json({ ok: true, resetToken });
});

app.post("/api/auth/password-reset", (req, res) => {
  const resetToken = String(req.body.resetToken || "");
  const password = String(req.body.password || "");
  const confirmPassword = String(req.body.confirmPassword || "");
  const reset = passwordResetTokens.get(resetToken);
  if (!reset || Date.now() > reset.expiresAt) {
    passwordResetTokens.delete(resetToken);
    return res.status(400).json({ error: "Password reset authorization expired. Request a new code." });
  }
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });
  if (password !== confirmPassword) return res.status(400).json({ error: "Passwords do not match." });

  const result = db.prepare(
    "UPDATE users SET password = ? WHERE id = ? AND status = 'active'",
  ).run(bcrypt.hashSync(password, 10), reset.userId);
  passwordResetTokens.delete(resetToken);
  if (!result.changes) return res.status(404).json({ error: "Active account not found." });
  for (const [token, session] of sessions) {
    if (Number(session.userId) === Number(reset.userId)) sessions.delete(token);
  }
  logActivity(reset.userId, "Password Reset", "Reset password using verified phone OTP");
  return res.json({ ok: true });
});

app.post("/api/sms/borrow-confirmation", async (req, res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    if (!phone) return res.status(400).json({ error: "Phone number is required." });

    const userName = String(req.body.userName || "Member");
    const bookTitle = String(req.body.bookTitle || "Book");
    const author = String(req.body.author || "Unknown Author");
    const borrowDate = String(req.body.borrowDate || "-");
    const dueDate = String(req.body.dueDate || "-");

    const message = renderSmsTemplate("Borrow Confirmation", {
      Name: userName,
      Username: userName,
      "Borrower Name": userName,
      "Book Title": bookTitle,
      Author: author,
      "Borrow Date": borrowDate,
      "Return Date": dueDate,
    });

    const smsResult = await sendSms(phone, message);
    return res.json({ ok: true, mock: smsResult.mock, message: "Borrow confirmation SMS sent." });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Failed to send borrow confirmation." });
  }
});

app.post("/api/sms/overdue-notice", async (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  try {
    const phone = normalizePhone(req.body.phone);
    if (!phone) return res.status(400).json({ error: "Borrower phone number is required." });
    const userName = String(req.body.userName || "Member");
    const bookTitle = String(req.body.bookTitle || "Book");
    const author = String(req.body.author || "Unknown Author");
    const dueDate = String(req.body.dueDate || "-");
    const message = renderSmsTemplate("Overdue Notice", {
      Name: userName,
      "Borrower Name": userName,
      "Book Title": bookTitle,
      Author: author,
      "Return Date": dueDate,
    });

    const smsResult = await sendSms(phone, message);
    return res.json({ ok: true, mock: smsResult.mock });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Failed to send overdue notice." });
  }
});

let dueDateReminderInFlight = false;

async function sendDueDateReminders() {
  if (dueDateReminderInFlight) return;
  dueDateReminderInFlight = true;
  try {
    const dueDate = addManilaDays(1);
    const loans = db.prepare(
      `SELECT t.id, t.due_date, b.title, b.author, u.name, u.phone
       FROM transactions t
       JOIN books b ON b.id = t.book_id
       JOIN users u ON u.id = t.user_id
       LEFT JOIN sms_reminder_log sent ON sent.transaction_id = t.id
       WHERE t.status = 'borrowed'
         AND STR_TO_DATE(t.due_date, '%m/%d/%Y') = STR_TO_DATE(?, '%Y-%m-%d')
         AND u.status = 'active'
         AND u.phone IS NOT NULL
         AND sent.transaction_id IS NULL
       ORDER BY t.id`,
    ).all(dueDate);

    for (const loan of loans) {
      try {
        const message = renderSmsTemplate("Due Date Reminder", {
          Name: loan.name,
          "Borrower Name": loan.name,
          "Book Title": loan.title,
          Author: loan.author,
          "Return Date": loan.due_date,
        });
        await sendSms(normalizePhone(loan.phone), message);
        db.prepare("INSERT IGNORE INTO sms_reminder_log (transaction_id) VALUES (?)").run(loan.id);
      } catch (err) {
        console.error(`Unable to send due-date reminder for transaction ${loan.id}:`, err.message || err);
      }
    }
  } catch (err) {
    console.error("Unable to process due-date reminders:", err.message || err);
  } finally {
    dueDateReminderInFlight = false;
  }
}

/* ---------- Books ---------- */

app.get("/api/books", (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  let rows = db.prepare(
    `SELECT b.*,
            COALESCE(active_loans.borrowed, 0) AS borrowed
     FROM books b
     LEFT JOIN (
       SELECT book_id, COUNT(*) AS borrowed
       FROM transactions
       WHERE status IN ('borrowed', 'overdue', 'return_pending')
       GROUP BY book_id
     ) active_loans ON active_loans.book_id = b.id
     WHERE b.is_archived = 0
     ORDER BY b.title`,
  ).all();
  if (q) {
    rows = rows.filter((b) => b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q));
  }
  const reservationWalkInMinimumCopies = getReservationWalkInMinimumCopies();
  const reservationHoldDays = getReservationHoldDays();
  return res.json(
    rows.map((b) => ({
      id: String(b.id),
      title: b.title,
      author: b.author,
      avail: b.available,
      borrowed: Number(b.borrowed) || 0,
      total: b.total,
      reservationWalkInMinimumCopies,
      reservationHoldDays,
      isbn: b.isbn,
      publicationYear: b.publication_year,
    })),
  );
});

app.get("/api/books/:id/copies", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;
  const bookId = Number(req.params.id);
  if (!Number.isInteger(bookId) || bookId < 1) return res.status(400).json({ error: "Invalid book ID." });
  const book = db.prepare("SELECT id FROM books WHERE id = ?").get(bookId);
  if (!book) return res.status(404).json({ error: "Book not found." });
  const copies = db.prepare(
    "SELECT id, barcode, is_active, created_at FROM book_copies WHERE book_id = ? ORDER BY id",
  ).all(bookId);
  return res.json(copies.map((copy) => ({
    id: copy.id,
    barcode: copy.barcode,
    isActive: Number(copy.is_active) === 1,
    createdAt: copy.created_at,
  })));
});

app.get("/api/books/copies", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;
  const copies = db.prepare(
    `SELECT c.book_id, c.barcode
     FROM book_copies c
     JOIN books b ON b.id = c.book_id
     WHERE c.is_active = 1 AND b.is_archived = 0
     ORDER BY c.book_id, c.id`,
  ).all();
  return res.json(copies.map((copy) => ({
    bookId: String(copy.book_id),
    barcode: copy.barcode,
  })));
});

app.post("/api/books", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;

  const { title, author, total, available, isbn, publicationYear } = req.body;
  if (!String(title || "").trim() || !String(author || "").trim() || !String(isbn || "").trim()) {
    return res.status(400).json({ error: "Title, author, and ISBN required." });
  }
  const parsedTotal = Number(total);
  const parsedAvailable = available === undefined ? parsedTotal : Number(available);
  if (!Number.isInteger(parsedTotal) || parsedTotal < 1 || parsedTotal > MAX_COPY_COUNT_PER_BOOK || !Number.isInteger(parsedAvailable) || parsedAvailable < 0 || parsedAvailable > parsedTotal) {
    return res.status(400).json({ error: `Enter a total between 1 and ${MAX_COPY_COUNT_PER_BOOK} copies, with an available count between 0 and the total.` });
  }

  const barcodes = Array.from({ length: parsedTotal }, () =>
    `GGC-${randomUUID().replace(/-/g, "").toUpperCase()}`,
  );
  const transactionSteps = [
    {
      sql: "INSERT INTO books (title, author, isbn, publication_year, total, available) VALUES (?, ?, ?, ?, ?, ?)",
      values: [String(title).trim(), String(author).trim(), isbn || null, publicationYear || null, parsedTotal, parsedAvailable],
    },
  ];
  for (let offset = 0; offset < barcodes.length; offset += 500) {
    const batch = barcodes.slice(offset, offset + 500);
    transactionSteps.push({
      sql: `INSERT INTO book_copies (book_id, barcode) VALUES ${batch.map(() => "(?, ?)").join(", ")}`,
      values: batch.flatMap((barcode) => [{ __lastInsertIdOf: 0 }, barcode]),
    });
  }
  const result = db.transaction(transactionSteps)[0];

  logActivity(session.userId, "Catalog Update", `Added new book (${title})`);

  return res.status(201).json({ ok: true, id: String(result.insertId), barcodes });
});

app.put("/api/books/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;

  const bookId = Number(req.params.id);
  if (!Number.isInteger(bookId) || bookId < 1) return res.status(400).json({ error: "Invalid book ID." });

  const title = String(req.body.title || "").trim();
  const author = String(req.body.author || "").trim();
  const isbn = String(req.body.isbn || "").trim();
  const total = Number(req.body.total);
  const available = Number(req.body.available);
  if (!title || !author || !isbn) {
    return res.status(400).json({ error: "Title, author, and ISBN are required." });
  }
  if (!Number.isInteger(total) || total < 1 || total > MAX_COPY_COUNT_PER_BOOK) {
    return res.status(400).json({ error: `Total stock must be a whole number between 1 and ${MAX_COPY_COUNT_PER_BOOK}.` });
  }
  if (!Number.isInteger(available) || available < 0) {
    return res.status(400).json({ error: "Available copies must be a non-negative whole number." });
  }

  const book = db.prepare("SELECT id, total FROM books WHERE id = ? AND is_archived = 0").get(bookId);
  if (!book) return res.status(404).json({ error: "Book not found." });

  expireVisitorReservations();
  const checkedOut = db
    .prepare("SELECT COUNT(*) AS count FROM transactions WHERE book_id = ? AND status IN ('borrowed', 'overdue', 'return_pending')")
    .get(bookId).count;
  const activeHolds = db
    .prepare("SELECT COUNT(*) AS count FROM visitor_reservations WHERE book_id = ? AND status = 'approved'")
    .get(bookId).count;
  const requiredTotal = available + Number(checkedOut) + Number(activeHolds);
  if (requiredTotal > total) {
    return res.status(400).json({ error: `Total stock must be at least ${requiredTotal} to include available, checked-out, and reserved copies.` });
  }

  const currentCopyCount = Number(db.prepare(
    "SELECT COUNT(*) AS count FROM book_copies WHERE book_id = ? AND is_active = 1",
  ).get(bookId).count);
  const copyDelta = total - currentCopyCount;
  const transactionSteps = [{
    sql: "UPDATE books SET title = ?, author = ?, isbn = ?, total = ?, available = ? WHERE id = ?",
    values: [title, author, isbn, total, available, bookId],
  }];
  if (copyDelta > 0) {
    const newBarcodes = Array.from({ length: copyDelta }, () =>
      `GGC-${randomUUID().replace(/-/g, "").toUpperCase()}`,
    );
    for (let offset = 0; offset < newBarcodes.length; offset += 500) {
      const batch = newBarcodes.slice(offset, offset + 500);
      transactionSteps.push({
        sql: `INSERT INTO book_copies (book_id, barcode) VALUES ${batch.map(() => "(?, ?)").join(", ")}`,
        values: batch.flatMap((barcode) => [bookId, barcode]),
      });
    }
  } else if (copyDelta < 0) {
    transactionSteps.push({
      sql: "UPDATE book_copies SET is_active = 0 WHERE book_id = ? AND is_active = 1 ORDER BY id DESC LIMIT ?",
      values: [bookId, Math.abs(copyDelta)],
    });
  }
  db.transaction(transactionSteps);
  logActivity(session.userId, "Catalog Update", `Edited book (${title})`);
  return res.json({ ok: true });
});

app.delete("/api/books/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;

  const bookId = Number(req.params.id);
  if (!Number.isInteger(bookId) || bookId < 1) return res.status(400).json({ error: "Invalid book ID." });

  const book = db.prepare("SELECT id, title FROM books WHERE id = ? AND is_archived = 0").get(bookId);
  if (!book) return res.status(404).json({ error: "Book not found." });

  expireVisitorReservations();
  const activeReservation = db
    .prepare("SELECT id FROM visitor_reservations WHERE book_id = ? AND status IN ('pending', 'approved') LIMIT 1")
    .get(bookId);
  if (activeReservation) {
    return res.status(409).json({ error: "Resolve active visitor reservations for this book before removing it from the catalog." });
  }

  const pendingTransaction = db
    .prepare("SELECT id FROM transactions WHERE book_id = ? AND status = 'pending' LIMIT 1")
    .get(bookId);
  if (pendingTransaction) {
    return res.status(409).json({ error: "Resolve pending borrow requests for this book before removing it from the catalog." });
  }

  db.prepare("DELETE FROM cart_items WHERE book_id = ?").run(bookId);
  db.prepare("UPDATE books SET is_archived = 1 WHERE id = ?").run(bookId);

  logActivity(session.userId, "Catalog Update", `Removed book from active catalog (${book.title})`);
  return res.json({ ok: true });
});

/* ---------- Cart ---------- */

app.get("/api/cart", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  const rows = db
    .prepare(
      `SELECT b.* FROM cart_items c JOIN books b ON b.id = c.book_id WHERE c.user_id = ? AND b.is_archived = 0 ORDER BY b.title`,
    )
    .all(session.userId);

  return res.json(
    rows.map((b) => ({ id: String(b.id), title: b.title, author: b.author, avail: b.available, total: b.total })),
  );
});

app.post("/api/cart/:bookId", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  db.prepare("INSERT IGNORE INTO cart_items (user_id, book_id) VALUES (?, ?)").run(session.userId, req.params.bookId);
  return res.json({ ok: true });
});

app.delete("/api/cart/:bookId", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  db.prepare("DELETE FROM cart_items WHERE user_id = ? AND book_id = ?").run(session.userId, req.params.bookId);
  return res.json({ ok: true });
});

/* ---------- Library policies ---------- */

app.get("/api/library-policy", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "admin"].includes(session.role)) return;
  return res.json({
    borrowingDurationDays: getBorrowingDurationDays(),
    facultyBorrowingDurationDays: getBorrowingDurationDays("faculty_borrowing_duration_days"),
    reservationWalkInMinimumCopies: getReservationWalkInMinimumCopies(),
    reservationHoldDays: getReservationHoldDays(),
    penaltyCostPerDay: getPenaltyCostPerDay(),
  });
});

app.post("/api/library-policy", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  const duration = Number(req.body.borrowingDurationDays);
  const facultyDuration = Number(req.body.facultyBorrowingDurationDays);
  const reservationWalkInMinimumCopies = req.body.reservationWalkInMinimumCopies === undefined
    ? getReservationWalkInMinimumCopies()
    : Number(req.body.reservationWalkInMinimumCopies);
  const reservationHoldDays = req.body.reservationHoldDays === undefined
    ? getReservationHoldDays()
    : Number(req.body.reservationHoldDays);
  const penaltyCostPerDay = req.body.penaltyCostPerDay === undefined
    ? getPenaltyCostPerDay()
    : Number(req.body.penaltyCostPerDay);
  if (!isValidDurationDays(duration) || !isValidDurationDays(facultyDuration)) {
    return res.status(400).json({ error: "Returning durations must be positive whole numbers of days that result in a supported due date." });
  }
  if (![1, 2, 3].includes(reservationWalkInMinimumCopies)) {
    return res.status(400).json({ error: "The minimum copies to keep available for walk-in borrowers must be 1, 2, or 3." });
  }
  if (!Number.isSafeInteger(reservationHoldDays) || reservationHoldDays < 1 || reservationHoldDays > 30) {
    return res.status(400).json({ error: "The reservation hold period must be between 1 and 30 whole days." });
  }
  if (!Number.isFinite(penaltyCostPerDay) || penaltyCostPerDay < 0 || penaltyCostPerDay > 1000000 ||
    Math.round(penaltyCostPerDay * 100) !== penaltyCostPerDay * 100) {
    return res.status(400).json({ error: "The penalty cost per day must be between ₱0 and ₱1,000,000, with up to two decimal places." });
  }

  db.prepare(
    "INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
  ).run("borrowing_duration_days", String(duration));
  db.prepare(
    "INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
  ).run("faculty_borrowing_duration_days", String(facultyDuration));
  db.prepare(
    "INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
  ).run("reservation_walk_in_minimum_copies", String(reservationWalkInMinimumCopies));
  db.prepare(
    "INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
  ).run("reservation_hold_days", String(reservationHoldDays));
  db.prepare(
    "INSERT INTO library_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)",
  ).run("penalty_cost_per_day", penaltyCostPerDay.toFixed(2));

  logActivity(
    session.userId,
    "Policy Update",
    `Set student and visitor returning duration to ${duration} days, faculty and teacher returning duration to ${facultyDuration} days, walk-in minimum to ${reservationWalkInMinimumCopies} copies, reservation holds to ${reservationHoldDays} days, and overdue penalty to ₱${penaltyCostPerDay.toFixed(2)} per day`,
  );
  return res.json({
    ok: true,
    borrowingDurationDays: duration,
    facultyBorrowingDurationDays: facultyDuration,
    reservationWalkInMinimumCopies,
    reservationHoldDays,
    penaltyCostPerDay,
  });
});

/* ---------- Visitor reservations ---------- */

function mapVisitorReservation(row) {
  return {
    id: row.id,
    userId: row.user_id,
    bookId: row.book_id,
    title: row.title,
    author: row.author,
    isbn: row.isbn,
    userName: row.user_name,
    schoolId: row.school_id,
    pickupDate: String(row.pickup_date).slice(0, 10),
    status: row.status,
    createdAt: row.created_at,
    approvedAt: row.approved_at,
    expiresAt: row.expires_at,
    transactionId: row.transaction_id,
  };
}

function getVisitorReservations(where, values = [], order = "DESC") {
  return db.prepare(
    `SELECT r.id, r.user_id, r.book_id, b.title, b.author, b.isbn,
            u.name AS user_name, u.school_id,
            DATE_FORMAT(r.pickup_date, '%Y-%m-%d') AS pickup_date,
            DATE_FORMAT(r.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
            DATE_FORMAT(r.approved_at, '%Y-%m-%d %H:%i:%s') AS approved_at,
            DATE_FORMAT(r.expires_at, '%Y-%m-%d %H:%i:%s') AS expires_at,
            r.status, r.transaction_id
     FROM visitor_reservations r
     JOIN books b ON b.id = r.book_id
     JOIN users u ON u.id = r.user_id
     ${where}
     ORDER BY r.id ${order}`,
  ).all(...values).map(mapVisitorReservation);
}

app.get("/api/reservations/mine", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;
  if (session.role !== "visitor") return res.status(403).json({ error: "Reservations are currently available to visitor accounts only." });
  expireVisitorReservations();
  return res.json(getVisitorReservations("WHERE r.user_id = ?", [session.userId]));
});

app.get("/api/reservations", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;
  expireVisitorReservations();
  return res.json(getVisitorReservations("WHERE r.status IN ('pending', 'approved')", [], "ASC"));
});

app.post("/api/reservations", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;
  if (session.role !== "visitor") return res.status(403).json({ error: "Reservations are currently available to visitor accounts only." });
  const restriction = getBorrowingRestriction(session.userId);
  if (restriction) return res.status(403).json({ error: restriction });
  expireVisitorReservations();

  const bookId = Number(req.body.bookId);
  const pickupDate = String(req.body.pickupDate || "");
  if (!Number.isSafeInteger(bookId) || bookId < 1) return res.status(400).json({ error: "Choose a valid book to reserve." });
  if (!isValidPickupDate(pickupDate)) return res.status(400).json({ error: "Choose a valid pickup date that is today or later." });

  const book = db.prepare("SELECT id, title, available FROM books WHERE id = ? AND is_archived = 0").get(bookId);
  if (!book) return res.status(404).json({ error: "This book is no longer available in the catalog." });
  if (Number(book.available) <= getReservationWalkInMinimumCopies()) {
    return res.status(409).json({ error: `Reservations require more than ${getReservationWalkInMinimumCopies()} available ${getReservationWalkInMinimumCopies() === 1 ? "copy" : "copies"} so the walk-in minimum remains in the library.` });
  }

  const activeReservation = db.prepare(
    "SELECT id FROM visitor_reservations WHERE user_id = ? AND book_id = ? AND status IN ('pending', 'approved') LIMIT 1",
  ).get(session.userId, bookId);
  if (activeReservation) return res.status(409).json({ error: "You already have a pending or active reservation for this book." });
  const activeLoan = db.prepare(
    "SELECT id FROM transactions WHERE user_id = ? AND book_id = ? AND status IN ('borrowed', 'overdue', 'return_pending') LIMIT 1",
  ).get(session.userId, bookId);
  if (activeLoan) return res.status(409).json({ error: "You already have this book checked out." });

  try {
    const [inserted] = db.transaction([
      {
        sql: `INSERT INTO visitor_reservations (user_id, book_id, pickup_date, active_key)
              VALUES (?, ?, ?, ?)`,
        values: [session.userId, bookId, pickupDate, `${session.userId}:${bookId}`],
      },
      {
        sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
              VALUES (?, 'Reservation Request Submitted', ?, ?, 'Library System')`,
        values: [
          session.userId,
          `Your reservation request for ${book.title} is waiting for librarian approval. A copy is not held until approval.`,
          todayMMDDYYYY(),
        ],
      },
    ]);
    logActivity(session.userId, "Visitor Reservation Request", `Requested a reservation for book (${book.title})`);
    return res.json({ ok: true, reservationId: inserted.insertId });
  } catch (err) {
    if (/Duplicate entry/i.test(String(err?.message || err))) {
      return res.status(409).json({ error: "You already have a pending or active reservation for this book." });
    }
    throw err;
  }
});

app.post("/api/reservations/:id/approve", async (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;
  expireVisitorReservations();
  const reservation = db.prepare(
    `SELECT r.id, r.user_id, r.book_id,
            DATE_FORMAT(r.pickup_date, '%Y-%m-%d') AS pickup_date,
            b.title, b.author, u.name AS visitor_name, u.phone AS visitor_phone
     FROM visitor_reservations r
     JOIN books b ON b.id = r.book_id
     JOIN users u ON u.id = r.user_id
     WHERE r.id = ? AND r.status = 'pending'`,
  ).get(req.params.id);
  if (!reservation) return res.status(409).json({ error: "This reservation is no longer pending." });
  const restriction = getBorrowingRestriction(reservation.user_id);
  if (restriction) return res.status(409).json({ error: restriction });
  if (String(reservation.pickup_date).slice(0, 10) < dateInManila()) {
    return res.status(409).json({ error: "The selected pickup date has passed; this request can no longer be approved." });
  }

  const minimum = getReservationWalkInMinimumCopies();
  const expiry = getReservationExpiryUtc(String(reservation.pickup_date).slice(0, 10), getReservationHoldDays());
  try {
    db.transaction([
      {
        sql: "UPDATE books SET available = available - 1 WHERE id = ? AND is_archived = 0 AND available > ?",
        values: [reservation.book_id, minimum],
        expectAffectedRows: 1,
      },
      {
        sql: `UPDATE visitor_reservations
              SET status = 'approved', approved_at = UTC_TIMESTAMP(), expires_at = ?, decided_by = ?
              WHERE id = ? AND status = 'pending'`,
        values: [expiry, session.userId, reservation.id],
        expectAffectedRows: 1,
      },
      {
        sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
              SELECT user_id, 'Reservation Approved', ?, ?, ?
              FROM visitor_reservations WHERE id = ?`,
        values: [
          `Your reservation for ${reservation.title} is approved. Pick it up by ${formatManilaDeadline(expiry)} Batangas time; the copy will be held until then.`,
          todayMMDDYYYY(),
          db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId)?.name || "Library",
          reservation.id,
        ],
      },
    ]);
  } catch (err) {
    if (transactionConflict(err)) {
      return res.status(409).json({ error: `The reservation could not be approved without reducing available copies below the ${minimum}-copy walk-in minimum. Availability may have changed.` });
    }
    throw err;
  }
  logActivity(session.userId, "Visitor Reservation Approval", `Approved reservation for book (${reservation.title})`);
  let smsStatus = "unavailable";
  if (reservation.visitor_phone) {
    try {
      const message = renderSmsTemplate("Reservation Approval", {
        Name: reservation.visitor_name,
        "Book Title": reservation.title,
        Author: reservation.author,
        "Pickup Date": reservation.pickup_date,
        "Hold Expiry": formatManilaDeadline(expiry),
      });
      const smsResult = await sendSms(normalizePhone(reservation.visitor_phone), message);
      smsStatus = smsResult.mock ? "demo" : "sent";
    } catch (err) {
      smsStatus = "failed";
      console.error(`Reservation approved, but approval SMS failed for reservation ${reservation.id}:`, err.message || err);
    }
  }
  return res.json({ ok: true, expiresAt: expiry, smsStatus });
});

app.post("/api/reservations/:id/decline", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;
  const reservation = db.prepare(
    `SELECT r.*, b.title FROM visitor_reservations r
     JOIN books b ON b.id = r.book_id WHERE r.id = ? AND r.status = 'pending'`,
  ).get(req.params.id);
  if (!reservation) return res.status(409).json({ error: "This reservation is no longer pending." });
  const librarian = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  try {
    db.transaction([
      {
        sql: "UPDATE visitor_reservations SET status = 'declined', active_key = NULL, decided_by = ? WHERE id = ? AND status = 'pending'",
        values: [session.userId, reservation.id],
        expectAffectedRows: 1,
      },
      {
        sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
              SELECT user_id, 'Reservation Declined', ?, ?, ?
              FROM visitor_reservations WHERE id = ?`,
        values: [
          `Your reservation request for ${reservation.title} was declined. Please contact the library if you need more information.`,
          todayMMDDYYYY(),
          librarian?.name || "Library",
          reservation.id,
        ],
      },
    ]);
  } catch (err) {
    if (transactionConflict(err)) return res.status(409).json({ error: "This reservation changed before it could be declined. Refresh and try again." });
    throw err;
  }
  logActivity(session.userId, "Visitor Reservation Decline", `Declined reservation for book (${reservation.title})`);
  return res.json({ ok: true });
});

app.delete("/api/reservations/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;
  if (session.role !== "visitor") return res.status(403).json({ error: "Only visitor account holders can cancel these reservations." });
  expireVisitorReservations();
  const reservation = db.prepare(
    "SELECT * FROM visitor_reservations WHERE id = ? AND user_id = ? AND status IN ('pending', 'approved')",
  ).get(req.params.id, session.userId);
  if (!reservation) return res.status(409).json({ error: "This reservation is no longer active." });
  const steps = [{
    sql: "UPDATE visitor_reservations SET status = 'cancelled', active_key = NULL WHERE id = ? AND user_id = ? AND status = ?",
    values: [reservation.id, session.userId, reservation.status],
    expectAffectedRows: 1,
  }];
  if (reservation.status === "approved") {
    steps.push({
      sql: "UPDATE books SET available = available + 1 WHERE id = ?",
      values: [reservation.book_id],
      expectAffectedRows: 1,
    });
  }
  steps.push({
    sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
          VALUES (?, 'Reservation Cancelled', ?, ?, 'Library System')`,
    values: [session.userId, "Your reservation was cancelled. Any held copy is now available to other users.", todayMMDDYYYY()],
  });
  try {
    db.transaction(steps);
  } catch (err) {
    if (transactionConflict(err)) return res.status(409).json({ error: "This reservation changed before it could be cancelled. Refresh the page and try again." });
    throw err;
  }
  logActivity(session.userId, "Visitor Reservation Cancellation", `Cancelled reservation for book (${reservation.book_id})`);
  return res.json({ ok: true });
});

app.post("/api/reservations/:id/pickup", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;
  expireVisitorReservations();
  const reservation = db.prepare(
    `SELECT r.*, b.title, b.author, u.user_type
     FROM visitor_reservations r
     JOIN books b ON b.id = r.book_id
     JOIN users u ON u.id = r.user_id
     WHERE r.id = ? AND r.status = 'approved' AND r.expires_at > UTC_TIMESTAMP()`,
  ).get(req.params.id);
  if (!reservation) return res.status(409).json({ error: "This reservation is no longer active or its hold has expired." });
  const restriction = getBorrowingRestriction(reservation.user_id);
  if (restriction) return res.status(409).json({ error: restriction });
  const borrowDate = todayMMDDYYYY();
  const dueDate = addDaysMMDDYYYY(getDurationForUser({ user_type: reservation.user_type }));
  try {
    db.transaction([
      {
        sql: "UPDATE visitor_reservations SET status = 'fulfilled', active_key = NULL WHERE id = ? AND status = 'approved' AND expires_at > UTC_TIMESTAMP()",
        values: [reservation.id],
        expectAffectedRows: 1,
      },
      {
        sql: `INSERT INTO transactions (user_id, book_id, borrow_date, due_date, created_at, status)
              VALUES (?, ?, ?, ?, UTC_TIMESTAMP(), 'borrowed')`,
        values: [reservation.user_id, reservation.book_id, borrowDate, dueDate],
      },
      {
        sql: "UPDATE visitor_reservations SET transaction_id = ? WHERE id = ? AND status = 'fulfilled'",
        values: [{ __lastInsertIdOf: 1 }, reservation.id],
        expectAffectedRows: 1,
      },
      {
        sql: `INSERT INTO notifications (user_id, title, body, date, sender_name)
              VALUES (?, 'Reserved Book Picked Up', ?, ?, ?)`,
        values: [
          reservation.user_id,
          `Your pickup of ${reservation.title} has been recorded. Return it by ${dueDate}.`,
          borrowDate,
          db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId)?.name || "Library",
        ],
      },
    ]);
  } catch (err) {
    if (transactionConflict(err)) return res.status(409).json({ error: "This reservation changed before pickup could be recorded. Refresh and try again." });
    throw err;
  }
  logActivity(session.userId, "Visitor Reservation Pickup", `Recorded pickup of book (${reservation.title})`);
  return res.json({ ok: true, borrowDate, dueDate });
});

/* ---------- Transactions ---------- */

app.get("/api/transactions/mine", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  const rows = db
    .prepare(
      `SELECT t.*, b.title, b.author, u.name AS user_name, u.school_id
       FROM transactions t
       JOIN books b ON b.id = t.book_id
       JOIN users u ON u.id = t.user_id
       WHERE t.user_id = ?
       ORDER BY t.id DESC`,
    )
    .all(session.userId);

  return res.json(rows.map(mapTransaction));
});

app.get("/api/transactions", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;

  const status = req.query.status;
  let sql = `SELECT t.*, b.title, b.author, b.isbn, u.name AS user_name, u.school_id, u.phone, u.course, u.user_type
             FROM transactions t JOIN books b ON b.id = t.book_id JOIN users u ON u.id = t.user_id`;
  const params = [];
  if (status) {
    sql += " WHERE t.status = ?";
    params.push(status);
  }
  sql += " ORDER BY t.id DESC";

  const rows = db.prepare(sql).all(...params);
  return res.json(rows.map((row) => mapTransaction(row, session.role !== "staff")));
});

app.get("/api/transactions/user/:userId", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;
  if (session.role === "staff") {
    const user = db.prepare(
      "SELECT id FROM users WHERE id = ? AND role IN ('member','visitor')",
    ).get(req.params.userId);
    if (!user) return res.status(404).json({ error: "User account not found." });
  }

  const rows = db
    .prepare(
      `SELECT t.*, b.title, b.author FROM transactions t JOIN books b ON b.id = t.book_id WHERE t.user_id = ? ORDER BY t.id DESC`,
    )
    .all(req.params.userId);

  return res.json(rows.map(mapTransaction));
});

app.post("/api/transactions/borrow", async (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;
  if (session.role === "staff") return res.status(403).json({ error: "Library Staff accounts cannot submit personal borrow requests." });
  if (session.role === "visitor") return res.status(403).json({ error: "Visitor accounts must submit a reservation request instead of a borrow request." });
  const restriction = getBorrowingRestriction(session.userId);
  if (restriction) return res.status(403).json({ error: restriction });

  const bookId = req.body.bookId;
  const book = db.prepare("SELECT * FROM books WHERE id = ? AND is_archived = 0").get(bookId);
  if (!book || book.available <= 0) return res.status(400).json({ error: "This book has no available copies to borrow." });

  const user = db.prepare("SELECT user_type FROM users WHERE id = ?").get(session.userId);
  const borrowDate = todayMMDDYYYY();
  const dueDate = addDaysMMDDYYYY(getDurationForUser(user));

  const result = db
    .prepare(
      `INSERT INTO transactions (user_id, book_id, borrow_date, due_date, created_at, status)
       VALUES (?, ?, ?, ?, NOW(), 'pending')`,
    )
    .run(session.userId, bookId, borrowDate, dueDate);

  logActivity(session.userId, "Borrow Request", `Requested to borrow book (${book.title})`);

  db.prepare("DELETE FROM cart_items WHERE user_id = ? AND book_id = ?").run(session.userId, bookId);
  db.prepare("INSERT INTO notifications (user_id, title, body, date, sender_name) VALUES (?, ?, ?, ?, ?)").run(
    session.userId,
    "Borrow Request Submitted",
    `Your request to borrow ${book.title} is waiting for librarian approval.`,
    borrowDate,
    "Library System",
  );

  return res.json({ ok: true, transactionId: result.lastInsertRowid, borrowDate, dueDate });
});

app.post("/api/transactions/:id/approve", async (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;

  const txn = db.prepare("SELECT * FROM transactions WHERE id = ?").get(req.params.id);
  if (!txn || txn.status !== "pending") return res.status(400).json({ error: "Invalid transaction." });
  const restriction = getBorrowingRestriction(txn.user_id);
  if (restriction) return res.status(409).json({ error: restriction });

  const book = db.prepare("SELECT * FROM books WHERE id = ? AND is_archived = 0").get(txn.book_id);
  if (!book || book.available <= 0) return res.status(400).json({ error: "This book has no available copies to borrow." });

  const borrowDate = txn.borrow_date;
  const dueDate = txn.due_date;
  db.prepare("UPDATE transactions SET status = 'borrowed' WHERE id = ?").run(txn.id);
  db.prepare("UPDATE books SET available = available - 1 WHERE id = ?").run(txn.book_id);

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(txn.user_id);
  const lib = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);

  db.prepare("INSERT INTO notifications (user_id, title, body, date, sender_name) VALUES (?, ?, ?, ?, ?)").run(
    txn.user_id,
    "Book Borrowing Confirmation",
    `Your borrow request for ${book.title} is approved.`,
    todayMMDDYYYY(),
    lib?.name || "Library System",
  );

  logActivity(session.userId, "Borrow Approval", `Approved borrowing of book (${book.title})`);

  if (user?.phone) {
    try {
      await sendSms(
        user.phone,
        renderSmsTemplate("Borrow Confirmation", {
          Name: user.name,
          Username: user.name,
          "Borrower Name": user.name,
          "Book Title": book.title,
          Author: book.author,
          "Borrow Date": borrowDate,
          "Return Date": dueDate,
        }),
      );
    } catch (err) {
      console.error(`Borrow approved, but confirmation SMS failed for transaction ${txn.id}:`, err.message || err);
    }
  }

  return res.json({ ok: true, borrowDate, dueDate });
});

app.post("/api/transactions/:id/decline", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;

  const txn = db.prepare(
    `SELECT t.*, b.title FROM transactions t JOIN books b ON b.id = t.book_id WHERE t.id = ? AND t.status = 'pending'`,
  ).get(req.params.id);
  if (!txn) return res.status(400).json({ error: "Invalid transaction." });

  db.prepare("UPDATE transactions SET status = 'declined' WHERE id = ? AND status = 'pending'").run(req.params.id);
  const librarian = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  logActivity(session.userId, "Borrow Decline", `Declined borrow request for book (${txn.title})`);
  db.prepare("INSERT INTO notifications (user_id, title, body, date, sender_name) VALUES (?, ?, ?, ?, ?)").run(
    txn.user_id,
    "Borrow Request Declined",
    `Your request to borrow ${txn.title} was declined.`,
    todayMMDDYYYY(),
    librarian?.name || "Library System",
  );
  return res.json({ ok: true });
});

app.post("/api/transactions/:id/return", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;

  const txn = db.prepare(
    `SELECT t.*, b.title FROM transactions t JOIN books b ON b.id = t.book_id
     WHERE t.id = ? AND t.status IN ('borrowed', 'overdue', 'return_pending')`,
  ).get(req.params.id);
  if (!txn) return res.status(400).json({ error: "This transaction is not currently checked out." });

  const returnDate = dateInManila();
  const [returnYear, returnMonth, returnDay] = returnDate.split("-");
  const returnDateMMDDYYYY = `${returnMonth}/${returnDay}/${returnYear}`;
  const penaltyCostPerDay = getPenaltyCostPerDay();

  try {
    db.transaction([
      {
        sql: `UPDATE transactions SET status = 'returned', return_date = ?
              WHERE id = ? AND status IN ('borrowed', 'overdue', 'return_pending')`,
        values: [returnDateMMDDYYYY, txn.id],
        expectAffectedRows: 1,
      },
      {
        sql: "UPDATE books SET available = available + 1 WHERE id = ?",
        values: [txn.book_id],
        expectAffectedRows: 1,
      },
      {
        sql: `INSERT INTO fines (transaction_id, amount, penalty_status, payment_status)
              SELECT ?, GREATEST(
                       DATEDIFF(STR_TO_DATE(?, '%Y-%m-%d'), STR_TO_DATE(?, '%m/%d/%Y')),
                       0
                     ) * ?, 'issued', 'pending'
              WHERE STR_TO_DATE(?, '%Y-%m-%d') > STR_TO_DATE(?, '%m/%d/%Y')
                AND ? > 0
                AND NOT EXISTS (SELECT 1 FROM fines WHERE transaction_id = ?)`,
        values: [
          txn.id,
          returnDate,
          txn.due_date,
          penaltyCostPerDay,
          returnDate,
          txn.due_date,
          penaltyCostPerDay,
          txn.id,
        ],
      },
    ]);
  } catch (err) {
    if (transactionConflict(err)) return res.status(409).json({ error: "This book has already been returned or its status changed. Refresh and try again." });
    throw err;
  }
  const fine = db.prepare(
    `SELECT amount FROM fines
     WHERE transaction_id = ?
       AND LOWER(COALESCE(payment_status, 'pending')) NOT IN ('paid', 'settled')
     ORDER BY id DESC LIMIT 1`,
  ).get(txn.id);

  const lib = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  logActivity(session.userId, "Book Return Marking", `Marked book as returned (${txn.title})`);
  db.prepare("INSERT INTO notifications (user_id, title, body, date, sender_name) VALUES (?, ?, ?, ?, ?)").run(
    txn.user_id,
    "Book Return Confirmed",
    fine
      ? `Your return of ${txn.title} has been recorded. An outstanding fine of ₱${Number(fine.amount).toFixed(2)} must be settled with the library before you can request another book or reservation.`
      : `Your return of ${txn.title} has been recorded.`,
    returnDateMMDDYYYY,
    lib?.name || "Library System",
  );

  return res.json({
    ok: true,
    fineIssued: Boolean(fine),
    fineAmount: fine ? Number(fine.amount) : null,
  });
});

app.get("/api/fines", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;

  const rows = db.prepare(
    `SELECT f.id, f.amount, f.payment_status, t.due_date, b.title,
            CASE
              WHEN STR_TO_DATE(t.return_date, '%m/%d/%Y') IS NOT NULL
                THEN GREATEST(DATEDIFF(
                  STR_TO_DATE(t.return_date, '%m/%d/%Y'),
                  STR_TO_DATE(t.due_date, '%m/%d/%Y')
                ), 0)
              ELSE GREATEST(DATEDIFF(
                DATE(f.date_issued),
                STR_TO_DATE(t.due_date, '%m/%d/%Y')
              ), 0)
            END AS days_elapsed,
            u.name AS user_name, u.school_id, u.user_type,
            DATE_FORMAT(f.date_issued, '%Y-%m-%d') AS date_issued
     FROM fines f
     JOIN transactions t ON t.id = f.transaction_id
     JOIN books b ON b.id = t.book_id
     JOIN users u ON u.id = t.user_id
     WHERE LOWER(COALESCE(f.payment_status, 'pending')) NOT IN ('paid', 'settled')
     ORDER BY f.date_issued ASC, f.id ASC`,
  ).all();
  return res.json(rows.map((row) => ({
    id: row.id,
    amount: Number(row.amount) || 0,
    paymentStatus: row.payment_status || "pending",
    dueDate: row.due_date,
    daysElapsed: Number(row.days_elapsed) || 0,
    title: row.title,
    userName: row.user_name,
    schoolId: row.school_id,
    userType: row.user_type,
    dateIssued: row.date_issued,
  })));
});

app.post("/api/fines/:id/settle", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff"].includes(session.role)) return;

  const fine = db.prepare(
    `SELECT f.id, f.transaction_id, f.amount, t.user_id, b.title, u.name AS user_name
     FROM fines f
     JOIN transactions t ON t.id = f.transaction_id
     JOIN books b ON b.id = t.book_id
     JOIN users u ON u.id = t.user_id
     WHERE f.id = ?
       AND LOWER(COALESCE(f.payment_status, 'pending')) NOT IN ('paid', 'settled')`,
  ).get(req.params.id);
  if (!fine) return res.status(404).json({ error: "Outstanding fine not found." });

  const result = db.prepare(
    "UPDATE fines SET payment_status = 'paid', penalty_status = 'settled' WHERE id = ? AND LOWER(COALESCE(payment_status, 'pending')) NOT IN ('paid', 'settled')",
  ).run(fine.id);
  if (!result.changes) return res.status(409).json({ error: "This fine has already been settled." });

  logActivity(
    session.userId,
    "Fine Settlement",
    `Verified payment receipt and recorded settlement of fine for ${fine.user_name} (${fine.title}), amount ₱${Number(fine.amount).toFixed(2)}`,
  );
  return res.json({
    ok: true,
    borrowingPermissionRestored: !getBorrowingRestriction(fine.user_id),
  });
});

function mapTransaction(t, includePhone = true) {
  return {
    id: t.id,
    userId: t.user_id,
    bookId: t.book_id,
    title: t.title,
    author: t.author,
    isbn: t.isbn,
    userName: t.user_name,
    schoolId: t.school_id,
    phone: includePhone ? t.phone : undefined,
    course: t.course,
    userType: t.user_type,
    borrowDate: t.borrow_date,
    dueDate: t.due_date,
    createdAt: t.created_at,
    returnDate: t.return_date,
    status: t.status,
  };
}

const BORROWING_RESTRICTION_MESSAGE =
  "Your account has an overdue book or an unpaid fine. Return overdue books and settle outstanding fines with the library before requesting to borrow or reserve books.";

function getBorrowingRestriction(userId) {
  const user = db.prepare("SELECT role FROM users WHERE id = ?").get(userId);
  if (!user || !["member", "visitor"].includes(user.role)) return null;

  const today = dateInManila();
  const overdueLoan = db.prepare(
    `SELECT id FROM transactions
     WHERE user_id = ? AND status IN ('borrowed', 'overdue', 'return_pending')
       AND STR_TO_DATE(due_date, '%m/%d/%Y') <= STR_TO_DATE(?, '%Y-%m-%d')
     LIMIT 1`,
  ).get(userId, today);
  if (overdueLoan) return BORROWING_RESTRICTION_MESSAGE;

  const unpaidFine = db.prepare(
    `SELECT f.id
     FROM fines f
     JOIN transactions t ON t.id = f.transaction_id
     WHERE t.user_id = ?
       AND LOWER(COALESCE(f.payment_status, 'pending')) NOT IN ('paid', 'settled')
     LIMIT 1`,
  ).get(userId);
  return unpaidFine ? BORROWING_RESTRICTION_MESSAGE : null;
}

/* ---------- Users (Admin) ---------- */

app.get("/api/users", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["admin", "librarian", "staff"].includes(session.role)) return;

  const status = req.query.status;
  const userColumns = session.role === "staff"
    ? "id, name, school_id, user_type, course, role, status"
    : "*";
  let sql = `SELECT ${userColumns} FROM users WHERE role IN ('member','visitor')`;
  const params = [];
  if (status) {
    sql += " AND status = ?";
    params.push(status);
  }
  sql += " ORDER BY name";

  return res.json(db.prepare(sql).all(...params).map(publicUser));
});

app.get("/api/admin/user-directory", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const rows = db.prepare(
    `SELECT id, username, name, school_id, user_type, course, status,
            DATE_FORMAT(created_at, '%Y-%m-%d') AS created_at
     FROM users
     WHERE role <> 'admin'
     ORDER BY name`,
  ).all();
  return res.json(rows.map(publicUser));
});

app.post("/api/users/:id/approve", async (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const user = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('member','visitor')").get(req.params.id);
  if (!user) return res.status(404).json({ error: "User account not found." });
  if (user.status !== "pending") return res.status(400).json({ error: "Only pending accounts can be approved." });

  db.prepare("UPDATE users SET status = 'active' WHERE id = ?").run(user.id);
  try {
    const message = renderSmsTemplate("Account Creation Approval", {
      Name: user.name,
    });
    const smsResult = await sendSms(normalizePhone(user.phone), message);
    return res.json({ ok: true, sms: smsResult.mock ? "demo" : "sent" });
  } catch (err) {
    return res.status(502).json({ error: `Account approved, but SMS notification failed: ${err.message}` });
  }
});

app.post("/api/users/:id/deactivate", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const user = db
    .prepare("SELECT id, status FROM users WHERE id = ? AND role IN ('member','visitor')")
    .get(req.params.id);
  if (!user) return res.status(404).json({ error: "User account not found." });
  if (user.status === "deactivated") return res.json({ ok: true, alreadyDeactivated: true });

  const result = db
    .prepare("UPDATE users SET status = 'deactivated' WHERE id = ? AND role IN ('member','visitor')")
    .run(req.params.id);
  if (!result.changes) return res.status(409).json({ error: "User account could not be deactivated." });
  return res.json({ ok: true });
});

app.post("/api/users/:id/activate", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const user = db
    .prepare("SELECT id, status FROM users WHERE id = ? AND role IN ('member','visitor')")
    .get(req.params.id);
  if (!user) return res.status(404).json({ error: "User account not found." });
  if (user.status === "active") return res.json({ ok: true, alreadyActive: true });

  const result = db
    .prepare("UPDATE users SET status = 'active' WHERE id = ? AND role IN ('member','visitor')")
    .run(req.params.id);
  if (!result.changes) return res.status(409).json({ error: "User account could not be activated." });
  return res.json({ ok: true });
});

function createManagedAccount(req, res, role) {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const name = String(req.body.name || "").trim();
  const schoolId = String(req.body.schoolId || "").trim();
  const password = String(req.body.password || "");
  const confirmPassword = String(req.body.confirmPassword || "");
  const email = String(req.body.email || "").trim().toLowerCase();
  const username = role === "staff"
    ? email.split("@")[0]
    : String(req.body.username || "").trim();
  if (!username || !name || !schoolId || !email || !password.trim() || !confirmPassword.trim()) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const duplicateFields = {};
  if (db.prepare("SELECT id FROM users WHERE lower(email) = lower(?) LIMIT 1").get(email)) {
    duplicateFields.email = "Email address already in use.";
  }
  if (db.prepare("SELECT id FROM users WHERE lower(username) = lower(?) LIMIT 1").get(username)) {
    if (role === "staff") {
      duplicateFields.email = "The part of this email address before @ is already in use as a username.";
    } else {
      duplicateFields.username = "Username already in use.";
    }
  }
  if (db.prepare(
    "SELECT id FROM users WHERE school_id IS NOT NULL AND replace(upper(school_id), ' ', '') = replace(upper(?), ' ', '') LIMIT 1",
  ).get(schoolId)) {
    duplicateFields.schoolId = "ID number already in use.";
  }
  if (Object.keys(duplicateFields).length > 0) {
    return res.status(409).json({
      error: "Some account information is already in use.",
      fieldErrors: duplicateFields,
    });
  }

  const result = db
    .prepare(
      `INSERT INTO users (username, email, password, name, school_id, user_type, role, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'active')`,
    )
    .run(
      username,
      email,
      bcrypt.hashSync(password, 10),
      name,
      schoolId,
      role === "librarian" ? "Librarian" : "Staff",
      role,
    );

  return res.json({ ok: true, id: result.lastInsertRowid });
}

app.post("/api/librarians", (req, res) => createManagedAccount(req, res, "librarian"));

app.post("/api/staff", (req, res) => createManagedAccount(req, res, "staff"));

app.get("/api/librarians", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const rows = db.prepare("SELECT id, username, name, school_id, email, status FROM users WHERE role = 'librarian'").all();
  return res.json(rows.map(publicUser));
});

app.post("/api/users/:id/notifications", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  const title = String(req.body.title || "").trim();
  const body = String(req.body.body || "").trim();
  if (!title || !body) return res.status(400).json({ error: "Message title and body are required." });

  const user = db
    .prepare("SELECT id FROM users WHERE id = ? AND role IN ('member','visitor') AND status = 'active'")
    .get(req.params.id);
  if (!user) return res.status(404).json({ error: "Active user account not found." });

  const sender = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  const notification = db.prepare(
    "INSERT INTO notifications (user_id, title, body, date, sender_id, sender_name) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(user.id, title, body, todayMMDDYYYY(), session.userId, sender?.name || "Library System");
  const thread = db.prepare(
    `INSERT INTO contact_messages
      (user_id, user_name, message, sender_id, sender_role, source_notification_id)
     VALUES (?, ?, ?, ?, 'librarian', ?)`,
  ).run(user.id, sender?.name || "Library System", body, session.userId, notification.lastInsertRowid);
  db.prepare("UPDATE contact_messages SET conversation_id = ? WHERE id = ?")
    .run(thread.lastInsertRowid, thread.lastInsertRowid);
  return res.json({ ok: true, threadId: thread.lastInsertRowid });
});

app.post("/api/contact-messages/:id/reply", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "member", "visitor"].includes(session.role)) return;

  const threadId = Number(req.params.id);
  const body = String(req.body.body || "").trim();
  if (!Number.isInteger(threadId) || threadId < 1 || !body || body.length > 500) {
    return res.status(400).json({ error: "A valid message and reply body are required." });
  }

  const thread = db.prepare(
    "SELECT id, user_id FROM contact_messages WHERE id = ? AND conversation_id = id",
  ).get(threadId);
  if (!thread) return res.status(404).json({ error: "The message thread could not be found." });
  if (session.role !== "librarian" && Number(thread.user_id) !== Number(session.userId)) {
    return res.status(403).json({ error: "You do not have access to this message thread." });
  }
  const recipient = session.role === "librarian"
    ? db
      .prepare("SELECT id FROM users WHERE id = ? AND role IN ('member','visitor') AND status = 'active'")
      .get(thread.user_id)
    : null;
  if (session.role === "librarian" && !recipient) {
    return res.status(404).json({ error: "The message sender does not have an active user account." });
  }
  const previousMessage = db.prepare(
    "SELECT id FROM contact_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 1",
  ).get(thread.id);
  if (!previousMessage) return res.status(404).json({ error: "The message thread has no messages to reply to." });

  const sender = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  let notificationId = null;
  if (session.role === "librarian") {
    const notification = db.prepare(
      `INSERT INTO notifications
        (user_id, title, body, date, sender_id, sender_name, reply_to_contact_message_id)
       VALUES (?, 'Replied', ?, CURRENT_DATE, ?, ?, ?)`,
    ).run(recipient.id, body, session.userId, sender?.name || "Library System", thread.id);
    notificationId = notification.lastInsertRowid;
  }
  db.prepare(
    `INSERT INTO contact_messages
      (user_id, user_name, message, conversation_id, reply_to_message_id, sender_id, sender_role, source_notification_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    thread.user_id,
    sender?.name || "Library User",
    body,
    thread.id,
    previousMessage.id,
    session.userId,
    session.role,
    notificationId,
  );
  return res.json({ ok: true });
});

/* ---------- Notifications ---------- */

app.get("/api/librarian/notifications/sent", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  const rows = db.prepare(
    `SELECT n.id, n.title, n.body, DATE_FORMAT(n.date, '%Y-%m-%d') AS date,
            DATE_FORMAT(n.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
            n.sender_name, u.name AS recipient_name
     FROM notifications n
     LEFT JOIN contact_messages thread_root
       ON thread_root.source_notification_id = n.id
      AND thread_root.conversation_id = thread_root.id
     JOIN users u ON u.id = n.user_id
     WHERE (
       n.sender_id = ?
       OR (n.sender_id IS NULL AND n.title = 'Message from the Library'
           AND n.sender_name = (SELECT name FROM users WHERE id = ?))
     ) AND n.announcement_id IS NULL
       AND n.reply_to_contact_message_id IS NULL
       AND NOT EXISTS (
         SELECT 1 FROM contact_messages thread_message
         WHERE thread_message.source_notification_id = n.id
       )
     ORDER BY n.id DESC`,
  ).all(session.userId, session.userId);
  return res.json(rows);
});

app.get("/api/librarian/notifications/system", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  const borrowRequests = db.prepare(
    `SELECT t.id, t.borrow_date, t.due_date,
            DATE_FORMAT(t.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
            u.name AS requester_name, u.school_id,
            b.title AS book_title
     FROM transactions t
     JOIN users u ON u.id = t.user_id
     JOIN books b ON b.id = t.book_id
     WHERE t.status = 'pending'
     ORDER BY t.id DESC`,
  ).all();
  return res.json({ borrowRequests });
});

app.get("/api/notifications", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  const rows = db
    .prepare(
      `SELECT n.id, n.title, n.body, DATE_FORMAT(n.date, '%Y-%m-%d') AS date,
              n.is_read, n.announcement_id, n.reply_to_contact_message_id,
              thread_root.id AS thread_id,
              DATE_FORMAT(n.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
              CASE
                WHEN linked_announcement.id IS NOT NULL AND announcement_sender.role = 'librarian'
                  THEN 'Golden Gate Colleges Library'
                WHEN linked_announcement.id IS NOT NULL
                  THEN announcement_sender.name
                ELSE COALESCE(n.sender_name, announcement_sender.name)
              END AS sender_name,
              linked_announcement.audience AS audience,
              announcement_sender.role AS announcement_creator_role,
              CASE
                WHEN notification_sender.role = 'librarian' OR thread_root.sender_role = 'librarian' THEN 'Librarian'
                WHEN notification_sender.role = 'visitor' OR notification_sender.user_type = 'Visitor' THEN 'Visitor'
                WHEN notification_sender.user_type IN ('Faculty', 'Teacher') THEN 'Faculty'
                WHEN notification_sender.user_type = 'Student' THEN 'Student'
                ELSE NULL
              END AS sender_type
       FROM notifications n
       LEFT JOIN users notification_sender ON notification_sender.id = n.sender_id
       LEFT JOIN announcements linked_announcement ON linked_announcement.id = n.announcement_id
       LEFT JOIN users announcement_sender ON announcement_sender.id = linked_announcement.created_by
       LEFT JOIN contact_messages thread_root ON thread_root.id = n.reply_to_contact_message_id
       WHERE n.user_id = ? AND n.date <= CURRENT_DATE
       UNION ALL
       SELECT CONCAT('announcement-', a.id) AS id, a.title, a.body,
              DATE_FORMAT(a.publication_date, '%Y-%m-%d') AS date,
              0 AS is_read, a.id AS announcement_id, NULL AS reply_to_contact_message_id,
              NULL AS thread_id, NULL AS created_at,
              CASE WHEN publisher.role = 'librarian' THEN 'Golden Gate Colleges Library' ELSE publisher.name END AS sender_name,
              a.audience AS audience,
              publisher.role AS announcement_creator_role,
              CASE
                WHEN publisher.role = 'librarian' THEN 'Librarian'
                WHEN publisher.role = 'visitor' OR publisher.user_type = 'Visitor' THEN 'Visitor'
                WHEN publisher.user_type IN ('Faculty', 'Teacher') THEN 'Faculty'
                WHEN publisher.user_type = 'Student' THEN 'Student'
                ELSE NULL
              END AS sender_type
       FROM announcements a
       JOIN users u ON u.id = ?
       LEFT JOIN users publisher ON publisher.id = a.created_by
       WHERE a.publication_date <= CURRENT_DATE
         AND u.status = 'active'
         AND (
           (a.audience = 'everyone' AND u.role IN ('member', 'visitor'))
           OR (a.audience = 'visitors' AND u.role = 'visitor')
           OR (a.audience = 'students' AND u.user_type = 'Student' AND u.role IN ('member', 'visitor'))
           OR (a.audience = 'faculty' AND u.user_type IN ('Faculty', 'Teacher') AND u.role IN ('member', 'visitor'))
         )
         AND NOT EXISTS (
           SELECT 1 FROM notifications existing
           WHERE existing.user_id = u.id AND existing.announcement_id = a.id
         )
       ORDER BY date DESC, id DESC`,
    )
    .all(session.userId, session.userId);

  return res.json(
    rows.map((n) => ({
      id: n.id,
      announcementId: n.announcement_id,
      date: n.date,
      createdAt: n.created_at,
      sender: n.sender_name || "System Notification",
      senderType: n.sender_type,
      audience: n.audience,
      announcementCreatorRole: n.announcement_creator_role,
      title: n.title,
      body: n.body,
      threadId: n.reply_to_contact_message_id || n.thread_id,
      read: !!n.is_read,
    })),
  );
});

app.get("/api/contact-messages", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;

  const rows = db
    .prepare(
      `SELECT root.id, root.user_id, root.user_name, root.message,
              latest.id AS last_message_id,
              latest.user_name AS latest_sender_name,
              CASE
                WHEN latest_sender.role = 'librarian' THEN 'Librarian'
                WHEN latest_sender.role = 'visitor' OR latest_sender.user_type = 'Visitor' THEN 'Visitor'
                WHEN latest_sender.user_type IN ('Faculty', 'Teacher') THEN 'Faculty'
                WHEN latest_sender.user_type = 'Student' THEN 'Student'
                ELSE NULL
              END AS sender_type,
              latest.message AS latest_message,
              latest.sender_role AS latest_sender_role,
              source_notification.title AS notification_title,
              DATE_FORMAT(latest.created_at, '%Y-%m-%d %H:%i:%s') AS created_at
       FROM contact_messages root
       JOIN contact_messages latest
         ON latest.id = (
           SELECT candidate.id FROM contact_messages candidate
           WHERE candidate.conversation_id = root.id
           ORDER BY candidate.id DESC LIMIT 1
         )
       LEFT JOIN users latest_sender ON latest_sender.id = latest.sender_id
       LEFT JOIN notifications source_notification ON source_notification.id = root.source_notification_id
       WHERE root.conversation_id = root.id
       ORDER BY latest.id DESC`,
    )
    .all();
  return res.json(rows.map((row) => {
    const { reason } = splitContactMessage(row.message);
    const lastMessage = row.last_message_id === row.id
      ? splitContactMessage(row.latest_message).body
      : row.latest_message;
    return {
      id: `thread-${row.id}-${row.last_message_id}`,
      threadId: row.id,
      contactMessageId: row.id,
      userId: row.user_id,
      from: row.latest_sender_name || row.user_name || "Library User",
      senderType: row.sender_type || (row.latest_sender_role === "librarian" ? "Librarian" : null),
      reason: row.notification_title || reason,
      message: lastMessage,
      date: row.created_at,
      createdAt: row.created_at,
    };
  }));
});

app.get("/api/contact-messages/sent", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["member", "visitor"].includes(session.role)) return;

  const rows = db.prepare(
    `SELECT root.id, latest.message,
            DATE_FORMAT(latest.created_at, '%Y-%m-%d %H:%i:%s') AS created_at
     FROM contact_messages root
     JOIN contact_messages latest
       ON latest.id = (
         SELECT candidate.id FROM contact_messages candidate
         WHERE candidate.conversation_id = root.id
         ORDER BY candidate.id DESC LIMIT 1
       )
     WHERE root.user_id = ?
       AND root.conversation_id = root.id
       AND EXISTS (
         SELECT 1 FROM contact_messages authored
         WHERE authored.conversation_id = root.id AND authored.sender_id = ?
       )
     ORDER BY latest.id DESC`,
  ).all(session.userId, session.userId);
  return res.json(rows.map((row) => ({
    id: row.id,
    threadId: row.id,
    message: row.message,
    date: row.created_at,
  })));
});

app.get("/api/contact-messages/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "member", "visitor"].includes(session.role)) return;

  const threadId = Number(req.params.id);
  if (!Number.isInteger(threadId) || threadId < 1) {
    return res.status(400).json({ error: "Invalid message thread." });
  }

  const root = db.prepare(
    `SELECT root.id, root.user_id, root.message, root.user_name,
            source_notification.title AS notification_title
     FROM contact_messages root
     LEFT JOIN notifications source_notification
       ON source_notification.id = root.source_notification_id
     WHERE root.id = ? AND root.conversation_id = root.id`,
  ).get(threadId);
  if (!root) return res.status(404).json({ error: "Message thread not found." });
  if (session.role !== "librarian" && Number(root.user_id) !== Number(session.userId)) {
    return res.status(403).json({ error: "You do not have access to this message thread." });
  }

  const messages = db.prepare(
    `SELECT cm.id, cm.message, cm.sender_role, cm.user_name, cm.reply_to_message_id,
            parent.user_name AS reply_to_sender_name,
            CASE
              WHEN parent_sender.role = 'librarian' THEN 'Librarian'
              WHEN parent_sender.role = 'visitor' OR parent_sender.user_type = 'Visitor' THEN 'Visitor'
              WHEN parent_sender.user_type IN ('Faculty', 'Teacher') THEN 'Faculty'
              WHEN parent_sender.user_type = 'Student' THEN 'Student'
              WHEN parent.sender_role = 'librarian' THEN 'Librarian'
              WHEN parent.sender_role = 'visitor' THEN 'Visitor'
              ELSE NULL
            END AS reply_to_sender_type,
            DATE_FORMAT(cm.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
            CASE
              WHEN sender.role = 'librarian' THEN 'Librarian'
              WHEN sender.role = 'visitor' OR sender.user_type = 'Visitor' THEN 'Visitor'
              WHEN sender.user_type IN ('Faculty', 'Teacher') THEN 'Faculty'
              WHEN sender.user_type = 'Student' THEN 'Student'
              WHEN cm.sender_role = 'librarian' THEN 'Librarian'
              WHEN cm.sender_role = 'visitor' THEN 'Visitor'
              ELSE NULL
            END AS sender_type
     FROM contact_messages cm
     LEFT JOIN users sender ON sender.id = cm.sender_id
     LEFT JOIN contact_messages parent ON parent.id = cm.reply_to_message_id
     LEFT JOIN users parent_sender ON parent_sender.id = parent.sender_id
     WHERE cm.conversation_id = ?
     ORDER BY cm.id ASC`,
  ).all(root.id);
  const topic = root.notification_title || splitContactMessage(root.message).reason;
  return res.json({
    id: root.id,
    userId: root.user_id,
    topic,
    messages: messages.map((message) => ({
      id: message.id,
      sender: message.user_name || root.user_name || "Library User",
      senderType: message.sender_type,
      replyTo: message.reply_to_message_id
        ? {
          sender: message.reply_to_sender_name || root.user_name || "Library User",
          senderType: message.reply_to_sender_type,
        }
        : null,
      body: message.id === root.id
        ? splitContactMessage(message.message).body
        : message.message,
      createdAt: message.created_at,
    })),
  });
});

app.put("/api/notifications/:id/read", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  const notificationId = String(req.params.id);
  const announcementMatch = /^announcement-(\d+)$/.exec(notificationId);
  if (announcementMatch) {
    const announcementId = Number(announcementMatch[1]);
    db.prepare(
      `INSERT INTO notifications (user_id, title, body, date, announcement_id, is_read, sender_name, created_at)
       SELECT u.id, a.title, a.body, a.publication_date, a.id, 1, publisher.name, NULL
       FROM announcements a
       JOIN users u ON u.id = ?
       LEFT JOIN users publisher ON publisher.id = a.created_by
       WHERE a.id = ?
         AND a.publication_date <= CURRENT_DATE
         AND u.status = 'active'
         AND (
           (a.audience = 'everyone' AND u.role IN ('member', 'visitor'))
           OR (a.audience = 'visitors' AND u.role = 'visitor')
           OR (a.audience = 'students' AND u.user_type = 'Student' AND u.role IN ('member', 'visitor'))
           OR (a.audience = 'faculty' AND u.user_type IN ('Faculty', 'Teacher') AND u.role IN ('member', 'visitor'))
         )
         AND NOT EXISTS (
           SELECT 1 FROM notifications existing
           WHERE existing.user_id = u.id AND existing.announcement_id = a.id
         )`,
    ).run(session.userId, announcementId);

    const notification = db.prepare(
      "SELECT id FROM notifications WHERE user_id = ? AND announcement_id = ?",
    ).get(session.userId, announcementId);
    if (!notification) return res.status(404).json({ error: "Notification not found." });
    db.prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?")
      .run(notification.id, session.userId);
    return res.json({ ok: true });
  }

  if (!/^\d+$/.test(notificationId)) {
    return res.status(400).json({ error: "Invalid notification ID." });
  }
  const notification = db.prepare(
    "SELECT id FROM notifications WHERE id = ? AND user_id = ?",
  ).get(notificationId, session.userId);
  if (!notification) return res.status(404).json({ error: "Notification not found." });
  db.prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?")
    .run(notification.id, session.userId);
  return res.json({ ok: true });
});

app.delete("/api/notifications/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  db.prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?").run(req.params.id, session.userId);
  return res.json({ ok: true });
});

/* ---------- Dashboard & Reports ---------- */

app.get("/api/dashboard/stats", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "staff", "admin"].includes(session.role)) return;

  const totalBooks = db.prepare("SELECT COALESCE(SUM(total),0) AS n FROM books WHERE is_archived = 0").get().n;
  const available = db.prepare("SELECT COALESCE(SUM(available),0) AS n FROM books WHERE is_archived = 0").get().n;
  const loanStats = db.prepare(
    `SELECT COUNT(*) AS borrowed,
            COALESCE(SUM(
              STR_TO_DATE(due_date, '%m/%d/%Y') <= STR_TO_DATE(?, '%Y-%m-%d')
            ), 0) AS overdue
     FROM transactions
     WHERE status IN ('borrowed', 'overdue', 'return_pending')`,
  ).get(dateInManila());
  const borrowed = Number(loanStats.borrowed) || 0;
  const overdue = Number(loanStats.overdue) || 0;
  const totalUsers = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role IN ('member','visitor') AND status = 'active'").get().n;
  const students = db.prepare("SELECT COUNT(*) AS n FROM users WHERE user_type = 'Student' AND status = 'active'").get().n;
  const faculty = db.prepare("SELECT COUNT(*) AS n FROM users WHERE user_type IN ('Teacher','Faculty') AND status = 'active'").get().n;
  const visitors = db.prepare("SELECT COUNT(*) AS n FROM users WHERE user_type = 'Visitor' AND status = 'active'").get().n;
  const librarians = db.prepare("SELECT COUNT(*) AS n FROM users WHERE user_type = 'Librarian' AND status = 'active'").get().n;
  const libraryStaff = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'staff' AND status = 'active'").get().n;
  const administrators = db.prepare("SELECT COUNT(*) AS n FROM users WHERE user_type = 'Administrator' AND status = 'active'").get().n;
  const pendingUsers = db.prepare("SELECT COUNT(*) AS n FROM users WHERE status = 'pending'").get().n;

  const stats = {
    totalBooks,
    available,
    borrowed,
    overdue,
    totalUsers,
    students,
    faculty,
    visitors,
    librarians,
    libraryStaff,
    administrators,
    pendingUsers,
    bookBorrowers: borrowed,
  };
  if (session.role === "staff") delete stats.pendingUsers;
  return res.json(stats);
});

app.get("/api/reports/:type", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "admin"].includes(session.role)) return;

  const type = req.params.type;
  const period = String(req.query.period || "all");
  let periodStart = null;
  let periodEnd = null;
  if (period !== "all") {
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(period)) {
      return res.status(400).json({ error: "Invalid report period." });
    }
    const start = new Date(`${period}-01T00:00:00.000Z`);
    if (Number.isNaN(start.getTime()) || start.toISOString().slice(0, 7) !== period) {
      return res.status(400).json({ error: "Invalid report period." });
    }
    periodStart = start.toISOString().slice(0, 10);
    start.setUTCMonth(start.getUTCMonth() + 1);
    periodEnd = start.toISOString().slice(0, 10);
  }

  if (type === "users") {
    const rows = db
      .prepare("SELECT school_id, username, name, email, phone, user_type, course FROM users WHERE role IN ('member','visitor') AND status = 'active' ORDER BY name")
      .all();
    return res.json(rows.map((r) => ({
      sid: r.school_id,
      username: r.username,
      name: r.name,
      email: r.email,
      phone: r.phone,
      type: r.user_type,
      course: r.course,
    })));
  }

  if (type === "inventory") {
    const rows = db.prepare(
      `SELECT b.isbn, b.title, b.author,
              DATE_FORMAT(b.date_added, '%Y-%m-%d') AS date_added,
              b.available, b.total,
              COALESCE(c.borrowed, 0) AS borrowed
       FROM books b
       LEFT JOIN (
         SELECT book_id, COUNT(*) AS borrowed
         FROM transactions
         WHERE status IN ('borrowed', 'overdue', 'return_pending')
         GROUP BY book_id
       ) c ON c.book_id = b.id
       WHERE b.is_archived = 0
       ORDER BY b.title`,
    ).all();
    return res.json(rows.map((r) => ({
      isbn: r.isbn,
      title: r.title,
      author: r.author,
      dateAdded: r.date_added,
      available: Number(r.available) || 0,
      borrowed: Number(r.borrowed) || 0,
      total: Number(r.total) || 0,
    })));
  }

  if (type === "overdue") {
    const rows = db
      .prepare(
        `SELECT b.isbn, b.title, b.author, u.name, u.school_id, t.borrow_date, t.due_date, u.phone
         FROM transactions t JOIN users u ON u.id = t.user_id JOIN books b ON b.id = t.book_id
        WHERE t.status IN ('borrowed', 'overdue', 'return_pending')
          AND STR_TO_DATE(t.due_date, '%m/%d/%Y') <= CURDATE()`,
      )
      .all();
    return res.json(
      rows.map((r) => ({
        isbn: r.isbn,
        title: r.title,
        book: r.title,
        author: r.author,
        user: r.name,
        sid: r.school_id,
        borrowed: r.borrow_date,
        due: r.due_date,
        phone: r.phone,
      })),
    );
  }

  if (type === "borrowed") {
    const rows = db
      .prepare(
        `SELECT b.isbn, b.title, b.author,
                COUNT(*) AS count,
                SUM(
                  STR_TO_DATE(t.due_date, '%m/%d/%Y') <= CURDATE()
                ) AS overdue
         FROM transactions t JOIN books b ON b.id = t.book_id
         WHERE t.status IN ('borrowed','overdue','return_pending')
         GROUP BY b.id, b.isbn, b.title, b.author
         ORDER BY count DESC, b.title`,
      )
      .all();
    return res.json(rows.map((r) => ({
      isbn: r.isbn,
      title: r.title,
      author: r.author,
      count: Number(r.count) || 0,
      overdue: Number(r.overdue) || 0,
      returnPending: Number(r.count) || 0,
    })));
  }

  if (type === "circulation") {
    const periodFilter = period === "all"
      ? ""
      : `AND (
           (STR_TO_DATE(t.borrow_date, '%m/%d/%Y') >= ? AND STR_TO_DATE(t.borrow_date, '%m/%d/%Y') < ?)
           OR (STR_TO_DATE(t.return_date, '%m/%d/%Y') >= ? AND STR_TO_DATE(t.return_date, '%m/%d/%Y') < ?)
         )`;
    const params = period === "all"
      ? []
      : [periodStart, periodEnd, periodStart, periodEnd];
    const rows = db.prepare(
      `SELECT u.school_id, u.name AS borrower, b.title,
              t.borrow_date, t.return_date, t.status
       FROM transactions t
       JOIN users u ON u.id = t.user_id
       JOIN books b ON b.id = t.book_id
       WHERE t.status IN ('borrowed', 'overdue', 'return_pending', 'returned')
         ${periodFilter}
       ORDER BY STR_TO_DATE(t.borrow_date, '%m/%d/%Y') DESC`,
    ).all(...params);
    return res.json(rows.map((r) => ({
      sid: r.school_id,
      borrower: r.borrower,
      title: r.title,
      dateBorrowed: r.borrow_date,
      dateReturned: r.return_date,
    })));
  }

  if (type === "popular") {
    const rows = period === "all"
      ? db.prepare(
        `SELECT b.isbn, b.title, b.author, COUNT(*) AS count
         FROM transactions t JOIN books b ON b.id = t.book_id
         WHERE t.status IN ('borrowed', 'overdue', 'return_pending', 'returned')
         GROUP BY b.id, b.isbn, b.title, b.author
         ORDER BY count DESC, b.title`,
      ).all()
      : db.prepare(
        `SELECT b.isbn, b.title, b.author, COUNT(*) AS count
         FROM transactions t JOIN books b ON b.id = t.book_id
         WHERE t.status IN ('borrowed', 'overdue', 'return_pending', 'returned')
           AND STR_TO_DATE(t.borrow_date, '%m/%d/%Y') >= ?
           AND STR_TO_DATE(t.borrow_date, '%m/%d/%Y') < ?
         GROUP BY b.id, b.isbn, b.title, b.author
         ORDER BY count DESC, b.title`,
      ).all(periodStart, periodEnd);
    return res.json(rows.map((r) => ({
      isbn: r.isbn,
      title: r.title,
      author: r.author,
      count: Number(r.count) || 0,
    })));
  }

  if (type === "user-status") {
    const rows = db.prepare(
      `SELECT school_id, username, name, user_type, course, status,
              DATE_FORMAT(created_at, '%Y-%m-%d') AS created_at
       FROM users
       WHERE role IN ('member', 'visitor')
       ORDER BY FIELD(status, 'pending', 'active', 'deactivated'), name`,
    ).all();
    return res.json(rows.map((r) => ({
      sid: r.school_id,
      username: r.username,
      name: r.name,
      type: r.user_type,
      course: r.course,
      status: r.status,
      createdAt: r.created_at,
    })));
  }

  return res.status(400).json({ error: "Unknown report type." });
});

app.get("/api/activity-log", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const queryValue = (value) => typeof value === "string" ? value.trim() : "";
  const userType = queryValue(req.query.userType);
  const validUserTypes = ["Librarian", "Library Staff", "Faculty", "Student", "Visitor"];
  if (userType && !validUserTypes.includes(userType)) {
    return res.status(400).json({ error: "Invalid activity log user type." });
  }
  const dateRange = queryValue(req.query.dateRange) || "all";
  const validDateRanges = ["all", "today", "last7", "last30", "custom"];
  if (!validDateRanges.includes(dateRange)) {
    return res.status(400).json({ error: "Invalid activity log date range." });
  }
  const dateFrom = queryValue(req.query.dateFrom);
  const dateTo = queryValue(req.query.dateTo);
  const isValidDate = (value) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(`${value}T00:00:00.000Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  };
  if (dateRange === "custom" && (!isValidDate(dateFrom) || !isValidDate(dateTo) || dateFrom > dateTo)) {
    return res.status(400).json({ error: "A valid custom activity log date range is required." });
  }
  const action = queryValue(req.query.action);
  const validActions = [
    "Login",
    "Logout",
    "Account Registration",
    "Profile Update",
    "Borrow Request",
    "Borrow Approval",
    "Borrow Decline",
    "Book Return Marking",
    "Fine Settlement",
    "Catalog Update",
    "Policy Update",
    "Calendar Update",
  ];
  if (action && !validActions.includes(action)) {
    return res.status(400).json({ error: "Invalid activity log action." });
  }
  const search = queryValue(req.query.search);
  if (search.length > 200) {
    return res.status(400).json({ error: "Activity log search must be 200 characters or fewer." });
  }

  const conditions = ["COALESCE(actor_type, 'Librarian') NOT IN ('Admin', 'Administrator')"];
  const params = [];
  if (userType) {
    if (userType === "Library Staff") {
      conditions.push("COALESCE(actor_type, 'Librarian') IN ('Library Staff', 'Staff')");
    } else {
      conditions.push("COALESCE(actor_type, 'Librarian') = ?");
      params.push(userType);
    }
  }
  if (dateRange === "today") {
    conditions.push("DATE(created_at) = CURRENT_DATE");
  } else if (dateRange === "last7") {
    conditions.push("created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 6 DAY) AND created_at < DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY)");
  } else if (dateRange === "last30") {
    conditions.push("created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 29 DAY) AND created_at < DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY)");
  } else if (dateRange === "custom") {
    conditions.push("created_at >= ? AND created_at < DATE_ADD(?, INTERVAL 1 DAY)");
    params.push(dateFrom, dateTo);
  }
  if (action) {
    conditions.push("action = ?");
    params.push(action);
  }
  if (search) {
    conditions.push(
      "LOCATE(LOWER(?), LOWER(CONCAT_WS(' ', COALESCE(actor_name, librarian_name), action, details))) > 0",
    );
    params.push(search);
  }
  const rows = db.prepare(
    `SELECT COALESCE(actor_name, librarian_name) AS actor_name,
            CASE COALESCE(actor_type, 'Librarian')
              WHEN 'Staff' THEN 'Library Staff'
              ELSE COALESCE(actor_type, 'Librarian')
            END AS actor_type, action, details,
            DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') AS datetime
     FROM activity_log
     WHERE ${conditions.join(" AND ")}
     ORDER BY created_at DESC, id DESC`,
  ).all(...params);
  return res.json(rows.map((r) => ({
    datetime: r.datetime,
    user: r.actor_name,
    userType: r.actor_type,
    action: r.action,
    details: r.details,
  })));
});

app.get("/api/announcements", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "admin"].includes(session.role)) return;

  const rows = db.prepare(
    `SELECT a.id, a.title, a.body, a.created_by,
            creator.name AS creator_name, creator.role AS creator_role,
            DATE_FORMAT(a.date, '%Y-%m-%d') AS date, a.audience,
            DATE_FORMAT(a.publication_date, '%Y-%m-%d') AS publication_date
     FROM announcements a
     LEFT JOIN users creator ON creator.id = a.created_by
     ORDER BY a.id DESC`,
  ).all();
  return res.json(rows.map((row) => ({
    id: `announcement-${row.id}`,
    announcementId: row.id,
    creatorId: row.created_by,
    creatorRole: row.creator_role,
    creatorName: row.creator_name,
    creatorLabel: row.creator_role === "librarian"
      ? "Golden Gate Colleges Library"
      : row.creator_name || "Library System",
    title: row.title,
    body: row.body,
    date: row.date,
    audience: row.audience,
    publicationDate: row.publication_date,
  })));
});

app.post("/api/announcements", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "admin"].includes(session.role)) return;

  const title = String(req.body.title || "").trim();
  const body = String(req.body.body || "").trim();
  const audience = String(req.body.audience || "everyone").trim().toLowerCase();
  const publicationDate = String(req.body.publicationDate || "").trim();
  if (!title || !body || !publicationDate) return res.status(400).json({ error: "Title, message, and publication date are required." });
  if (!["everyone", "students", "faculty", "visitors"].includes(audience)) {
    return res.status(400).json({ error: "Invalid announcement audience." });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(publicationDate)) {
    return res.status(400).json({ error: "Publication date must be valid." });
  }
  const today = new Date();
  const todayDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  if (publicationDate < todayDate) {
    return res.status(400).json({ error: "Publication date cannot be in the past." });
  }
  const result = db.prepare(
    "INSERT INTO announcements (title, body, date, audience, publication_date, created_by) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(title, body, publicationDate, audience, publicationDate, session.userId);
  const audienceClause = audience === "everyone"
    ? "role IN ('member', 'visitor')"
    : audience === "visitors"
      ? "role = 'visitor'"
      : audience === "faculty"
        ? "role IN ('member', 'visitor') AND user_type IN ('Faculty', 'Teacher')"
        : "role IN ('member', 'visitor') AND user_type = 'Student'";
  const recipients = db.prepare(`SELECT id FROM users WHERE status = 'active' AND ${audienceClause}`).all();
  const sender = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  const notify = db.prepare(
    "INSERT INTO notifications (user_id, title, body, date, announcement_id, sender_name, created_at) VALUES (?, ?, ?, ?, ?, ?, NULL)",
  );
  recipients.forEach((recipient) => notify.run(
    recipient.id, title, body, publicationDate, result.lastInsertRowid, sender?.name || "Library System",
  ));
  return res.json({ ok: true, id: result.lastInsertRowid });
});

app.put("/api/announcements/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || !["librarian", "admin"].includes(session.role)) return;

  const title = String(req.body.title || "").trim();
  const body = String(req.body.body || "").trim();
  const audience = String(req.body.audience || "everyone").trim().toLowerCase();
  const publicationDate = String(req.body.publicationDate || "").trim();
  if (!title || !body || !publicationDate) return res.status(400).json({ error: "Title, message, and publication date are required." });
  if (!["everyone", "students", "faculty", "visitors"].includes(audience)) return res.status(400).json({ error: "Invalid announcement audience." });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(publicationDate)) return res.status(400).json({ error: "Publication date must be valid." });
  const today = new Date();
  const todayDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  if (publicationDate < todayDate) return res.status(400).json({ error: "Publication date cannot be in the past." });

  const announcement = db.prepare("SELECT id, created_by FROM announcements WHERE id = ?").get(req.params.id);
  if (!announcement) return res.status(404).json({ error: "Announcement not found." });
  if (Number(announcement.created_by) !== Number(session.userId)) {
    return res.status(403).json({ error: "You can only edit announcements you created." });
  }

  db.prepare("UPDATE announcements SET title = ?, body = ?, date = ?, audience = ?, publication_date = ? WHERE id = ?")
    .run(title, body, publicationDate, audience, publicationDate, req.params.id);
  db.prepare("DELETE FROM notifications WHERE announcement_id = ?").run(req.params.id);

  const audienceClause = audience === "everyone"
    ? "role IN ('member', 'visitor')"
    : audience === "visitors"
      ? "role = 'visitor'"
      : audience === "faculty"
        ? "role IN ('member', 'visitor') AND user_type IN ('Faculty', 'Teacher')"
        : "role IN ('member', 'visitor') AND user_type = 'Student'";
  const recipients = db.prepare(`SELECT id FROM users WHERE status = 'active' AND ${audienceClause}`).all();
  const sender = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  const notify = db.prepare(
    "INSERT INTO notifications (user_id, title, body, date, announcement_id, sender_name, created_at) VALUES (?, ?, ?, ?, ?, ?, NULL)",
  );
  recipients.forEach((recipient) => notify.run(
    recipient.id, title, body, publicationDate, req.params.id, sender?.name || "Library System",
  ));
  return res.json({ ok: true });
});

app.get("/api/report-requests", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const rows = db.prepare("SELECT * FROM report_requests ORDER BY id DESC").all();
  return res.json(rows);
});

app.get("/api/sms-templates", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const templateType = String(req.query.type || "Borrow Confirmation");
  if (!SMS_TEMPLATE_TYPES.has(templateType)) {
    return res.status(400).json({ error: "Invalid SMS template type." });
  }

  const row = db.prepare("SELECT * FROM sms_templates WHERE template_type = ?").get(templateType);
  if (!row) return res.status(404).json({ error: "SMS template not found." });
  return res.json(row);
});

app.put("/api/sms-templates", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "admin") return;

  const { templateType, body } = req.body || {};
  if (!SMS_TEMPLATE_TYPES.has(templateType)) {
    return res.status(400).json({ error: "Invalid SMS template type." });
  }
  if (typeof body !== "string" || !body.trim()) {
    return res.status(400).json({ error: "Template message cannot be empty." });
  }
  if (
    ["OTP (Account Creation)", "OTP (Change Password)"].includes(templateType) &&
    !body.includes("[OTP]")
  ) {
    return res.status(400).json({ error: "OTP templates must include the [OTP] placeholder." });
  }

  db.prepare(
    `INSERT INTO sms_templates (template_type, body) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE body = VALUES(body)`,
  ).run(templateType, body);
  return res.json({ ok: true });
});

app.post("/api/contact", (req, res) => {
  const session = requireSession(req, res);
  if (!session) return;

  let reason = String(req.body.reason || "").trim();
  let message = String(req.body.message || "").trim();
  if (!reason && message) {
    const parsed = splitContactMessage(message);
    if (parsed.reason !== "Message") {
      reason = parsed.reason;
      message = parsed.body;
    }
  }
  if (reason && (!CONTACT_REASONS.includes(reason) || !message)) {
    return res.status(400).json({ error: "Select a contact reason and enter a message." });
  }
  const storedMessage = reason ? `${reason}: ${message}` : message;
  if (!storedMessage) return res.status(400).json({ error: "A message is required." });

  const user = db.prepare("SELECT name FROM users WHERE id = ?").get(session.userId);
  const result = db.prepare(
    `INSERT INTO contact_messages
      (user_id, user_name, message, sender_id, sender_role)
     VALUES (?, ?, ?, ?, ?)`,
  ).run(
    session.userId,
    user?.name,
    storedMessage,
    session.userId,
    session.role,
  );
  db.prepare("UPDATE contact_messages SET conversation_id = ? WHERE id = ?").run(result.lastInsertRowid, result.lastInsertRowid);
  return res.json({ ok: true, threadId: result.lastInsertRowid });
});

app.get("/api/calendar-events", (_req, res) => {
  const rows = db.prepare(
    "SELECT id, title, event_date, event_type, month, day, year FROM calendar_events ORDER BY year, month, day, id",
  ).all();
  return res.json(rows);
});

function isValidCalendarEventDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day;
}

function calendarEventPayload(req, res) {
  const title = String(req.body?.title || "").trim();
  const eventDate = String(req.body?.eventDate || "").trim();
  const eventType = String(req.body?.eventType || "").trim().toLowerCase();
  if (!title || title.length > 255) {
    res.status(400).json({ error: "Activity name is required and must be 255 characters or fewer." });
    return null;
  }
  if (!isValidCalendarEventDate(eventDate)) {
    res.status(400).json({ error: "Enter a valid calendar date." });
    return null;
  }
  if (!["activity", "holiday", "closed"].includes(eventType)) {
    res.status(400).json({ error: "Choose a valid activity type." });
    return null;
  }
  const [year, month, day] = eventDate.split("-").map(Number);
  return { title, eventDate, eventType, year, month, day };
}

app.post("/api/calendar-events", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;
  const event = calendarEventPayload(req, res);
  if (!event) return;

  const result = db.prepare(
    "INSERT INTO calendar_events (title, event_date, event_type, month, day, year) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(event.title, event.eventDate, event.eventType, event.month, event.day, event.year);
  logActivity(session.userId, "Calendar Update", `Added calendar activity (${event.title}) for ${event.eventDate}`);
  return res.status(201).json({ ok: true, id: result.lastInsertRowid });
});

app.put("/api/calendar-events/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;
  const eventId = Number(req.params.id);
  if (!Number.isSafeInteger(eventId) || eventId < 1) {
    return res.status(400).json({ error: "Invalid calendar activity ID." });
  }
  const existing = db.prepare("SELECT id FROM calendar_events WHERE id = ?").get(eventId);
  if (!existing) return res.status(404).json({ error: "Calendar activity not found." });
  const event = calendarEventPayload(req, res);
  if (!event) return;

  db.prepare(
    "UPDATE calendar_events SET title = ?, event_date = ?, event_type = ?, month = ?, day = ?, year = ? WHERE id = ?",
  ).run(event.title, event.eventDate, event.eventType, event.month, event.day, event.year, eventId);
  logActivity(session.userId, "Calendar Update", `Edited calendar activity (${event.title}) for ${event.eventDate}`);
  return res.json({ ok: true });
});

app.delete("/api/calendar-events/:id", (req, res) => {
  const session = requireSession(req, res);
  if (!session || session.role !== "librarian") return;
  const eventId = Number(req.params.id);
  if (!Number.isSafeInteger(eventId) || eventId < 1) {
    return res.status(400).json({ error: "Invalid calendar activity ID." });
  }
  const existing = db.prepare("SELECT id, title FROM calendar_events WHERE id = ?").get(eventId);
  if (!existing) return res.status(404).json({ error: "Calendar activity not found." });

  db.prepare("DELETE FROM calendar_events WHERE id = ?").run(eventId);
  logActivity(session.userId, "Calendar Update", `Deleted calendar activity (${existing.title})`);
  return res.json({ ok: true });
});

app.get("/{*splat}", (_req, res) => {
  res.sendFile(path.resolve(__dirname, "index.html"));
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Golden Gate Library System running at http://localhost:${PORT}`);

  // Optionally open Chrome when OPEN_IN_CHROME=true is set in the environment
  try {
    if (process.env.OPEN_IN_CHROME === 'true') {
      const { exec } = require('child_process');
      const url = `http://localhost:${PORT}`;
      // Use Windows 'start' to open Chrome specifically. If Chrome is not on PATH, this will open default browser instead.
      exec(`start chrome "${url}"`, (err) => {
        if (err) console.error('Failed to open Chrome:', err);
      });
    }
  } catch (e) {
    // don't crash the server if opening the browser fails
    // eslint-disable-next-line no-console
    console.error('Browser open check failed:', e && e.message ? e.message : e);
  }
});

const reservationExpiryTimer = setInterval(() => {
  try {
    expireVisitorReservations();
  } catch (err) {
    console.error("Failed to expire visitor reservations:", err.message || err);
  }
}, 60_000);
reservationExpiryTimer.unref();

sendDueDateReminders();
const dueDateReminderTimer = setInterval(sendDueDateReminders, 60 * 60 * 1000);
dueDateReminderTimer.unref();
