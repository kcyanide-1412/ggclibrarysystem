(function () {
  "use strict";

  const BOOKS = [
    { id: "1", title: "Anna Karenina", author: "Leo Tolstoy", isbn: "9780143035008", avail: 9, total: 12, categories: ["Fiction", "Literature"] },
    { id: "2", title: "To Kill a Mockingbird", author: "Harper Lee", isbn: "9780061120084", avail: 5, total: 10, categories: ["Fiction", "Literature"] },
    { id: "3", title: "1984", author: "George Orwell", isbn: "9780451524935", avail: 3, total: 8, categories: ["Fiction", "Science", "Technology"] },
    { id: "4", title: "Pride and Prejudice", author: "Jane Austen", isbn: "9780141439518", avail: 15, total: 19, categories: ["Fiction", "Literature"] },
    { id: "5", title: "The Great Gatsby", author: "F. Scott Fitzgerald", isbn: "9780743273565", avail: 3, total: 8, categories: ["Fiction", "Literature"] },
    { id: "6", title: "War and Peace", author: "Leo Tolstoy", isbn: "9780143039990", avail: 2, total: 4, categories: ["Fiction", "History", "Literature"] },
    { id: "7", title: "The Catcher in the Rye", author: "J.D. Salinger", isbn: "9780316769488", avail: 11, total: 23, categories: ["Fiction", "Literature"] },
  ];

  function categoriesForBook(title) {
    const normalizedTitle = String(title || "").toLowerCase();
    if (normalizedTitle === "anna karenina") return ["Fiction", "Literature"];
    if (normalizedTitle === "to kill a mockingbird") return ["Fiction", "Literature"];
    if (normalizedTitle === "1984") return ["Fiction", "Science", "Technology"];
    if (normalizedTitle === "pride and prejudice") return ["Fiction", "Literature"];
    if (normalizedTitle === "the great gatsby") return ["Fiction", "Literature"];
    if (normalizedTitle === "war and peace") return ["Fiction", "History", "Literature"];
    if (normalizedTitle === "the catcher in the rye") return ["Fiction", "Literature"];
    if (normalizedTitle === "a study in scarlet" || normalizedTitle === "sign of the four") return ["Fiction", "Literature"];
    if (normalizedTitle === "bible") return ["Non-fiction", "Reference"];
    if (normalizedTitle === "capstone project guide") return ["Education", "Reference"];
    if (normalizedTitle === "english" || normalizedTitle === "filipino") return ["Education", "Literature"];
    return [];
  }
  function renderMemberCategories() {
    qsa(".member-category-card").forEach((button) => {
      const active = button.getAttribute("data-catalog-category") === state.catalogCategory;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });
  }

  const LIB_APPROVAL_ROWS = [
    { user: "kudo", sid: "CET 123", bookId: "1", book: "Anna Karenina", author: "Leo Tolstoy" },
    { user: "brendant", sid: "CET 234", bookId: "2", book: "To Kill a Mockingbird", author: "Harper Lee" },
    { user: "lorenz", sid: "CET 345", bookId: "4", book: "Pride and Prejudice", author: "Jane Austen" },
    { user: "clarise", sid: "CET 456", bookId: "5", book: "The Great Gatsby", author: "F. Scott Fitzgerald" },
  ];

  const LIB_USERS = LIB_APPROVAL_ROWS.map((r) => ({ name: r.user, sid: r.sid }));

  const ADMIN_USERS = [
    { sid: "CET 123", name: "kudo", type: "Student", course: "BSIT" },
    { sid: "CET 234", name: "brendant", type: "Student", course: "BSIT" },
    { sid: "CET 345", name: "lorenz", type: "Teacher", course: "BSIT" },
    { sid: "CET 456", name: "clarise", type: "Student", course: "BSIT" },
  ];

  const DEMO_CREDENTIALS = {
    member: {
      name: "kudo",
      schoolId: "CET123",
      password: "ggckudo",
    },
    librarian: {
      username: "librarian",
      password: "ggclib",
    },
    admin: {
      username: "admin",
      password: "ggcadmin",
    },
  };

  /** @type {{ cart: Set<string>, borrowed: { bookId:string, borrowed:string, due:string, user?:string }[], overdueRows: object[], notifications:{id?:string|number,announcementId?:string|number|null,createdAt?:string|null,sender?:string|null,date:string,title:string,body:string,read?:boolean}[], sentMessages:{id?:string|number,date:string,message:string}[], notificationFilter:string, memberTransactions:object[], historyUsers:object[], txn:{title:string,author:string,date:string,status:string}[], pendingApprove:typeof LIB_APPROVAL_ROWS, pendingReturns:object[], outstandingFines:object[] }} */
  const state = {
    cart: new Set(),
    borrowed: [
      { bookId: "1", borrowed: "04/16/2026", due: "04/19/2026" },
      { bookId: "2", borrowed: "04/11/2026", due: "04/14/2026" },
      { bookId: "3", borrowed: "04/9/2026", due: "04/12/2026" },
      { bookId: "4", borrowed: "04/8/2026", due: "04/11/2026" },
    ],
    overdueRows: [],
    notifications: [
      { date: "04/16/2026", title: "Borrow Request Approved", body: "Your request to borrow Anna Karenina was approved.", read: false },
      { date: "04/14/2026", title: "Overdue Book Reminder", body: "Please return overdue materials.", read: false },
      { date: "04/12/2026", title: "Overdue Book Reminder", body: "Friendly reminder — due date approaching.", read: false },
      { date: "04/11/2026", title: "Overdue Book Reminder", body: "Return books to avoid penalties.", read: false },
    ],
    sentMessages: [],
    notificationFilter: "all",
    memberTransactions: [],
    memberReservations: [],
    txn: [],
    pendingApprove: [],
    pendingReturns: [],
    outstandingFines: [],
    visitorReservations: [],
    historyUsers: [],
    currentMemberName: "Member Demo",
    currentMemberPhone: "",
    composedMemberMessage: "",
    composedMemberReason: "",
    authToken: "",
    currentUser: null,
    libInbox: [],
    libReadNotificationIds: new Set(),
    libNotificationFilter: "all",
    pendingMemberSignup: null,
    passwordResetPhone: "",
    passwordResetToken: "",
    adminUsers: [],
    adminUserStatus: "pending",
    adminDirectoryUsers: [],
    adminDirectoryFilter: "all",
    adminDirectorySearch: "",
    adminActivityFilter: "all",
    adminActivityDateRange: "all",
    adminActivityDateFrom: "",
    adminActivityDateTo: "",
    adminActivityAction: "all",
    adminActivitySearch: "",
    adminCatalogBooks: [],
    adminCatalogSearch: "",
    adminCatalogSort: "title",
    adminCatalogSortDirection: "asc",
    adminAnnouncements: [],
    adminReadAnnouncementIds: new Set(),
    libraryPolicyDuration: 4,
    facultyLibraryPolicyDuration: 4,
    penaltyCostPerDay: 10,
    reservationWalkInMinimumCopies: 1,
    reservationHoldDays: 7,
    calendarEvents: [],
    calendarDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
    activeView: "home",
    catalogCategory: "All Books",
    catalogCategoriesOpen: false,
    contactSectionsOpen: false,
    memberSidebarCollapsed: true,
  };

  const ADMIN_DASHBOARD_REFRESH_MS = 30 * 1000;
  let adminDashboardRefreshTimer = null;
  let adminDashboardRefreshInFlight = false;
  let reportPreviewRequestId = 0;
  let librarianDashboardRefreshTimer = null;
  let librarianDashboardRefreshInFlight = false;
  let staffDashboardRefreshTimer = null;
  let staffDashboardRefreshInFlight = false;

  rebuildTransactions();

  const els = {
    modalRoot: document.getElementById("modal-root"),
    modalBody: document.getElementById("modal-body"),
    chromeRoot: document.getElementById("chrome-root"),
  };

  const STANDALONE_ENTRY_VIEWS = {
    "user.html": "member-catalog",
    "librarian.html": "lib-dashboard",
    "staff.html": "staff-dashboard",
    "admin.html": "adm-dashboard",
  };
  const ROLE_PAGES = {
    member: "user.html",
    visitor: "user.html",
    librarian: "librarian.html",
    staff: "staff.html",
    admin: "admin.html",
  };
  const ROLE_DESTINATIONS = {
    member: "member-catalog",
    visitor: "member-catalog",
    librarian: "lib-dashboard",
    staff: "staff-dashboard",
    admin: "adm-dashboard",
  };

  function standaloneEntryView() {
    const fileName = String(window.location.pathname || "").split("/").pop().toLowerCase();
    return STANDALONE_ENTRY_VIEWS[fileName] || "";
  }

  function renderMemberProfile() {
    const form = qs("#member-profile-form");
    if (!form) return;
    const name = String(state.currentUser?.name || state.currentMemberName || "Member Demo").trim();
    const schoolId = String(state.currentUser?.schoolId || state.currentUser?.sid || "").trim();
    const phone = String(state.currentUser?.phone || state.currentMemberPhone || "").trim();
    const email = String(state.currentUser?.email || "").trim();
    form.elements.name.value = name;
    form.elements.schoolId.value = schoolId;
    form.elements.phone.value = phone;
    form.elements.email.value = email;
    form.elements.currentPassword.value = "";
    form.elements.newPassword.value = "";
    form.elements.confirmPassword.value = "";
  }

  function restoreStandaloneSession() {
    if (!standaloneEntryView()) return;
    try {
      const saved = JSON.parse(sessionStorage.getItem("ggc-library-session") || "null");
      if (!saved?.token || !saved.user) return;
      state.authToken = saved.token;
      state.currentUser = saved.user;
      state.currentMemberName = saved.user.name || "Member";
      state.currentMemberPhone = saved.user.phone || "";
      if (saved.user.role === "member" || saved.user.role === "visitor") {
        if (saved.user.freshAccount) resetFreshMemberState();
        restoreMemberCart();
      }
    } catch (_ignored) {
      sessionStorage.removeItem("ggc-library-session");
    }
  }

  function continueAfterLogin(role, destination) {
    sessionStorage.setItem(
      "ggc-library-session",
      JSON.stringify({ token: state.authToken, user: state.currentUser }),
    );
    if (!document.getElementById("view-" + destination) && ROLE_PAGES[role]) {
      window.location.href = ROLE_PAGES[role];
      return false;
    }
    navigate(destination);
    return true;
  }

  restoreStandaloneSession();

  const ASSET_LOGO = "assets/extract-3361.png";
  const GGC_TITLE = "Web-Based Library System With Auto SMS Notification For Golden Gate Colleges";
  const API_BASES = [window.location.protocol === "file:" ? "http://localhost:5500/api" : "/api"];

  function redirectAfterSessionExpiry() {
    state.authToken = "";
    state.currentUser = null;
    sessionStorage.removeItem("ggc-library-session");
    if (document.getElementById("view-login")) {
      navigate("login");
      return;
    }
    window.location.href = "index.html";
  }

  async function postJson(path, payload) {
    const headers = { "Content-Type": "application/json" };
    if (state.authToken) headers.Authorization = `Bearer ${state.authToken}`;
    let lastError;
    for (const base of API_BASES) {
      try {
        const res = await fetch(`${base}${path}`, {
          method: "POST",
          headers,
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (res.status === 401 && path !== "/auth/login") {
            redirectAfterSessionExpiry();
            throw new Error("Session expired.");
          }

          async function putJson(path, payload) {
            const headers = { "Content-Type": "application/json" };
            if (state.authToken) headers.Authorization = `Bearer ${state.authToken}`;
            const res = await fetch(`${API_BASES[0]}${path}`, {
              method: "PUT",
              headers,
              body: JSON.stringify(payload),
            });
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
            return data;
          }
          const error = new Error(data.error || `Request failed (${res.status})`);
          error.fieldErrors = data.fieldErrors;
          throw error;
        }
        return data;
      } catch (err) {
        lastError = err;
        if (err instanceof Error && !/Failed to fetch|NetworkError|Load failed/i.test(err.message)) throw err;
      }
    }
    throw new Error(`Cannot connect to the library server at http://localhost:5500. ${lastError?.message || ""}`.trim());
  }

  async function putJson(path, payload) {
    const headers = { "Content-Type": "application/json" };
    if (state.authToken) headers.Authorization = `Bearer ${state.authToken}`;
    let lastError;
    for (const base of API_BASES) {
      try {
        const res = await fetch(`${base}${path}`, {
          method: "PUT",
          headers,
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (res.status === 401) {
            redirectAfterSessionExpiry();
            throw new Error("Session expired.");
          }
          throw new Error(data.error || `Request failed (${res.status})`);
        }
        return data;
      } catch (err) {
        lastError = err;
        if (err instanceof Error && !/Failed to fetch|NetworkError|Load failed/i.test(err.message)) throw err;
      }
    }
    throw new Error(`Cannot connect to the library server at http://localhost:5500. ${lastError?.message || ""}`.trim());
  }

  async function getJson(path) {
    const headers = {};
    if (state.authToken) headers.Authorization = `Bearer ${state.authToken}`;
    let lastError;
    let lastHttpError;
    for (const base of API_BASES) {
      try {
        const res = await fetch(`${base}${path}`, { headers });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (res.status === 401) {
            redirectAfterSessionExpiry();
            throw new Error("Session expired.");
          }
          if (res.status === 404 || res.status === 405) {
            lastHttpError = new Error(data.error || `Request failed (${res.status})`);
            lastError = lastHttpError;
            continue;
          }
          throw new Error(data.error || `Request failed (${res.status})`);
        }
        return data;
      } catch (err) {
        lastError = err;
        if (err instanceof Error && !/Failed to fetch|NetworkError|Load failed/i.test(err.message)) throw err;
      }
    }
    if (lastHttpError) throw lastHttpError;
    throw new Error(`Cannot connect to the library server at http://localhost:5500. ${lastError?.message || ""}`.trim());
  }

  async function deleteJson(path) {
    const headers = {};
    if (state.authToken) headers.Authorization = `Bearer ${state.authToken}`;
    let lastError;
    for (const base of API_BASES) {
      try {
        const res = await fetch(`${base}${path}`, { method: "DELETE", headers });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (res.status === 401) {
            redirectAfterSessionExpiry();
            throw new Error("Session expired.");
          }
          throw new Error(data.error || `Request failed (${res.status})`);
        }
        return data;
      } catch (err) {
        lastError = err;
        if (err instanceof Error && !/Failed to fetch|NetworkError|Load failed/i.test(err.message)) throw err;
      }
    }
    throw new Error(`Cannot connect to the library server at http://localhost:5500. ${lastError?.message || ""}`.trim());
  }

  async function loadPendingTransactions(activeTab = "borrow") {
    if (!state.authToken || !["librarian", "staff"].includes(state.currentUser?.role)) return;
    const [rows, borrowedRows, overdueRows, legacyReturnRows, users, visitorReservations] = await Promise.all([
      getJson("/transactions?status=pending"),
      getJson("/transactions?status=borrowed"),
      getJson("/transactions?status=overdue"),
      getJson("/transactions?status=return_pending"),
      getJson("/users?status=active"),
      getJson("/reservations"),
    ]);
    state.pendingApprove = rows.map((r) => ({
      transactionId: r.id,
      user: r.userName,
      sid: r.schoolId,
      course: r.course || "N/A",
      userType: r.userType || "N/A",
      bookId: String(r.bookId),
      book: r.title,
      author: r.author,
    }));
    state.pendingReturns = [...borrowedRows, ...overdueRows, ...legacyReturnRows]
      .map((r) => ({
        transactionId: r.id,
        user: r.userName,
        sid: r.schoolId,
        bookId: String(r.bookId),
        book: r.title,
        isbn: r.isbn || "N/A",
        author: r.author,
        course: r.course || "N/A",
        userType: r.userType || "N/A",
        status: r.status,
      }))
      .sort((a, b) => Number(b.transactionId) - Number(a.transactionId));
    state.historyUsers = users.map((user) => ({
      id: user.id,
      sid: user.schoolId,
      name: user.name,
      course: user.course,
      userType: user.userType,
      role: user.role,
    }));
    state.visitorReservations = visitorReservations;
    renderLibBorrowTabs(activeTab);
  }

  async function loadOutstandingFines() {
    if (!state.authToken || !["librarian", "staff"].includes(state.currentUser?.role)) return;
    const fines = await getJson("/fines");
    if (!Array.isArray(fines)) throw new Error("Invalid outstanding fine data received from the server.");
    state.outstandingFines = fines;
    renderLibBorrowTabs("fines");
  }

  async function loadLibraryPolicy() {
    if (!state.authToken || state.currentUser?.role !== "librarian") return;
    const policy = await getJson("/library-policy");
    state.libraryPolicyDuration = Number(policy.borrowingDurationDays);
    state.facultyLibraryPolicyDuration = Number(policy.facultyBorrowingDurationDays);
    state.reservationWalkInMinimumCopies = Number(policy.reservationWalkInMinimumCopies);
    state.reservationHoldDays = Number(policy.reservationHoldDays);
    state.penaltyCostPerDay = Number(policy.penaltyCostPerDay);
    const select = qs("#lib-borrowing-duration");
    const facultySelect = qs("#lib-faculty-borrowing-duration");
    const walkInMinimumSelect = qs("#lib-reservation-walk-in-minimum");
    const holdDaysInput = qs("#lib-reservation-hold-days");
    const penaltyCostInput = qs("#lib-penalty-cost-per-day");
    const status = qs("#lib-borrowing-duration-status");
    if (select) select.value = String(state.libraryPolicyDuration);
    if (facultySelect) facultySelect.value = String(state.facultyLibraryPolicyDuration);
    if (walkInMinimumSelect) walkInMinimumSelect.value = String(state.reservationWalkInMinimumCopies);
    if (holdDaysInput) holdDaysInput.value = String(state.reservationHoldDays);
    if (penaltyCostInput) penaltyCostInput.value = String(state.penaltyCostPerDay);
    if (status) {
      const copies = state.reservationWalkInMinimumCopies;
      status.textContent = `Reservations leave at least ${copies} available ${copies === 1 ? "copy" : "copies"} for walk-in borrowers; ordinary borrowing may use those copies. Overdue books incur a penalty of ₱${state.penaltyCostPerDay.toFixed(2)} per day when returned late.`;
    }
  }

  async function loadLibrarianOverdue() {
    if (!state.authToken || state.currentUser?.role !== "librarian") {
      state.overdueRows = [];
      renderLibOverdue();
      return;
    }
    const rows = await getJson("/reports/overdue");
    if (!Array.isArray(rows)) throw new Error("Invalid overdue report data received from the server.");
    state.overdueRows = rows;
    renderLibOverdue();
  }

  async function loadLibrarianInbox() {
    if (!state.authToken || state.currentUser?.role !== "librarian") {
      state.libInbox = [];
      state.libReadNotificationIds = new Set();
      renderLibrarianNotifications();
      renderLibInbox();
      renderLibAnnouncements();
      updateLibrarianNotificationBell();
      return;
    }
    const readKey = `ggc-librarian-read-${state.currentUser.id}`;
    let readIds = [];
    try {
      readIds = JSON.parse(localStorage.getItem(readKey) || "[]");
    } catch (_ignored) {
      readIds = [];
    }
    state.libReadNotificationIds = new Set(Array.isArray(readIds) ? readIds : []);
    const [messages, announcements, sentMessages, systemNotifications] = await Promise.all([
      getJson("/contact-messages"),
      getJson("/announcements"),
      getJson("/librarian/notifications/sent"),
      getJson("/librarian/notifications/system"),
    ]);
    if (
      !Array.isArray(messages) ||
      !Array.isArray(announcements) ||
      !Array.isArray(sentMessages) ||
      !Array.isArray(systemNotifications?.borrowRequests)
    ) {
      throw new Error("Invalid notification data received from the server.");
    }
    state.libInbox = [
      ...messages.map((message) => ({
        id: message.id,
        threadId: message.threadId,
        contactMessageId: message.contactMessageId,
        recipientUserId: message.userId,
        senderType: message.senderType,
        date: message.date,
        createdAt: message.createdAt,
        from: message.from,
        kind: message.senderType === "Librarian" ? "Sent" : "Received",
        title: message.reason || "Message",
        excerpt: message.message,
      })),
      ...sentMessages.map((message) => ({
        id: `sent-${message.id}`,
        sourceId: message.id,
        date: message.date,
        createdAt: message.created_at,
        from: message.sender_name || state.currentUser?.name || "Librarian",
        to: message.recipient_name,
        kind: "Sent",
        title: message.title || "Message from the Library",
        excerpt: message.body,
      })),
      ...systemNotifications.borrowRequests.map((request) => ({
        id: `system-borrow-${request.id}`,
        date: request.borrow_date,
        createdAt: request.created_at,
        from: "Library System",
        kind: "System",
        title: "Borrow Request",
        source: "Borrowing",
        excerpt: `${request.requester_name} (${request.school_id || "No ID"}) requested "${request.book_title}".`,
      })),
      ...announcements.map((announcement) => ({
        id: announcement.id,
        announcementId: announcement.announcementId,
        creatorId: announcement.creatorId,
        creatorRole: announcement.creatorRole,
        creatorName: announcement.creatorName,
        creatorLabel: announcement.creatorLabel,
        date: announcement.date,
        from: announcement.creatorLabel || "Library System",
        kind: "Announcement",
        title: announcement.title,
        audience: announcement.audience,
        creatorRole: announcement.creatorRole,
        creatorName: announcement.creatorName,
        creatorLabel: announcement.creatorLabel,
        publicationDate: announcement.publicationDate,
        excerpt: announcement.body,
      })),
    ].sort(compareNotificationRecency);
    renderLibInbox();
    renderLibAnnouncements();
    renderLibrarianNotifications();
  }

  async function loadMemberTransactions() {
    if (!state.authToken || !["member", "visitor"].includes(state.currentUser?.role)) return;
    const rows = await getJson("/transactions/mine");
    if (!Array.isArray(rows)) throw new Error("Invalid transaction data received from the server.");
    state.memberTransactions = rows;

    state.borrowed = rows
      .filter((transaction) => ["borrowed", "overdue", "return_pending"].includes(transaction.status))
      .map((transaction) => ({
        transactionId: transaction.id,
        bookId: String(transaction.bookId),
        borrowed: transaction.borrowDate,
        due: transaction.dueDate,
      }));

    state.pendingApprove = rows
      .filter((transaction) => transaction.status === "pending")
      .map((transaction) => ({
        transactionId: transaction.id,
        memberRequest: true,
        user: state.currentUser.name,
        sid: state.currentUser.schoolId,
        bookId: String(transaction.bookId),
        book: transaction.title,
        author: transaction.author,
      }));

  }

  async function loadMemberReservations() {
    if (!state.authToken || state.currentUser?.role !== "visitor") return;
    const rows = await getJson("/reservations/mine");
    if (!Array.isArray(rows)) throw new Error("Invalid visitor reservation data received from the server.");
    state.memberReservations = rows;
    await loadBooks();
  }

  function renderMemberReservations() {
    const tbody = qs("#member-reservations-table tbody");
    if (!tbody) return;
    tbody.innerHTML = state.memberReservations.length
      ? state.memberReservations.map((reservation) => {
        const status = String(reservation.status || "").toLowerCase();
        const canCancel = ["pending", "approved"].includes(status);
        const requestedAt = String(reservation.createdAt || "");
        const statusDetails = {
          pending: "Awaiting librarian approval",
          approved: "Copy held for pickup",
          fulfilled: "Picked up",
          declined: "Request declined",
          cancelled: "Cancelled by you",
          expired: "Reservation expired",
        }[status] || "";
        const actionCell = canCancel
          ? `<button type="button" class="btn-borrow-pdf cancel-visitor-reservation" data-reservation-id="${escapeHtml(reservation.id)}">Cancel</button>`
          : status === "cancelled"
            ? '<span class="reservation-cancelled-label">Canceled</span>'
            : "—";
        return `<tr>
          <td>
            <div class="member-reservation-primary">${escapeHtml(reservation.title || "Untitled book")}</div>
            <div class="member-reservation-secondary">by ${escapeHtml(reservation.author || "Unknown author")}</div>
            <div class="member-reservation-secondary">ISBN: ${escapeHtml(reservation.isbn || "N/A")}</div>
          </td>
          <td><div class="member-reservation-primary">${escapeHtml(requestedAt.slice(0, 10) || "—")}</div><div class="member-reservation-secondary">${escapeHtml(requestedAt.slice(11, 16))}</div></td>
          <td><div class="member-reservation-primary">${escapeHtml(reservation.pickupDate || "—")}</div><div class="member-reservation-secondary">Requested pickup date</div></td>
          <td>${reservation.expiresAt
            ? `<div class="member-reservation-primary">${escapeHtml(formatReservationDeadline(reservation.expiresAt))}</div><div class="member-reservation-secondary">${status === "approved" ? "Pickup deadline" : "Hold expiry"}</div>`
            : `<div class="member-reservation-primary">—</div>${status === "pending" ? '<div class="member-reservation-secondary">Set after approval</div>' : ""}`}</td>
          <td><span class="reservation-status reservation-status-${escapeHtml(status)}">${escapeHtml(status.charAt(0).toUpperCase() + status.slice(1))}</span><div class="member-reservation-secondary">${escapeHtml(statusDetails)}</div></td>
          <td>${actionCell}</td>
        </tr>`;
      }).join("")
      : '<tr><td colspan="6" class="muted">You have no reservations yet.</td></tr>';
  }

  function formatReservationDeadline(value) {
    if (!value) return "—";
    const parsed = Date.parse(`${String(value).replace(" ", "T")}Z`);
    if (!Number.isFinite(parsed)) return String(value);
    return new Intl.DateTimeFormat(undefined, {
      timeZone: "Asia/Manila",
      dateStyle: "medium",
      timeStyle: "short",
    }).format(parsed);
  }

  async function loadMemberNotifications() {
    if (!state.authToken || !["member", "visitor"].includes(state.currentUser?.role)) return;
    const rows = await getJson("/notifications");
    if (!Array.isArray(rows)) throw new Error("Invalid notification data received from the server.");
    state.notifications = rows;
  }

  async function loadMemberSentMessages() {
    if (!state.authToken || !["member", "visitor"].includes(state.currentUser?.role)) {
      state.sentMessages = [];
      return;
    }
    const rows = await getJson("/contact-messages/sent");
    if (!Array.isArray(rows)) throw new Error("Invalid sent message data received from the server.");
    state.sentMessages = rows;
  }

  async function loadAdminUsers(status = state.adminUserStatus) {
    if (!state.authToken || state.currentUser?.role !== "admin") return;
    state.adminUserStatus = status;
    const rows = await getJson(status && status !== "all" ? `/users?status=${encodeURIComponent(status)}` : "/users");
    if (!Array.isArray(rows)) throw new Error("Invalid user data received from the server.");
    state.adminUsers = rows;
    renderAdmUsers();
  }

  async function loadAdminDirectory() {
    if (!state.authToken || state.currentUser?.role !== "admin") return;
    const rows = await getJson("/admin/user-directory");
    if (!Array.isArray(rows)) throw new Error("Invalid admin user directory data received from the server.");
    state.adminDirectoryUsers = rows;
    renderAdminDirectory();
  }

  function applyDashboardStats(stats, prefix = "adm") {
    const totalBooks = Number(stats.totalBooks) || 0;
    const availableBooks = Number(stats.available) || 0;
    const borrowed = Number(stats.borrowed) || 0;
    const overdue = Number(stats.overdue) || 0;
    const librarians = Number(stats.librarians) || 0;
    const students = Number(stats.students) || 0;
    const faculty = Number(stats.faculty) || 0;
    const visitors = Number(stats.visitors) || 0;
    const administrators = Number(stats.administrators) || 0;
    const libraryStaff = Number(stats.libraryStaff) || 0;
    const booksInChart = availableBooks;
    const borrowedNotOverdue = Math.max(0, borrowed - overdue);

    const values = {
      [`${prefix}-total-books`]: totalBooks,
      [`${prefix}-total-users`]: Number(stats.totalUsers) || 0,
      [`${prefix}-borrowed-books`]: borrowed,
      [`${prefix}-overdue-books`]: overdue,
      [`${prefix}-books-legend`]: booksInChart,
      [`${prefix}-borrowed-legend`]: borrowedNotOverdue,
      [`${prefix}-overdue-legend`]: overdue,
      [`${prefix}-librarians-legend`]: librarians,
      [`${prefix}-library-staff-legend`]: libraryStaff,
      [`${prefix}-students-legend`]: students,
      [`${prefix}-faculty-legend`]: faculty,
      [`${prefix}-visitors-legend`]: visitors,
      [`${prefix}-administrators-legend`]: administrators,
    };
    Object.entries(values).forEach(([id, value]) => {
      const node = document.getElementById(id);
      if (node) node.textContent = value.toLocaleString();
    });

    const setDonut = (id, parts, colors = ["#4f8a68", "#ffdb4d", "#ff3d45"]) => {
      const total = parts.reduce((sum, value) => sum + value, 0);
      const donut = document.getElementById(id);
      if (!donut) return;
      if (!total) {
        donut.style.background = "#cbd6d8";
        return;
      }

      const segmentEnds = [];
      let current = 0;
      for (let index = 0; index < parts.length; index += 1) {
        current += (parts[index] / total) * 100;
        segmentEnds.push(current);
      }

      const stops = [];
      for (let index = 0; index < parts.length; index += 1) {
        const start = index === 0 ? 0 : segmentEnds[index - 1];
        const end = segmentEnds[index];
        stops.push(`${colors[index]} ${start}% ${end}%`);
      }
      donut.style.background = `conic-gradient(${stops.join(", ")})`;
    };

    setDonut(`${prefix}-books-donut`, [booksInChart, borrowedNotOverdue, overdue], ["#4f8a68", "#ffdb4d", "#ff3d45"]);
    setDonut(
      `${prefix}-users-donut`,
      [administrators, librarians, libraryStaff, faculty, students, visitors],
      ["#a6cdb5", "#78aa8c", "#9b78b5", "#4f8a68", "#265c42", "#ffdb4d"],
    );
  }

  async function loadAdminDashboardStats() {
    if (!state.authToken || state.currentUser?.role !== "admin") return;
    applyDashboardStats(await getJson("/dashboard/stats"));
  }

  async function loadLibrarianDashboardStats() {
    if (!state.authToken || state.currentUser?.role !== "librarian") return;
    applyDashboardStats(await getJson("/dashboard/stats"), "lib");
  }

  async function loadStaffDashboardStats() {
    if (!state.authToken || state.currentUser?.role !== "staff") return;
    applyDashboardStats(await getJson("/dashboard/stats"), "lib");
  }

  async function refreshStaffDashboardStats() {
    if (staffDashboardRefreshInFlight || state.activeView !== "staff-dashboard" || document.hidden) return;
    staffDashboardRefreshInFlight = true;
    try {
      await loadStaffDashboardStats();
    } catch (err) {
      toast(`Unable to refresh Library Staff dashboard statistics: ${err.message}`);
    } finally {
      staffDashboardRefreshInFlight = false;
    }
  }

  function stopStaffDashboardRefresh() {
    if (staffDashboardRefreshTimer !== null) {
      window.clearInterval(staffDashboardRefreshTimer);
      staffDashboardRefreshTimer = null;
    }
  }

  function startStaffDashboardRefresh() {
    stopStaffDashboardRefresh();
    refreshStaffDashboardStats();
    staffDashboardRefreshTimer = window.setInterval(
      refreshStaffDashboardStats,
      ADMIN_DASHBOARD_REFRESH_MS,
    );
  }

  async function refreshLibrarianDashboardStats() {
    if (librarianDashboardRefreshInFlight || state.activeView !== "lib-dashboard" || document.hidden) return;
    librarianDashboardRefreshInFlight = true;
    try {
      await loadLibrarianDashboardStats();
    } catch (err) {
      toast(`Unable to refresh librarian dashboard statistics: ${err.message}`);
    }
    try {
      await loadLibrarianInbox();
    } catch (err) {
      toast(`Unable to refresh notifications: ${err.message}`);
    } finally {
      librarianDashboardRefreshInFlight = false;
    }
  }

  function stopLibrarianDashboardRefresh() {
    if (librarianDashboardRefreshTimer !== null) {
      window.clearInterval(librarianDashboardRefreshTimer);
      librarianDashboardRefreshTimer = null;
    }
  }

  function startLibrarianDashboardRefresh() {
    stopLibrarianDashboardRefresh();
    refreshLibrarianDashboardStats();
    librarianDashboardRefreshTimer = window.setInterval(
      refreshLibrarianDashboardStats,
      ADMIN_DASHBOARD_REFRESH_MS,
    );
  }

  async function refreshAdminDashboardStats() {
    if (adminDashboardRefreshInFlight || state.activeView !== "adm-dashboard" || document.hidden) return;
    adminDashboardRefreshInFlight = true;
    try {
      await loadAdminDashboardStats();
    } catch (err) {
      toast(`Unable to refresh dashboard statistics: ${err.message}`);
    }
    try {
      await loadAdminAnnouncements();
    } catch (err) {
      const list = qs("#adm-dashboard-announcements");
      if (list) list.innerHTML = `<li class="adm-dashboard-announcement-empty" role="alert">${escapeHtml(`Unable to load announcements: ${err.message}`)}</li>`;
      toast(`Unable to refresh dashboard announcements: ${err.message}`);
    } finally {
      adminDashboardRefreshInFlight = false;
    }
  }

  function stopAdminDashboardRefresh() {
    if (adminDashboardRefreshTimer !== null) {
      window.clearInterval(adminDashboardRefreshTimer);
      adminDashboardRefreshTimer = null;
    }
  }

  function startAdminDashboardRefresh() {
    stopAdminDashboardRefresh();
    refreshAdminDashboardStats();
    adminDashboardRefreshTimer = window.setInterval(
      refreshAdminDashboardStats,
      ADMIN_DASHBOARD_REFRESH_MS,
    );
  }

  async function loadBooks() {
    const rows = await getJson("/books");
    if (!Array.isArray(rows)) throw new Error("Invalid book data received from the server.");
    BOOKS.splice(
      0,
      BOOKS.length,
      ...rows.map((book) => ({
        id: String(book.id),
        title: String(book.title || ""),
        author: String(book.author || ""),
        isbn: String(book.isbn || ""),
        avail: Number(book.avail) || 0,
        total: Number(book.total) || 0,
        reservationMinimum: Number(book.reservationWalkInMinimumCopies) || 1,
        reservationHoldDays: Number(book.reservationHoldDays) || 7,
        categories: categoriesForBook(book.title),
      })),
    );
    if (rows.length) {
      state.reservationWalkInMinimumCopies = Number(rows[0].reservationWalkInMinimumCopies) || 1;
      state.reservationHoldDays = Number(rows[0].reservationHoldDays) || 7;
    }
    if (["member", "visitor"].includes(state.currentUser?.role)) {
      restoreMemberCart();
      const validBookIds = new Set(BOOKS.map((book) => book.id));
      const validCart = Array.from(state.cart).filter((bookId) => validBookIds.has(bookId));
      state.cart = new Set(validCart);
      saveMemberCart();
    }
    if (qs("#catalog-table")) renderCatalog();
    if (qs("#cart-table")) renderCart();
    if (qs("#borrowed-table")) renderBorrowed();
    if (qs("#lib-inv-table")) renderLibInventory();
    if (qs("#adm-catalog-table")) renderAdmCatalog();
    renderHomeCatalog();
  }

  function renderHomeCatalog() {
    const preview = qs("#home-catalog-preview");
    if (!preview) return;
    const featuredBooks = [...BOOKS]
      .sort((first, second) => Number(second.avail > 0) - Number(first.avail > 0) ||
        first.title.localeCompare(second.title))
      .slice(0, 4);
    if (!featuredBooks.length) {
      preview.innerHTML = '<p class="home-catalog-status">The catalog is currently empty. Please check back later.</p>';
      return;
    }
    preview.innerHTML = featuredBooks.map((book, index) => `
      <article class="home-catalog-card">
        <div class="home-catalog-card-mark" aria-hidden="true">
          <span>GGC</span>
          <strong>${String(index + 1).padStart(2, "0")}</strong>
          <i></i>
        </div>
        <div class="home-catalog-card-copy">
          <p class="home-catalog-card-kicker">Library Collection</p>
          <h3>${escapeHtml(book.title)}</h3>
          <p class="home-catalog-author">by ${escapeHtml(book.author || "Unknown author")}</p>
          <span class="home-catalog-availability${book.avail > 0 ? " is-available" : ""}">
            ${book.avail > 0 ? `${book.avail} available` : "Currently unavailable"}
          </span>
        </div>
      </article>
    `).join("");
  }

  function toE164Phone(value) {
    const raw = String(value || "").trim().replace(/[^\d+]/g, "");
    if (raw.startsWith("+")) return raw;
    if (raw.startsWith("09") && raw.length === 11) {
      return `+63${raw.slice(1)}`;
    }
    if (raw.startsWith("639") && raw.length === 12) {
      return `+${raw}`;
    }
    return raw;
  }

  function isPublicChrome(id) {
    return (
      id === "home" ||
      id === "about" ||
      id === "contact" ||
      id === "login" ||
      id.startsWith("login-") ||
      id === "register" ||
      id === "otp-signup" ||
      id === "otp-forgot" ||
      id === "forgot" ||
      id === "reset-password"
    );
  }

  function navMark(active, target) {
    return active === target ? "nav-active" : "";
  }

  function staffNavLib(active) {
    const catActive = active === "lib-inventory" ? "nav-active" : "";
    return `
    <nav class="staff-secondary-nav" aria-label="Librarian">
      <div class="staff-secondary-nav-inner">
        <button type="button" class="${navMark(active, "lib-dashboard")}" data-go="lib-dashboard">Dashboard</button>
        <button type="button" class="${catActive}" data-go="lib-inventory">Catalog Management</button>
        <button type="button" class="${navMark(active, "lib-borrowing")}" data-go="lib-borrowing">Borrowing &amp; Returning Control</button>
        <button type="button" class="${navMark(active, "lib-policies")}" data-go="lib-policies">Library Policies</button>
        <button type="button" class="${navMark(active, "lib-overdue")}" data-go="lib-overdue">Overdue Monitoring</button>
        <button type="button" class="${navMark(active, "lib-announcements")}" data-go="lib-announcements">Announcements</button>
        <button type="button" class="${navMark(active, "lib-report")}" data-go="lib-report">System Reports &amp; Analytics</button>
        <button type="button" class="${navMark(active, "lib-calendar")}" data-go="lib-calendar">Edit Calendar</button>
      </div>
    </nav>`;
  }

  function staffNav(active) {
    return `
    <nav class="staff-secondary-nav" aria-label="Library Staff">
      <div class="staff-secondary-nav-inner">
        <button type="button" class="${navMark(active, "staff-dashboard")}" data-go="staff-dashboard">Dashboard</button>
        <button type="button" class="${navMark(active, "staff-inventory")}" data-go="staff-inventory">Catalog Management</button>
        <button type="button" class="${navMark(active, "staff-borrowing")}" data-go="staff-borrowing">Borrowing &amp; Returning Control</button>
        <button type="button" class="${navMark(active, "staff-calendar")}" data-go="staff-calendar">Calendar</button>
      </div>
    </nav>`;
  }

  function staffNavAdm(active) {
    const userManagementPages = {
      "adm-directory": "All Users",
      "adm-users": "Account Creation Approval And Deactivation",
      "adm-activity": "User Activity Logs",
    };
    const userManagementLabel = userManagementPages[active] || "User Accounts Management";
    const staffGrp = userManagementPages[active] ? "nav-active" : "";
    return `
    <nav class="staff-secondary-nav" aria-label="Administrator">
      <div class="staff-secondary-nav-inner">
        <button type="button" class="${navMark(active, "adm-dashboard")}" data-go="adm-dashboard">Dashboard</button>
        <div class="nav-dd-wrap">
          <button type="button" class="${staffGrp}">${userManagementLabel} ▾</button>
          <div class="nav-dd-panel">
            <button type="button" data-go="adm-directory">All Users</button>
            <button type="button" data-go="adm-users">Account Creation Approval And Deactivation</button>
            <button type="button" data-go="adm-activity">User Activity Logs</button>
          </div>
        </div>
        <button type="button" class="${navMark(active, "adm-catalog")}" data-go="adm-catalog">Catalog Oversight</button>
        <button type="button" class="${navMark(active, "adm-sms")}" data-go="adm-sms">SMS Notification Templates</button>
        <button type="button" class="${navMark(active, "adm-reports")}" data-go="adm-reports">System Reports &amp; Analytics</button>
        <button type="button" class="${navMark(active, "adm-announcements")}" data-go="adm-announcements">Announcements</button>
        <button type="button" class="${navMark(active, "adm-calendar")}" data-go="adm-calendar">Calendar</button>
      </div>
    </nav>`;
  }

  function refreshChrome(viewId) {
    if (!els.chromeRoot) return;
    document.querySelector(
      "#chrome-root + .ggc-subbar, #chrome-root + .staff-secondary-nav[aria-label='Administrator']",
    )?.remove();
    document.body.classList.remove("mode-public", "mode-member", "mode-staff");

    if (isPublicChrome(viewId)) {
      document.body.classList.add("mode-public");
      els.chromeRoot.innerHTML = `
      <header class="ggc-banner">
        <img src="${ASSET_LOGO}" alt="Golden Gate Colleges" class="ggc-seal" width="56" height="56" />
        <h1 class="ggc-banner-title">${GGC_TITLE}</h1>
      </header>
      <div class="ggc-subbar"><nav aria-label="Homepage sections"><a href="#home-about" data-home-section="home-about">About</a><a href="#home-catalog" data-home-section="home-catalog">Explore the Collection</a><a href="#home-borrowing" data-home-section="home-borrowing">How Borrowing Works</a><a href="#home-contact" data-home-section="home-contact">Contact</a><a href="#home-reservation" data-home-section="home-reservation">Reservation Guide</a></nav></div>`;
      const publicNav = els.chromeRoot.querySelector(".ggc-subbar");
      if (publicNav) els.chromeRoot.after(publicNav);
      return;
    }

    if (viewId.startsWith("member-")) {
      els.chromeRoot.innerHTML = "";
      document.body.classList.add("mode-member");
      return;
    }

    document.body.classList.add("mode-staff");

    if (viewId.startsWith("staff-")) {
      const staffName = String(
        state.currentUser?.name || state.currentUser?.username || "Library Staff",
      ).trim();
      const staffInitial = staffName.charAt(0).toUpperCase() || "S";
      els.chromeRoot.innerHTML = `
      <header class="ggc-banner staff-layout">
        <div class="brand-lockup">
          <img src="${ASSET_LOGO}" alt="" class="ggc-seal" width="52" height="52" />
          <span class="brand-lockup-text">${GGC_TITLE}</span>
        </div>
        <div class="staff-user-menu">
          <button type="button" class="staff-user-avatar" aria-label="Open Library Staff menu for ${escapeHtml(staffName)}" aria-expanded="false" title="${escapeHtml(staffName)}">
            <span aria-hidden="true">${escapeHtml(staffInitial)}</span>
          </button>
          <div class="staff-user-dropdown" role="menu">
            <div class="staff-user-dropdown-name">${escapeHtml(staffName)}</div>
            <button type="button" data-action="staff-edit-profile" role="menuitem">Edit Profile</button>
            <button type="button" data-go="staff-logout-confirm" role="menuitem">Log out</button>
          </div>
        </div>
      </header>
      ${staffNav(viewId)}`;
      return;
    }

    if (viewId.startsWith("lib-")) {
      const librarianName = String(
        state.currentUser?.name || state.currentUser?.username || "Librarian",
      ).trim();
      const librarianInitial = librarianName.charAt(0).toUpperCase() || "L";
      els.chromeRoot.innerHTML = `
      <header class="ggc-banner staff-layout">
        <div class="brand-lockup">
          <img src="${ASSET_LOGO}" alt="" class="ggc-seal" width="52" height="52" />
          <span class="brand-lockup-text">${GGC_TITLE}</span>
        </div>
        <div class="staff-user-menu librarian-user-menu">
          <button type="button" class="staff-notification-button" data-go="lib-messages" aria-label="Notifications" title="Notifications">
            <img src="assets/notif.png" alt="" aria-hidden="true" />
          </button>
          <button type="button" class="staff-user-avatar" aria-label="Open librarian menu for ${escapeHtml(librarianName)}" aria-expanded="false" title="${escapeHtml(librarianName)}">
            <span aria-hidden="true">${escapeHtml(librarianInitial)}</span>
          </button>
          <div class="staff-user-dropdown" role="menu">
            <div class="staff-user-dropdown-name">${escapeHtml(librarianName)}</div>
            <button type="button" data-action="lib-edit-profile" role="menuitem">Edit Profile</button>
            <button type="button" data-go="lib-logout-confirm" role="menuitem">Log out</button>
          </div>
        </div>
      </header>
      ${staffNavLib(viewId)}`;
      return;
    }

    if (viewId.startsWith("adm-")) {
      els.chromeRoot.innerHTML = `
      <header class="ggc-banner staff-layout">
        <div class="brand-lockup">
          <img src="${ASSET_LOGO}" alt="" class="ggc-seal" width="52" height="52" />
          <span class="brand-lockup-text">${GGC_TITLE}</span>
        </div>
        <div class="staff-user-menu">
          <button type="button" class="staff-user-avatar" aria-label="Open administrator menu" aria-expanded="false">
            <span aria-hidden="true">A</span>
          </button>
          <div class="staff-user-dropdown" role="menu">
            <button type="button" data-go="adm-logout-confirm" role="menuitem">Log out</button>
          </div>
        </div>
      </header>`;
      els.chromeRoot.insertAdjacentHTML("afterend", staffNavAdm(viewId));
    }
  }

  function qs(sel, ctx = document) {
    return ctx.querySelector(sel);
  }
  function qsa(sel, ctx = document) {
    return Array.from(ctx.querySelectorAll(sel));
  }

  function showView(id, options = {}) {
    qsa(".view").forEach((v) => v.classList.add("hidden"));
    const node = document.getElementById("view-" + id);
    if (node) {
      if (id === "member-catalog" && state.activeView !== "member-catalog" && !options.preserveCatalogCategory) {
        state.catalogCategory = "All Books";
        state.catalogCategoriesOpen = false;
      }
      if (id !== "member-catalog") state.catalogCategoriesOpen = false;
      if (!id.startsWith("member-contact")) state.contactSectionsOpen = false;
      node.classList.remove("hidden");
      state.activeView = id;
      window.scrollTo(0, 0);
      refreshChrome(id);
      if (typeof onViewShown === "function") onViewShown(id);
    }
  }

  let registerModalReturnFocus = null;
  let loginModalReturnFocus = null;

  function openRegistrationModal(returnFocus = null) {
    const modal = qs("#view-register");
    if (!modal) return;
    registerModalReturnFocus = returnFocus || registerModalReturnFocus;
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    qs('[role="dialog"]', modal)?.focus();
  }

  function closeRegistrationModal(restoreFocus = true) {
    const modal = qs("#view-register");
    if (!modal || modal.classList.contains("hidden")) return;
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
    if (
      els.modalRoot.classList.contains("hidden") &&
      qs("#view-login")?.classList.contains("hidden")
    ) {
      document.body.classList.remove("modal-open");
    }
    const returnFocus = registerModalReturnFocus;
    registerModalReturnFocus = null;
    if (restoreFocus && returnFocus?.isConnected) returnFocus.focus();
  }

  function openLoginModal(returnFocus = null) {
    const modal = qs("#view-login");
    if (!modal) return;
    loginModalReturnFocus = returnFocus || loginModalReturnFocus;
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    qs('[role="dialog"]', modal)?.focus();
  }

  function closeLoginModal(restoreFocus = true) {
    const modal = qs("#view-login");
    if (!modal || modal.classList.contains("hidden")) return;
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
    if (
      els.modalRoot.classList.contains("hidden") &&
      qs("#view-register")?.classList.contains("hidden")
    ) {
      document.body.classList.remove("modal-open");
    }
    const returnFocus = loginModalReturnFocus;
    loginModalReturnFocus = null;
    if (restoreFocus && returnFocus?.isConnected) returnFocus.focus();
  }

  const loginForm = qs("#form-login");
  const updateLoginFloatingLabel = (field) => {
    const wrapper = field.closest(".register-field");
    if (!wrapper) return;
    const input = wrapper.querySelector("input");
    wrapper.classList.toggle(
      "is-floating",
      input === document.activeElement || Boolean(input?.value),
    );
  };
  loginForm?.addEventListener("input", (event) => updateLoginFloatingLabel(event.target));
  loginForm?.addEventListener("change", (event) => updateLoginFloatingLabel(event.target));
  loginForm?.addEventListener("focusin", (event) => updateLoginFloatingLabel(event.target));
  loginForm?.addEventListener("focusout", (event) => updateLoginFloatingLabel(event.target));
  loginForm?.addEventListener("click", (event) => {
    const button = event.target.closest(".login-password-toggle");
    if (!button) return;
    const passwordField = loginForm.elements.namedItem("password");
    if (!(passwordField instanceof HTMLInputElement)) return;
    const showPassword = passwordField.type === "password";
    passwordField.type = showPassword ? "text" : "password";
    button.innerHTML = showPassword
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7s-1.1 2.1-3.1 3.8M6.2 6.2C3.6 8 2 12 2 12s3.6 7 10 7a10.7 10.7 0 0 0 4.2-.9"></path></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    button.setAttribute("aria-label", `${showPassword ? "Hide" : "Show"} password`);
    button.setAttribute("aria-pressed", String(showPassword));
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeRegistrationModal();
      closeLoginModal();
    }
  });

  function onViewShown(id) {
    if (id.startsWith("member-")) {
      hydrateMemberSidebars();
      hydrateMemberProfiles();
      if (state.authToken && ["member", "visitor"].includes(state.currentUser?.role)) {
        loadMemberNotifications()
          .then(() => {
            if (state.activeView === "member-notifications") renderMemberNotifications();
            else updateMemberNotificationIcon();
          })
          .catch((err) => toast(`Unable to load notifications: ${err.message}`));
      }
    }
    if (id === "member-catalog") {
      renderCatalog();
      loadMemberTransactions()
        .then(() => renderCatalog())
        .catch((err) => toast(`Unable to refresh borrow request status: ${err.message}`));
      if (state.currentUser?.role === "visitor") {
        loadMemberReservations().then(renderCatalog)
          .catch((err) => toast(`Unable to load visitor reservations: ${err.message}`));
      }
    }
    if (id === "member-categories") renderMemberCategories();
    if (id === "member-cart") renderCart();
    if (id === "member-borrowed") {
      renderBorrowed();
      loadMemberTransactions()
        .then(() => renderBorrowed())
        .catch((err) => toast(`Unable to load borrowed books: ${err.message}`));
    }
    if (id === "member-notifications") {
      renderMemberNotifications();
    }
    if (id === "member-transactions") {
      renderTransactionsTable();
      loadMemberTransactions()
        .then(() => renderTransactionsTable())
        .catch((err) => toast(`Unable to load transaction history: ${err.message}`));
    }
    if (id === "member-reservations" && state.currentUser?.role === "visitor") {
      renderMemberReservations();
      loadMemberReservations()
        .then(renderMemberReservations)
        .catch((err) => toast(`Unable to load reservations: ${err.message}`));
    }
    if (id === "member-profile") renderMemberProfile();
    if (id === "member-calendar") {
      mountCalendar(document.getElementById("member-calendar-mount"), false)
        .catch((err) => toast(`Unable to load the calendar: ${err.message}`));
    }
    if (id === "adm-dashboard") {
      startAdminDashboardRefresh();
    } else {
      stopAdminDashboardRefresh();
    }
    if (id === "lib-dashboard") {
      startLibrarianDashboardRefresh();
    } else {
      stopLibrarianDashboardRefresh();
    }
    if (id === "staff-dashboard") {
      startStaffDashboardRefresh();
    } else {
      stopStaffDashboardRefresh();
    }
    if (id === "lib-inventory") renderLibInventory();
    if (id === "lib-borrowing") {
      renderLibBorrowTabs();
      loadPendingTransactions().catch((err) => {
        toast(`Unable to load borrowing and return records: ${err.message}`);
      });
    }
    if (id === "lib-policies") {
      loadLibraryPolicy().catch((err) => {
        toast(`Unable to load borrowing policy: ${err.message}`);
      });
    }
    if (id === "lib-overdue") {
      renderLibOverdue();
      loadLibrarianOverdue().catch((err) => {
        toast(`Unable to load overdue books: ${err.message}`);
      });
    }
    if (id === "lib-messages") {
      renderLibInbox();
    }
    if (id.startsWith("lib-") && id !== "lib-dashboard") {
      loadLibrarianInbox().catch((err) => toast(`Unable to load notifications: ${err.message}`));
    }
    if (id === "lib-report") {
      initializeReportPeriodOptions("lib");
      loadReportPreview("lib").catch((err) => renderReportPreviewError(err.message, "lib"));
    }
    if (id === "lib-calendar") {
      mountCalendar(document.getElementById("lib-calendar-mount"), true)
        .catch((err) => toast(`Unable to load the calendar: ${err.message}`));
    }
    if (id === "staff-calendar") {
      mountCalendar(document.getElementById("staff-calendar-mount"), false)
        .catch((err) => toast(`Unable to load the calendar: ${err.message}`));
    }
    if (id === "adm-calendar") {
      mountCalendar(document.getElementById("adm-calendar-mount"), false)
        .catch((err) => toast(`Unable to load the calendar: ${err.message}`));
    }
    if (id === "staff-inventory") renderLibInventory();
    if (id === "staff-borrowing") {
      renderLibBorrowTabs();
      loadPendingTransactions().catch((err) => {
        toast(`Unable to load borrowing and return records: ${err.message}`);
      });
    }
    if (id === "adm-users") {
      renderAdmUsers();
      loadAdminUsers().catch((err) => toast(`Unable to load user accounts: ${err.message}`));
      loadAdminDashboardStats().catch((err) => toast(`Unable to load user statistics: ${err.message}`));
    }
    if (id === "adm-directory") {
      renderAdminDirectory();
      loadAdminDirectory().catch((err) => toast(`Unable to load the user directory: ${err.message}`));
    }
    if (id === "adm-activity") {
      loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
    }
    if (id === "adm-catalog") {
      loadAdminCatalog().catch((err) => toast(`Unable to load the catalog: ${err.message}`));
    }
    if (id === "adm-sms") {
      loadAdminSmsTemplate(qs("#sms-type")?.value || "Borrow Confirmation")
        .catch((err) => toast(`Unable to load the notification template: ${err.message}`));
    }
    if (id === "adm-reports") {
      initializeReportPeriodOptions("adm");
      loadReportPreview("adm").catch((err) => {
        renderReportPreviewError(err.message, "adm");
      });
    }
    if (id === "adm-announcements") {
      loadAdminAnnouncements().catch((err) => {
        const list = qs("#adm-announcements-list");
        if (list) list.innerHTML = `<li class="adm-announcement-empty" role="alert">${escapeHtml(`Unable to load announcements: ${err.message}`)}</li>`;
        toast(`Unable to load announcements: ${err.message}`);
      });
    }
  }

  function navigate(target, options) {
    if (target === "login") {
      showView("home");
      openLoginModal();
      return;
    }
    showView(target, options);
  }

  async function loadAdminSmsTemplate(templateType) {
    const typeSelect = qs("#sms-type");
    const bodyInput = qs("#sms-body");
    const saveButton = qs("#btn-save-sms");
    const help = qs("#adm-sms-help");
    if (!typeSelect || !bodyInput || !saveButton) return;
    const placeholders = {
      "Borrow Confirmation": "[Name], [Username], [Borrower Name], [Book Title], [Author], [Borrow Date], [Return Date]",
      "Due Date Reminder": "[Name], [Borrower Name], [Book Title], [Author], [Return Date]",
      "Overdue Notice": "[Borrower Name], [Book Title], [Author], [Return Date]",
      "OTP (Account Creation)": "[Name], [OTP], [Expiration Time] ([OTP] is required)",
      "OTP (Change Password)": "[Name], [OTP], [Expiration Time] ([OTP] is required)",
      "Visitor Account Creation": "[Name]",
      "Account Creation Approval": "[Name]",
      "Reservation Approval": "[Name], [Book Title], [Author], [Pickup Date], [Hold Expiry]",
    };

    typeSelect.disabled = true;
    bodyInput.disabled = true;
    saveButton.disabled = true;
    bodyInput.value = "";
    try {
      const template = await getJson(`/sms-templates?type=${encodeURIComponent(templateType)}`);
      if (typeof template.body !== "string") {
        throw new Error("The saved template has no message content.");
      }
      bodyInput.value = template.body;
      if (help) {
        const schedule = templateType === "Due Date Reminder"
          ? " This reminder is sent automatically one day before a loan's due date."
          : "";
        help.textContent = `Available placeholders: ${placeholders[templateType] || "none"}. Placeholder names and capitalization must match exactly.${schedule}`;
      }
    } finally {
      typeSelect.disabled = false;
      bodyInput.disabled = false;
      saveButton.disabled = false;
    }
  }

  function toast(msg) {
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green">
        <div class="modal-head-pdf modal-head-green">
          <h3>Library System</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <p class="modal-message-green">${escapeHtml(msg)}</p>
          <div class="modal-foot-pdf">
            <button type="button" class="btn-submit-request" data-close-modal>Close</button>
          </div>
        </div>
      </div>`);
  }

  function updateModalFloatingLabel(field) {
    const container = field.closest(".modal-floating-field");
    if (!container) return;
    container.classList.toggle(
      "is-floating",
      field === document.activeElement ||
        Boolean(field.value) ||
        field.tagName === "SELECT",
    );
  }

  function enhanceModalFloatingLabels() {
    qsa("#modal-body input, #modal-body select, #modal-body textarea").forEach((field) => {
      if (["checkbox", "radio", "button", "submit", "reset", "hidden", "file"].includes(field.type)) return;
      if (field.classList.contains("modal-floating-control")) return;

      const wrappingLabel = field.closest("label");
      const associatedLabel = wrappingLabel ||
        (field.id ? qs(`#modal-body label[for="${CSS.escape(field.id)}"]`) : null);
      if (!associatedLabel) return;

      const labelText = associatedLabel.cloneNode(true);
      qsa("input, select, textarea, button", labelText).forEach((element) => element.remove());
      const captionText = labelText.textContent.replace(/\s+/g, " ").trim();
      if (!captionText) return;

      const caption = document.createElement("span");
      caption.className = "modal-floating-caption";
      caption.textContent = captionText;

      let container;
      if (wrappingLabel) {
        container = wrappingLabel;
        wrappingLabel.replaceChildren(caption, ...Array.from(wrappingLabel.children));
      } else {
        container = document.createElement("div");
        container.className = "modal-floating-field";
        associatedLabel.before(container);
        container.append(associatedLabel, field);
        associatedLabel.replaceChildren(caption);
      }

      container.classList.add("modal-floating-field");
      if (field.required) caption.classList.add("is-required");
      field.classList.add("modal-floating-control");
      const supportsPlaceholder = field.matches(
        "input:not([type]), input[type='text'], input[type='email'], input[type='password'], input[type='search'], input[type='tel'], input[type='url'], textarea",
      );
      if (supportsPlaceholder && !field.hasAttribute("placeholder")) {
        field.setAttribute("placeholder", " ");
      }
      updateModalFloatingLabel(field);
    });
  }

  els.modalBody.addEventListener("focusin", (event) => updateModalFloatingLabel(event.target));
  els.modalBody.addEventListener("focusout", (event) => updateModalFloatingLabel(event.target));
  els.modalBody.addEventListener("input", (event) => updateModalFloatingLabel(event.target));
  els.modalBody.addEventListener("change", (event) => updateModalFloatingLabel(event.target));

  function openModal(html) {
    els.modalBody.innerHTML = html;
    enhanceModalFloatingLabels();
    const memberRole = ["member", "visitor"].includes(String(state.currentUser?.role || "").toLowerCase());
    els.modalRoot.classList.toggle("member-role-modal", memberRole);
    els.modalRoot.classList.remove("hidden");
    els.modalRoot.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    qs('.modal-dialog-pdf[role="dialog"]', els.modalRoot)?.focus();
  }

  function closeModal() {
    els.modalRoot.classList.add("hidden");
    els.modalRoot.classList.remove("member-role-modal");
    els.modalRoot.setAttribute("aria-hidden", "true");
    els.modalBody.innerHTML = "";
    document.body.classList.remove("modal-open");
  }

  async function openContactThreadModal(threadId, allowReply) {
    try {
      const thread = await getJson(`/contact-messages/${encodeURIComponent(threadId)}`);
      if (!Array.isArray(thread.messages)) throw new Error("Invalid message thread received from the server.");
      const messages = thread.messages.map((message) => {
        const sender = message.senderType
          ? `${message.sender} (${message.senderType})`
          : message.sender;
        const replyToSender = message.replyTo
          ? message.replyTo.senderType
            ? `${message.replyTo.sender} (${message.replyTo.senderType})`
            : message.replyTo.sender
          : "";
        const replyContext = replyToSender
          ? `<span class="contact-thread-reply-context">Replying to ${escapeHtml(replyToSender)}</span>`
          : "";
        return `<article class="contact-thread-message"><div class="contact-thread-message-meta"><strong>${escapeHtml(sender)}</strong><span>${escapeHtml(formatNotificationTimestamp({ createdAt: message.createdAt, date: message.createdAt }))}</span></div>${replyContext}<p>${escapeHtml(message.body)}</p></article>`;
      }).join("");
      const content = `
        <div class="modal-sheet-pdf modal-sheet-green contact-thread-modal">
          <div class="modal-head-pdf modal-head-green">
            <h3>${escapeHtml(thread.topic || "Message Conversation")}</h3>
            <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
          </div>
          ${allowReply
            ? `<form class="modal-body-pdf" id="contact-thread-reply-form" data-thread-id="${escapeHtml(String(thread.id))}">
                <div class="contact-thread-messages">${messages || `<p class="muted">No messages in this conversation yet.</p>`}</div>
                <label for="contact-thread-reply">Your reply</label>
                <textarea id="contact-thread-reply" name="reply" rows="4" maxlength="500" required></textarea>
                <div class="modal-foot-pdf">
                  <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
                  <button type="submit" class="btn-submit-request">Send Reply</button>
                </div>
              </form>`
            : `<div class="modal-body-pdf">
                <div class="contact-thread-messages">${messages || `<p class="muted">No messages in this conversation yet.</p>`}</div>
                <div class="modal-foot-pdf">
                  <button type="button" class="btn-cancel-soft" data-close-modal>Close</button>
                  <button type="button" class="btn-submit-request" data-open-thread-reply="${escapeHtml(String(thread.id))}">Reply</button>
                </div>
              </div>`}
        </div>`;
      openModal(content);
    } catch (err) {
      toast(`Unable to load message conversation: ${err.message}`);
    }
  }

  function openAnnouncementComposer(initialAnnouncement = {}) {
    const today = new Date();
    const publicationDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    const isEditing = Boolean(initialAnnouncement.id);
    const isAdmin = state.currentUser?.role === "admin";
    const title = String(initialAnnouncement.title || "");
    const body = String(initialAnnouncement.body || "");
    const audience = String(initialAnnouncement.audience || "everyone");
    const selectedPublicationDate = String(initialAnnouncement.publicationDate || publicationDate);
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green lib-message-modal${isAdmin ? " adm-announcement-modal" : ""}">
        <div class="modal-head-pdf modal-head-green">
          <h3>${isEditing ? "Edit Announcement" : "Create Announcement"}</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form class="modal-body-pdf" id="lib-announcement-form" data-announcement-id="${escapeHtml(String(initialAnnouncement.id || ""))}">
          <label for="lib-announcement-title">Title</label>
          <input class="lib-announcement-control" id="lib-announcement-title" name="title" maxlength="100" value="${escapeHtml(title)}" required />
          <label for="lib-announcement-body">Announcement Body</label>
          <textarea id="lib-announcement-body" name="body" maxlength="2000" required>${escapeHtml(body)}</textarea>
          <label for="lib-announcement-audience">Audience</label>
          <select class="lib-announcement-control" id="lib-announcement-audience" name="audience" required>
            <option value="everyone" ${audience === "everyone" ? "selected" : ""}>Everyone</option>
            <option value="students" ${audience === "students" ? "selected" : ""}>Students</option>
            <option value="faculty" ${audience === "faculty" ? "selected" : ""}>Faculty / Teachers</option>
            <option value="visitors" ${audience === "visitors" ? "selected" : ""}>Visitors</option>
          </select>
          <label for="lib-announcement-date">Publication Date</label>
          <input class="lib-announcement-control" id="lib-announcement-date" name="publicationDate" type="date" value="${escapeHtml(selectedPublicationDate)}" min="${publicationDate}" required />
          <div class="modal-foot-pdf">
            <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
            <button type="submit" class="btn-submit-request">${isEditing ? "Save Changes" : "Publish Announcement"}</button>
          </div>
        </form>
      </div>
    `);
  }

  function renderMemberMessagePreview() {
    const preview = qs("#member-contact-preview");
    const reasonPreview = qs("#member-contact-reason-preview");
    const composeButton = qs("#compose-member-message");
    const editButton = qs("#edit-member-message");
    const sendButton = qs("#send-member-message");
    if (!preview || !reasonPreview || !composeButton || !editButton || !sendButton) return;
    preview.value = state.composedMemberMessage;
    const hasMessage = Boolean(state.composedMemberMessage);
    reasonPreview.textContent = state.composedMemberReason ? `Contact reason: ${state.composedMemberReason}` : "";
    reasonPreview.hidden = !state.composedMemberReason;
    composeButton.hidden = hasMessage;
    editButton.hidden = !hasMessage;
    sendButton.hidden = !hasMessage;
    sendButton.disabled = !hasMessage;
  }

  function memberNavItems(active) {
    const catalogOpen = active === "member-catalog" || state.catalogCategoriesOpen;
    const navIcons = {
      books: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 3.5h15v4H4zM6 9.5h14v4H6zM3 15.5h17v4H3zM8 3.5v4M16 9.5v4M9 15.5v4"/></svg>',
      bookmarks: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 4.5A1.5 1.5 0 0 1 6.5 3h10A1.5 1.5 0 0 1 18 4.5V21l-6.5-4-6.5 4zM8 6.5h8M8 9.5h8"/></svg>',
      return: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 7 4 12l5 5M4.5 12H15a5 5 0 0 1 5 5v1M13 4h6v7h-6z"/></svg>',
      checklist: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 5h11M9 12h11M9 19h11M3.5 5l1.3 1.3L7 4M3.5 12l1.3 1.3L7 11M3.5 19l1.3 1.3L7 18"/></svg>',
      contact: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="4.5" width="18" height="15" rx="2"/><circle cx="9" cy="10" r="2.2"/><path d="M5.7 16a3.4 3.4 0 0 1 6.6 0M14 9h4M14 12h4M14 15h4"/></svg>',
      calendar: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 9h18M7 13h2M12 13h2M7 17h2M12 17h2"/></svg>',
      reservations: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M7 2v4M17 2v4M3 9h18M8 14l2.5 2.5L16 11"/></svg>',
    };
    const categoryOptions = [
      "Fiction",
      "Non-fiction",
      "Literature",
      "History",
      "Science",
      "Technology",
      "Education",
      "Reference",
      "Arts and Culture",
    ];
    const items = [
      ...(state.currentUser?.role === "visitor" ? [] : [{ label: "Saved For Later", view: "member-cart", icon: navIcons.bookmarks }]),
      { label: "Books To Return", view: "member-borrowed", icon: navIcons.return },
      ...(state.currentUser?.role === "visitor" ? [{ label: "My Reservations", view: "member-reservations", icon: navIcons.reservations }] : []),
      { label: "Transactions History", view: "member-transactions", icon: navIcons.checklist },
    ];
    return `
      <button type="button" class="member-nav side-link${catalogOpen ? " active" : ""}" data-catalog-toggle aria-label="Library Catalog and Search" title="Library Catalog and Search" aria-expanded="${catalogOpen}">
        <span class="member-nav-icon">${navIcons.books}</span><span>Library Catalog and Search</span>
      </button>
      <div class="member-subnav${catalogOpen ? " is-open" : ""}" data-catalog-subnav>
        <button type="button" class="member-subnav-link${active === "member-catalog" && state.catalogCategory === "All Books" && !state.catalogCategoriesOpen ? " active" : ""}" data-go="member-catalog" data-catalog-category="All Books">All Books</button>
        <button type="button" class="member-subnav-link member-categories-toggle${state.catalogCategoriesOpen ? " active" : ""}" data-catalog-categories-toggle aria-expanded="${state.catalogCategoriesOpen}">
          Categories
        </button>
        <div class="member-category-subnav${state.catalogCategoriesOpen ? " is-open" : ""}" data-catalog-category-list>
          ${categoryOptions
            .map(
              (category) =>
                `<button type="button" class="member-category-subnav-link${state.catalogCategory === category ? " active" : ""}" data-catalog-category="${category}">${category}</button>`,
            )
            .join("")}
        </div>
      </div>
    ${items
      .map(
        ({ label, view, icon }) =>
          `<button type="button" class="member-nav side-link${view === active ? " active" : ""}" data-go="${view}" aria-label="${label}" title="${label}">${icon ? `<span class="member-nav-icon">${icon}</span>` : ""}<span>${label}</span></button>`,
      )
      .join("")}
    <button type="button" class="member-nav side-link${active.startsWith("member-contact") ? " active" : ""}" data-contact-toggle aria-label="Contact" title="Contact" aria-expanded="${state.contactSectionsOpen}">
      <span class="member-nav-icon">${navIcons.contact}</span><span>Contact</span>
    </button>
    <div class="member-subnav${state.contactSectionsOpen ? " is-open" : ""}" data-contact-subnav>
      <button type="button" class="member-subnav-link${active === "member-contact" ? " active" : ""}" data-go="member-contact">Library Contact Details</button>
      <button type="button" class="member-subnav-link${active === "member-contact-message" ? " active" : ""}" data-go="member-contact-message">Send A Message</button>
      <button type="button" class="member-subnav-link${active === "member-contact-faq" ? " active" : ""}" data-go="member-contact-faq">FAQ</button>
    </div>`;
  }

  function hydrateMemberSidebars() {
    const active = state.activeView.startsWith("member-") ? state.activeView : "member-catalog";
    const html = `
      <div class="member-brand">
        <img src="${ASSET_LOGO}" alt="" class="ggc-side-logo" width="92" height="92" />
        <p class="member-brand-title">Golden Gate Colleges Library System</p>
      </div>
      <button type="button" class="member-sidebar-toggle" data-member-sidebar-toggle aria-label="${state.memberSidebarCollapsed ? "Expand navigation" : "Collapse navigation"}" title="${state.memberSidebarCollapsed ? "Expand navigation" : "Collapse navigation"}" aria-expanded="${!state.memberSidebarCollapsed}">
        ${state.memberSidebarCollapsed
          ? '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7"/></svg>'
          : '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 4l6 6M4 4v5M4 4h5M20 20l-6-6m6 6v-5m0 5h-5"/></svg>'}
      </button>
      ${memberNavItems(active)}
      <button type="button" class="member-nav side-link${active === "member-calendar" ? " active" : ""}" data-go="member-calendar" aria-label="Calendar Of Activities" title="Calendar Of Activities"><span class="member-nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 9h18M7 13h2M12 13h2M7 17h2M12 17h2"/></svg></span><span>Calendar Of Activities</span></button>
    `;
    qsa(".member-sidebar").forEach((aside) => {
      aside.innerHTML = `<div class="member-sidebar-content">${html}</div>`;
    });
    document.body.classList.toggle("member-sidebar-collapsed", state.memberSidebarCollapsed);
  }

  function hydrateMemberProfiles() {
    const displayName = String(
      state.currentUser?.name ||
      state.currentUser?.username ||
      state.currentMemberName ||
      "User",
    ).trim();
    const initial = displayName.charAt(0).toUpperCase() || "U";

    qsa(".member-page-head").forEach((header) => {
      let menu = qs(".member-user-menu", header);
      if (!menu) {
        menu = document.createElement("div");
        menu.className = "member-user-menu";
        menu.innerHTML = `
          <button type="button" class="member-notification-button" data-go="member-notifications" aria-label="Notifications" title="Notifications">
            <img src="assets/notif.png" alt="" aria-hidden="true" />
          </button>
          <button type="button" class="member-user-avatar" aria-label="Open user menu" aria-expanded="false"></button>
          <div class="member-user-dropdown" role="menu">
            <div class="member-user-dropdown-name" data-member-display-name>User</div>
            <button type="button" data-go="member-profile" role="menuitem">Edit Profile</button>
            <button type="button" data-go="member-logout-confirm" role="menuitem">Log out</button>
          </div>`;
        header.appendChild(menu);
      }
      const avatar = qs(".member-user-avatar", menu);
      avatar.textContent = initial;
      avatar.title = displayName;
      avatar.setAttribute("aria-label", `Open user menu for ${displayName}`);
      const nameNode = qs("[data-member-display-name]", menu);
      if (nameNode) nameNode.textContent = displayName;
    });
    updateMemberNotificationIcon();
  }

  function updateMemberNotificationIcon() {
    const unreadCount = state.notifications.filter((notification) => !notification.read).length;
    qsa(".member-notification-button").forEach((button) => {
      const image = qs("img", button);
      if (image) image.src = unreadCount ? "assets/notif1.png" : "assets/notif.png";
      const label = unreadCount
        ? `Notifications, ${unreadCount} unread`
        : "Notifications, no unread notifications";
      button.setAttribute("aria-label", label);
      button.title = label;
    });
  }

  function getBook(bookId) {
    return BOOKS.find((b) => b.id === bookId);
  }

  function currentDateMMDDYYYY() {
    const date = new Date();
    return `${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")}/${date.getFullYear()}`;
  }

  function memberIdentity() {
    return {
      user: String(state.currentUser?.name || state.currentMemberName || "Member Demo").trim(),
      sid: String(state.currentUser?.schoolId || state.currentUser?.sid || "CET 123").trim(),
    };
  }

  function memberCartStorageKeys() {
    const user = state.currentUser;
    const identifiers = [
      user?.schoolId,
      user?.sid,
      user?.username,
      user?.email,
      user?.name,
      user?.id,
      state.currentMemberName,
    ]
      .map((identifier) => String(identifier || "").trim().toLowerCase())
      .filter(Boolean);
    if (!user) identifiers.push("member-demo");
    return [...new Set(identifiers)].map((identifier) => `ggc-library-cart:${identifier}`);
  }

  function memberCartStorageKey() {
    return memberCartStorageKeys()[0];
  }

  function saveMemberCart() {
    localStorage.setItem(memberCartStorageKey(), JSON.stringify(Array.from(state.cart)));
  }

  function restoreMemberCart() {
    state.cart.clear();
    const storageKeys = memberCartStorageKeys();
    for (const storageKey of storageKeys) {
      const stored = localStorage.getItem(storageKey);
      if (!stored) continue;
      const savedIds = JSON.parse(stored);
      if (!Array.isArray(savedIds)) throw new Error("Saved cart data is invalid.");
      savedIds
        .map((bookId) => String(bookId))
        .forEach((bookId) => state.cart.add(bookId));
    }
    if (state.cart.size > 0) saveMemberCart();
  }

  function hasPendingRequest(bookId) {
    const identity = memberIdentity();
    return state.pendingApprove.some(
      (r) => r.bookId === bookId && r.user === identity.user && r.memberRequest === true,
    );
  }

  function getVisitorReservation(bookId) {
    return state.memberReservations.find(
      (reservation) => String(reservation.bookId) === String(bookId) &&
        ["pending", "approved"].includes(String(reservation.status).toLowerCase()),
    );
  }

  function hasBorrowedBook(bookId) {
    return state.borrowed.some((r) => r.bookId === bookId);
  }

  function requestButton(b, source = "catalog") {
    const cartAttribute = source === "cart" ? ' data-from-cart="true"' : "";
    if (state.currentUser?.role === "visitor") {
      const reservation = getVisitorReservation(b.id);
      if (reservation) {
        if (String(reservation.status).toLowerCase() === "pending") {
          return '<span class="reservation-pending-status">Reservation Pending</span>';
        }
        return '<span class="reservation-pending-status">Waiting for pick up</span>';
      }
      if (hasBorrowedBook(b.id)) {
        return source === "catalog"
          ? '<span class="borrowed-status">Already Borrowed</span>'
          : '<button type="button" class="btn-borrow-pdf" disabled>Already Borrowed</button>';
      }
      const minimum = Number(b.reservationMinimum) || state.reservationWalkInMinimumCopies;
      if (b.avail <= minimum) {
        return `<button type="button" class="btn-borrow-pdf btn-borrow-unavailable" disabled title="Reservations require more than ${minimum} available ${minimum === 1 ? "copy" : "copies"} to preserve the walk-in minimum.">Not Reservable</button>`;
      }
      return `<button type="button" class="btn-borrow-pdf reserve-now"${cartAttribute} data-book="${escapeHtml(b.id)}">Reserve</button>`;
    }
    if (b.avail <= 0) {
      return `<button type="button" class="btn-borrow-pdf btn-borrow-unavailable" disabled title="This book is currently unavailable.">Unavailable</button>`;
    }
    if (hasPendingRequest(b.id)) {
      return `<button type="button" class="btn-borrow-pdf btn-request-pending" disabled>Request Pending</button>`;
    }
    if (hasBorrowedBook(b.id)) {
      if (source === "catalog") {
        return `<span class="borrowed-status">Already Borrowed</span>`;
      }
      return `<button type="button" class="btn-borrow-pdf" disabled>Already Borrowed</button>`;
    }
    return `<button type="button" class="btn-borrow-pdf borrow-now"${cartAttribute} data-book="${b.id}">Request To Borrow</button>`;
  }

  function bookRowActions(b, mode) {
    if (mode === "catalog") {
      if (state.currentUser?.role === "visitor") return `<div class="cell-actions">${requestButton(b)}</div>`;
      const inCart = state.cart.has(b.id);
      const cartIcon = inCart
        ? '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V20l-6-3.5L6 20z"/><path d="m9 11 2 2 4-4"/></svg>'
        : '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V20l-6-3.5L6 20z"/><path d="M12 7v6M9 10h6"/></svg>';
      const requestPending = hasPendingRequest(b.id);
      const cartLabel = requestPending
        ? "A borrow request has already been sent for this book"
        : inCart
          ? "Book is already in cart"
          : "Add book to cart";
      return `
        <div class="cell-actions">
          ${requestButton(b)}
          <button type="button" class="btn-add-cart-pdf add-cart${requestPending ? " add-cart-pending" : ""}" data-book="${b.id}" title="${cartLabel}" aria-label="${cartLabel}">
            ${cartIcon}
          </button>
        </div>`;
    }
    if (mode === "cart") {
      if (state.currentUser?.role === "visitor") {
        return `${requestButton(b, "cart")}
          <button type="button" class="btn-remove-soft remove-cart" data-book="${escapeHtml(b.id)}" title="Remove from cart" aria-label="Remove ${escapeHtml(b.title)} from cart">
            <img src="assets/ud-icons/remove.png" alt="" aria-hidden="true" />
          </button>`;
      }
      return `
        ${requestButton(b, "cart")}
        <button type="button" class="btn-remove-soft remove-cart" data-book="${b.id}" title="Remove from cart" aria-label="Remove ${escapeHtml(b.title)} from cart">
          <img src="assets/ud-icons/remove.png" alt="" aria-hidden="true" />
        </button>`;
    }
    return "";
  }

  function filteredBooks(q, category = state.catalogCategory) {
    const s = q.trim().toLowerCase();
    return BOOKS.filter((b) => {
      const matchesCategory = category === "All Books" || (b.categories || []).includes(category);
      const matchesSearch = !s || b.title.toLowerCase().includes(s) || b.author.toLowerCase().includes(s);
      return matchesCategory && matchesSearch;
    });
  }

  function renderCatalog() {
    const tbody = qs("#catalog-table tbody");
    if (!tbody) return;
    const qInput = qs("#catalog-search");
    const q = qInput?.value ?? "";
    const books = filteredBooks(q);
    tbody.innerHTML = books.length ? books
      .map(
        (b) =>
          `<tr><td class="book-title-cell">${escapeHtml(b.title.toUpperCase())}</td><td>${escapeHtml(b.author)}</td><td>${escapeHtml(b.isbn)}</td><td>${b.avail}/${
            b.total
          }</td><td>${bookRowActions(b, "catalog")}</td></tr>`,
      )
      .join("") : `<tr><td colspan="5" class="muted">No books found in this category.</td></tr>`;
  }

  function renderCart() {
    const tbody = qs("#cart-table tbody");
    const rows = BOOKS.filter((b) => state.cart.has(b.id));
    tbody.innerHTML = rows
      .map(
        (b) =>
          `<tr><td class="book-title-cell">${escapeHtml(b.title.toUpperCase())}</td><td>${escapeHtml(b.author)}</td><td>${escapeHtml(b.isbn)}</td><td>${b.avail}/${
            b.total
          }</td><td><div class="cell-actions">${bookRowActions(b, "cart")}</div></td></tr>`,
      )
      .join("");
    if (!rows.length)
      tbody.innerHTML = `<tr><td colspan="5" class="muted">Cart is empty — add titles from Library Catalog.</td></tr>`;
    const borrowAll = qs("#borrow-all");
    if (borrowAll) {
      borrowAll.classList.toggle("hidden", state.currentUser?.role === "visitor");
      borrowAll.disabled = state.currentUser?.role === "visitor" || rows.filter((b) => b.avail > 0).length === 0;
    }
  }

  function renderBorrowed() {
    const tbody = qs("#borrowed-table tbody");
    const identity = memberIdentity();
    tbody.innerHTML = state.borrowed
      .map((br) => {
        const b = getBook(br.bookId);
        if (!b) return "";
        if (br.user && br.user !== identity.user) return "";
        return `<tr><td>${escapeHtml(b.title)}</td><td>${escapeHtml(b.author)}</td><td>${br.borrowed}</td><td>${br.due}</td><td><span class="return-process-guidance">Walk-in return at the library counter</span></td></tr>`;
      })
      .join("");
    if (!tbody.innerHTML.trim()) {
      tbody.innerHTML = `<tr><td colspan="5" class="muted">No currently borrowed books.</td></tr>`;
    }
  }

  function renderMemberNotifications() {
    const ul = qs("#member-notifications");
    const tabs = qsa(".member-notification-tab");
    tabs.forEach((tab) => {
      const active = tab.getAttribute("data-notification-filter") === state.notificationFilter;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });

    if (state.notificationFilter === "sent") {
      const sentMessages = [...state.sentMessages].sort(compareNotificationRecency);
      ul.innerHTML = sentMessages.length
        ? sentMessages
          .map((message) => {
            const idx = state.sentMessages.indexOf(message);
            return `<li class="member-sent-message"><div class="member-sent-message-content"><div class="member-notification-summary-meta"><span>${escapeHtml(formatNotificationTimestamp({ createdAt: message.date, date: message.date }))}</span><span>From: You</span></div><strong>Message Conversation</strong></div><div class="member-notification-actions"><button type="button" class="btn btn-outline sm read-sent-message" data-si="${idx}">View</button><button type="button" class="btn btn-outline sm reply-sent-message" data-si="${idx}">Reply</button></div></li>`;
          })
            .join("")
        : `<li class="member-notification-empty">You have not sent any messages yet.</li>`;
      updateMemberNotificationIcon();
      return;
    }

    const visibleNotifications = state.notifications.filter((notification) => {
      if (state.notificationFilter === "all") return true;
      if (state.notificationFilter === "announcements") return notification.announcementId != null;
      if (state.notificationFilter === "transactions") {
        return /^(borrow request|book borrowing|return request|reservation)/i.test(notification.title);
      }
      if (state.notificationFilter === "messages") {
        return notification.announcementId == null && !/^(borrow request|book borrowing|return request|reservation)/i.test(notification.title);
      }
      return true;
    }).sort(compareNotificationRecency);
    ul.innerHTML = visibleNotifications.length
      ? visibleNotifications
      .map(
        (notification) => {
          const idx = state.notifications.indexOf(notification);
          const sender = notification.senderType
            ? `${notification.sender || "System Notification"} (${notification.senderType})`
            : notification.sender || "System Notification";
          const isAnnouncement = notification.announcementId != null;
          const creator = isAnnouncement ? notification.sender || "Library System" : sender;
          const audience = isAnnouncement && notification.audience
            ? `<span>Audience: ${escapeHtml(notification.audience)}</span>`
            : "";
          const content = `<div class="member-notification-content"><div class="member-notification-summary-meta"><span>${escapeHtml(formatNotificationTimestamp(notification))}</span><span>From: ${escapeHtml(creator)}</span>${audience}</div><strong>${escapeHtml(notification.title)}</strong></div>`;
          const unreadClass = notification.read ? "" : " is-unread";
          const replyButton = notification.threadId
            ? `<button type="button" class="btn btn-outline sm reply-msg" data-ni="${idx}">Reply</button>`
            : "";
          return `<li class="member-notification-item${unreadClass}">${content}<div class="table-actions member-notification-actions"><button type="button" class="btn btn-outline sm read-msg" data-ni="${idx}">View</button>${replyButton}<button type="button" class="btn btn-ghost sm remove-note" data-ni="${idx}">Remove</button></div></li>`;
        },
      )
      .join("")
      : `<li class="member-notification-empty">No notifications in this category.</li>`;
    updateMemberNotificationIcon();
  }

  function compareNotificationRecency(a, b) {
    const timeDifference = getNotificationTime(b) - getNotificationTime(a);
    if (timeDifference) return timeDifference;
    return getNotificationId(b) - getNotificationId(a);
  }

  function getNotificationTime(notification) {
    const timestamp = String(notification.createdAt || "");
    const timestampMatch = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?$/i.exec(timestamp);
    if (timestampMatch) {
      const parsedTimestamp = timestampMatch[7]
        ? Date.parse(timestamp.replace(" ", "T"))
        : new Date(
          Number(timestampMatch[1]),
          Number(timestampMatch[2]) - 1,
          Number(timestampMatch[3]),
          Number(timestampMatch[4]),
          Number(timestampMatch[5]),
          Number(timestampMatch[6] || 0),
        ).getTime();
      if (!Number.isNaN(parsedTimestamp)) return parsedTimestamp;
    }

    const dateValue = String(notification.date || "");
    const isoDate = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateValue);
    const localDate = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(dateValue);
    if (isoDate) {
      return new Date(Number(isoDate[1]), Number(isoDate[2]) - 1, Number(isoDate[3])).getTime();
    }
    if (localDate) {
      return new Date(Number(localDate[3]), Number(localDate[1]) - 1, Number(localDate[2])).getTime();
    }
    return 0;
  }

  function getNotificationId(notification) {
    const match = String(notification.id || "").match(/(\d+)$/);
    return match ? Number(match[1]) : 0;
  }

  function formatNotificationTimestamp(notification) {
    const { date, time } = getNotificationTimestampParts(notification);
    return time ? `${date} · ${time}` : date;
  }

  function getNotificationTimestampParts(notification) {
    const timestamp = String(notification.createdAt || "");
    const match = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?$/i.exec(timestamp);
    if (match) {
      const date = match[7]
        ? new Date(timestamp)
        : new Date(
          Number(match[1]),
          Number(match[2]) - 1,
          Number(match[3]),
          Number(match[4]),
          Number(match[5]),
          Number(match[6] || 0),
        );
      if (!Number.isNaN(date.getTime())) {
        const hour = date.getHours();
        const minute = String(date.getMinutes()).padStart(2, "0");
        const displayHour = hour % 12 || 12;
        const meridiem = hour >= 12 ? "PM" : "AM";
        return {
          date: formatNotificationDate(
            `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
          ),
          time: `${displayHour}:${minute} ${meridiem}`,
        };
      }
    }

    return { date: formatNotificationDate(notification.date), time: "" };
  }

  function formatNotificationDate(value) {
    const dateValue = String(value || "");
    const isoDate = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateValue);
    const localDate = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(dateValue);
    if (isoDate) return `${isoDate[2]}/${isoDate[3]}/${isoDate[1]}`;
    if (localDate) return `${localDate[1].padStart(2, "0")}/${localDate[2].padStart(2, "0")}/${localDate[3]}`;
    return "Date unavailable";
  }

  function rebuildTransactions() {
    if (state.authToken && ["member", "visitor"].includes(state.currentUser?.role)) {
      state.txn = state.memberTransactions.map((transaction) => ({
        title: transaction.title,
        author: transaction.author,
        date: transaction.returnDate || transaction.borrowDate,
        status: transaction.status === "pending"
          ? "Request Pending"
          : transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1),
      }));
      return;
    }
    const rows = [];
    const identity = memberIdentity();
    state.borrowed.forEach((br) => {
      const b = getBook(br.bookId);
      if (!b) return;
      if (br.user && br.user !== identity.user) return;
      rows.push({
        title: b.title,
        author: b.author,
        date: br.borrowed,
        status: "Borrowed",
      });
    });
    state.pendingApprove.forEach((request) => {
      if (request.user !== identity.user) return;
      rows.push({
        title: request.book,
        author: request.author,
        date: "04/16/2026",
        status: "Request Pending",
      });
    });
    state.txn = rows;
  }

  function addNotification(notification) {
    if (state.authToken && ["member", "visitor"].includes(state.currentUser?.role)) return;
    const now = new Date();
    const createdAt = [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, "0"),
      String(now.getDate()).padStart(2, "0"),
    ].join("-") + ` ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    state.notifications.unshift({
      ...notification,
      createdAt: notification.createdAt || createdAt,
      sender: notification.sender || "Library System",
    });
    updateMemberNotificationIcon();
  }

  function renderTransactionsTable() {
    rebuildTransactions();
    const tbody = qs("#txn-table tbody");
    tbody.innerHTML = state.txn
      .map(
        (t) =>
          `<tr><td>${escapeHtml(t.title)}</td><td>${escapeHtml(t.author)}</td><td>${escapeHtml(t.date)}</td><td>${escapeHtml(
            t.status,
          )}</td></tr>`,
      )
      .join("");
  }

  async function mountCalendar(container, editMode) {
    if (!container) return;
    bindCalendarControls(container, editMode);
    container.innerHTML = '<p class="lib-calendar-status" role="status">Loading calendar…</p>';
    try {
      const events = await getJson("/calendar-events");
      if (!Array.isArray(events)) throw new Error("Invalid calendar data received from the server.");
      const normalizedEvents = events.map(normalizeCalendarEvent);
      if (normalizedEvents.some((event) => !event)) {
        throw new Error("Calendar data contains an invalid activity.");
      }
      state.calendarEvents = normalizedEvents;
      renderCalendar(container, editMode);
    } catch (err) {
      container.innerHTML = `<p class="lib-calendar-status" role="alert">${escapeHtml(`Unable to load calendar: ${err.message}`)}</p>`;
      throw err;
    }
  }

  function normalizeCalendarEvent(event) {
    const id = String(event.id ?? "");
    const storedDate = String(event.event_date || "");
    const date = /^\d{4}-\d{2}-\d{2}/.test(storedDate)
      ? storedDate.slice(0, 10)
      : `${String(event.year).padStart(4, "0")}-${String(event.month).padStart(2, "0")}-${String(event.day).padStart(2, "0")}`;
    if (!id || !isValidCalendarDate(date)) return null;
    const storedType = String(event.event_type || "activity").toLowerCase();
    return {
      id,
      title: String(event.title || calendarEventTypeLabel(storedType)),
      eventType: ["holiday", "closed", "activity"].includes(storedType) ? storedType : "activity",
      date,
    };
  }

  function isValidCalendarDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const [year, month, day] = value.split("-").map(Number);
    const date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
  }

  function calendarEventTypeLabel(eventType) {
    return eventType === "closed" ? "Closed"
      : eventType === "holiday" ? "Holiday"
        : "Activity";
  }

  function bindCalendarControls(container, editMode) {
    if (container.dataset.calendarControlsBound === "true") return;
    container.dataset.calendarControlsBound = "true";
    container.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const shift = target.closest("[data-calendar-month-shift]");
      if (shift) {
        const monthDelta = Number(shift.getAttribute("data-calendar-month-shift"));
        if (Number.isInteger(monthDelta)) {
          state.calendarDate = new Date(
            state.calendarDate.getFullYear(),
            state.calendarDate.getMonth() + monthDelta,
            1,
          );
          renderCalendar(container, editMode);
        }
        return;
      }
      if (editMode && target.closest("[data-calendar-add]")) {
        openCalendarEventModal();
        return;
      }
      if (editMode) {
        const eventButton = target.closest("[data-calendar-event-id]");
        const calendarEvent = eventButton && state.calendarEvents.find(
          (item) => item.id === eventButton.getAttribute("data-calendar-event-id"),
        );
        if (calendarEvent) openCalendarEventModal(calendarEvent);
      }
    });
  }

  function renderCalendar(container, editMode) {
    if (!container) return;
    const year = state.calendarDate.getFullYear();
    const month = state.calendarDate.getMonth();
    const monthLabel = state.calendarDate.toLocaleDateString(undefined, { month: "long" });
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const daysLabels = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const monthKey = `${year}-${String(month + 1).padStart(2, "0")}-`;
    const monthEvents = state.calendarEvents.filter((calendarEvent) => calendarEvent.date.startsWith(monthKey));
    const cells = [];

    for (let cellIndex = 0; cellIndex < 42; cellIndex += 1) {
      const day = cellIndex - firstDay + 1;
      if (day < 1 || day > daysInMonth) {
        cells.push("<td></td>");
        continue;
      }
      const date = `${monthKey}${String(day).padStart(2, "0")}`;
      const dayEvents = monthEvents.filter((calendarEvent) => calendarEvent.date === date);
      const eventMarkup = dayEvents.map((calendarEvent) => {
        const eventClass = `lib-calendar-event is-${escapeHtml(calendarEvent.eventType)}`;
        const typeLabel = calendarEventTypeLabel(calendarEvent.eventType);
        const label = calendarEvent.title.toLowerCase() === typeLabel.toLowerCase()
          ? calendarEvent.title
          : `${calendarEvent.title} · ${typeLabel}`;
        return editMode
          ? `<button type="button" class="${eventClass} lib-calendar-event-button" data-calendar-event-id="${escapeHtml(calendarEvent.id)}" aria-label="Edit ${escapeHtml(calendarEvent.title)} on ${escapeHtml(date)}">${escapeHtml(label)}</button>`
          : `<span class="${eventClass}">${escapeHtml(label)}</span>`;
      }).join("");
      cells.push(`<td><span class="lib-calendar-day-number">${day}</span>${eventMarkup}</td>`);
    }

    const rows = [];
    for (let start = 0; start < cells.length; start += 7) {
      rows.push(`<tr>${cells.slice(start, start + 7).join("")}</tr>`);
    }
    container.innerHTML = `
      <div class="lib-calendar-heading">
        <div class="lib-calendar-month-navigation">
          <button type="button" class="lib-calendar-month-button" data-calendar-month-shift="-1" aria-label="Previous month">‹</button>
          <p class="cal-title">${escapeHtml(monthLabel)} <span>${year} · Calendar of Activities</span></p>
          <button type="button" class="lib-calendar-month-button" data-calendar-month-shift="1" aria-label="Next month">›</button>
        </div>
        ${editMode ? '<button type="button" class="btn btn-primary sm lib-calendar-edit" data-calendar-add>Add Activity</button>' : ""}
      </div>
      <div class="lib-calendar-legend" aria-label="Calendar legend">
        <span><i class="lib-calendar-swatch is-closed"></i>Closed</span>
        <span><i class="lib-calendar-swatch is-holiday"></i>Holiday</span>
        <span><i class="lib-calendar-swatch is-activity"></i>Activity</span>
      </div>
      <div class="lib-calendar-table-scroll">
        <table class="lib-calendar-table" aria-label="${escapeHtml(monthLabel)} ${year} calendar of activities">
          <thead><tr>${daysLabels.map((day) => `<th scope="col">${day}</th>`).join("")}</tr></thead>
          <tbody>${rows.join("")}</tbody>
        </table>
      </div>
    `;
  }

  function openCalendarEventModal(calendarEvent = null) {
    const editing = Boolean(calendarEvent);
    const date = calendarEvent?.date ||
      `${state.calendarDate.getFullYear()}-${String(state.calendarDate.getMonth() + 1).padStart(2, "0")}-01`;
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green lib-calendar-event-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>${editing ? "Edit Calendar Activity" : "Add Calendar Activity"}</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form class="modal-body-pdf" id="lib-calendar-event-form">
          <label>Activity name
            <input name="title" type="text" maxlength="255" value="${escapeHtml(calendarEvent?.title || "")}" required />
          </label>
          <label>Date
            <input name="date" type="date" value="${escapeHtml(date)}" required />
          </label>
          <label>Activity type
            <select name="eventType" required>
              <option value="activity"${calendarEvent?.eventType === "activity" || !calendarEvent ? " selected" : ""}>Activity</option>
              <option value="holiday"${calendarEvent?.eventType === "holiday" ? " selected" : ""}>Holiday</option>
              <option value="closed"${calendarEvent?.eventType === "closed" ? " selected" : ""}>Closed</option>
            </select>
          </label>
          <div class="modal-foot-pdf">
            ${editing ? '<button type="button" class="btn-delete-book" id="lib-calendar-event-delete">Delete Activity</button>' : ""}
            <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
            <button type="submit" class="btn-submit-request">${editing ? "Save Changes" : "Add Activity"}</button>
          </div>
        </form>
      </div>
    `);
    const form = qs("#lib-calendar-event-form", els.modalBody);
    form?.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const submitButton = qs('button[type="submit"]', form);
      if (submitButton) submitButton.disabled = true;
      const formData = new FormData(form);
      const payload = {
        title: String(formData.get("title") || "").trim(),
        eventDate: String(formData.get("date") || ""),
        eventType: String(formData.get("eventType") || ""),
      };
      let saved = false;
      try {
        if (editing) {
          await putJson(`/calendar-events/${encodeURIComponent(calendarEvent.id)}`, payload);
        } else {
          await postJson("/calendar-events", payload);
        }
        saved = true;
        const [year, month] = payload.eventDate.split("-").map(Number);
        state.calendarDate = new Date(year, month - 1, 1);
        await mountCalendar(qs("#lib-calendar-mount"), true);
        closeModal();
        toast(editing ? "Calendar activity updated." : "Calendar activity added.");
      } catch (err) {
        if (saved) {
          closeModal();
          toast(`Calendar activity was saved, but the calendar could not refresh: ${err.message}`);
          return;
        }
        if (submitButton) submitButton.disabled = false;
        toast(`Unable to save calendar activity: ${err.message}`);
      }
    });
    qs("#lib-calendar-event-delete", els.modalBody)?.addEventListener("click", async (event) => {
      const button = event.currentTarget;
      if (!window.confirm(`Delete "${calendarEvent.title}" from the calendar?`)) return;
      button.disabled = true;
      let deleted = false;
      try {
        await deleteJson(`/calendar-events/${encodeURIComponent(calendarEvent.id)}`);
        deleted = true;
        await mountCalendar(qs("#lib-calendar-mount"), true);
        closeModal();
        toast("Calendar activity deleted.");
      } catch (err) {
        if (deleted) {
          closeModal();
          toast(`Calendar activity was deleted, but the calendar could not refresh: ${err.message}`);
          return;
        }
        button.disabled = false;
        toast(`Unable to delete calendar activity: ${err.message}`);
      }
    });
  }

  function openVisitorReservationModal(bookId, fromCart = false) {
    const book = getBook(bookId);
    if (!book || state.currentUser?.role !== "visitor") return;
    const minimum = Number(book.reservationMinimum) || state.reservationWalkInMinimumCopies;
    if (book.avail <= minimum) {
      toast(`Reservations require more than ${minimum} available ${minimum === 1 ? "copy" : "copies"} to preserve the walk-in minimum.`);
      return;
    }
    if (getVisitorReservation(bookId)) {
      toast("You already have a pending or active reservation for this book.");
      return;
    }
    if (hasBorrowedBook(bookId)) {
      toast("You already have this book checked out.");
      return;
    }
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green visitor-reservation-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>Reserve a Book</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form id="visitor-reservation-form">
          <div class="modal-body-pdf">
            <div class="book-lines"><strong>Book title:</strong> ${escapeHtml(book.title)}<br /><strong>Author:</strong> ${escapeHtml(book.author)}</div>
            <label for="visitor-reservation-pickup-date">Requested Pickup Date</label>
            <input id="visitor-reservation-pickup-date" name="pickupDate" type="date" required />
            <p class="small muted visitor-reservation-note">A librarian must approve your request before a copy is held. The hold expires at the earlier of your pickup date (valid through end of day, Batangas local time) or ${Number(book.reservationHoldDays) || state.reservationHoldDays} days after approval.</p>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
              <button type="submit" class="btn-submit-request">Submit Reservation</button>
            </div>
          </div>
        </form>
      </div>
    `);
    const dateInput = qs("#visitor-reservation-pickup-date", els.modalBody);
    dateInput.min = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Manila",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date());
    qs("#visitor-reservation-form", els.modalBody)?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const submitButton = qs('button[type="submit"]', event.currentTarget);
      if (!event.currentTarget.reportValidity()) return;
      submitButton.disabled = true;
      let submitted = false;
      try {
        await postJson("/reservations", {
          bookId: Number(book.id),
          pickupDate: dateInput.value,
        });
        submitted = true;
        if (fromCart) {
          state.cart.delete(book.id);
          saveMemberCart();
          renderCart();
        }
        closeModal();
        toast("Reservation request submitted. A copy will be held only after librarian approval.");
        try {
          await loadMemberReservations();
          renderCatalog();
          if (qs("#member-reservations-table")) renderMemberReservations();
        } catch (err) {
          toast(`Reservation submitted, but the reservation list could not refresh: ${err.message}`);
        }
      } catch (err) {
        if (!submitted) {
          submitButton.disabled = false;
          toast(`Unable to submit reservation: ${err.message}`);
        }
      }
    });
  }

  function modalBorrow(bookId, fromCart = false) {
    const b = getBook(bookId);
    if (!b) return;
    if (state.currentUser?.role === "visitor") {
      openVisitorReservationModal(bookId, fromCart);
      return;
    }
    if (b.avail <= 0) {
      toast("This book is currently unavailable.");
      return;
    }
    if (hasPendingRequest(bookId)) {
      toast("You have already sent a borrow request for this book.");
      return;
    }
    if (hasBorrowedBook(bookId)) {
      toast("This book is already in your borrowed books.");
      return;
    }
    const requestDate = currentDateMMDDYYYY();
    openModal(`
      <div class="modal-sheet-pdf">
        <div class="modal-head-pdf modal-head-green">
          <h3>Request To Borrow</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <div class="book-lines"><strong>Book title:</strong> ${escapeHtml(b.title)}<br /><strong>Author:</strong> ${escapeHtml(
      b.author,
    )}</div>
          <div class="date-box-pdf">
            <div class="row-date"><span>Request Date</span><span>${requestDate}</span></div>
          </div>
          <p style="font-size:0.82rem;margin:0">Submit this request for librarian approval. The book will only be borrowed after approval.</p>
          <div class="modal-foot-pdf">
            <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
            <button type="button" class="btn-submit-request" id="confirm-borrow-final" data-book="${bookId}">Submit Request</button>
          </div>
        </div>
      </div>`);
    qs("#confirm-borrow-final", els.modalBody)?.addEventListener("click", async () => {
      closeModal();
      const identity = memberIdentity();
      let transactionId;
      if (state.authToken) {
        try {
          const result = await postJson("/transactions/borrow", { bookId: Number(bookId) });
          transactionId = result.transactionId;
        } catch (err) {
          toast(`Unable to submit borrow request: ${err.message}`);
          return;
        }

      }
      state.pendingApprove.unshift({
        transactionId,
        memberRequest: true,
        user: identity.user,
        sid: identity.sid,
        bookId,
        book: b.title,
        author: b.author,
      });
      if (fromCart || state.cart.has(bookId)) {
        state.cart.delete(bookId);
        saveMemberCart();
      }
      addNotification({
        date: requestDate,
        title: "Borrow Request Submitted",
        body: `Your request to borrow ${b.title} is waiting for librarian approval.`,
        read: true,
      });
      toast("Borrow request submitted for librarian approval.");
      openModal(`
      <div class="modal-sheet-pdf">
        <div class="modal-head-pdf modal-head-green"><h3>Request Submitted</h3><button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button></div>
        <div class="modal-body-pdf">
          <p><strong>Your borrow request has been submitted.</strong></p>
          <p class="muted">${escapeHtml(b.title)} will be added to your borrowed books after the librarian approves it.</p>
          <div class="modal-foot-pdf"><button type="button" class="btn-submit-request" id="borrow-success-close">Continue Browsing</button></div>
        </div>
      </div>`);
      qs("#borrow-success-close", els.modalBody)?.addEventListener("click", () => {
        closeModal();
        navigate("member-catalog");
      });
      if (qs("#catalog-table")) renderCatalog();
      if (qs("#cart-table")) renderCart();
      if (qs("#txn-table")) renderTransactionsTable();
    });
  }

  function modalBorrowAll() {
    if (state.currentUser?.role === "visitor") {
      toast("Visitor accounts reserve books directly from the catalog.");
      return;
    }
    const rows = BOOKS.filter((b) => state.cart.has(b.id) && b.avail > 0);
    if (!rows.length) {
      toast("There are no borrowable books in your cart.");
      return;
    }
    const requestDate = currentDateMMDDYYYY();
    openModal(`
      <div class="modal-sheet-pdf">
        <div class="modal-head-pdf modal-head-green">
          <h3>Borrow All Books</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <p>Submit one request for the following books:</p>
          <ul class="modal-book-list">${rows
            .map((b) => `<li><strong>${escapeHtml(b.title)}</strong><br /><span class="muted">${escapeHtml(b.author)}</span></li>`)
            .join("")}</ul>
          <div class="date-box-pdf">
            <div class="row-date"><span>Request Date</span><span>${requestDate}</span></div>
          </div>
          <p style="font-size:0.82rem;margin:0">The books will be added to Returning Books only after the librarian approves the request.</p>
          <div class="modal-foot-pdf">
            <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
            <button type="button" class="btn-submit-request" id="confirm-borrow-all">Submit Request</button>
          </div>
        </div>
      </div>`);
    qs("#confirm-borrow-all", els.modalBody)?.addEventListener("click", async () => {
      const identity = memberIdentity();
      const requests = [];
      try {
        for (const b of rows) {
          let transactionId;
          if (state.authToken) {
            const result = await postJson("/transactions/borrow", { bookId: Number(b.id) });
            transactionId = result.transactionId;
          }
          requests.push({ transactionId, memberRequest: true, batchRequest: true, user: identity.user, sid: identity.sid, bookId: b.id, book: b.title, author: b.author });
        }
      } catch (err) {
        toast(`Unable to submit borrow request: ${err.message}`);
        return;
      }
      closeModal();
      state.pendingApprove.unshift(...requests);
      state.cart.clear();
      saveMemberCart();
      addNotification({
        date: requestDate,
        title: "Borrow Request Submitted",
        body: `Your request for ${rows.length} book${rows.length === 1 ? "" : "s"} is waiting for librarian approval.`,
        read: true,
      });
      toast("Borrow request submitted for librarian approval.");
      renderCart();
      renderTransactionsTable();
    });
  }

  let libInventoryRenderId = 0;

  async function renderLibInventory() {
    const renderId = ++libInventoryRenderId;
    const query = qs("#lib-inv-search")?.value || "";
    let copiesByBook = new Map();
    let barcodeError = "";
    try {
      const copies = await getJson("/books/copies");
      if (!Array.isArray(copies)) throw new Error("Invalid copy barcode data received from the server.");
      copies.forEach((copy) => {
        const bookId = String(copy.bookId);
        if (!copiesByBook.has(bookId)) copiesByBook.set(bookId, []);
        copiesByBook.get(bookId).push(String(copy.barcode));
      });
    } catch (err) {
      barcodeError = err.message;
    }
    if (renderId !== libInventoryRenderId) return;
    const rows = filteredBooks(query, "All Books").map(
      (b) => {
        const barcodes = copiesByBook.get(String(b.id)) || [];
        const barcodeCell = barcodeError
          ? `<span class="muted">Unable to load</span>`
          : barcodes.length
            ? `<button type="button" class="lib-inventory-barcode-button" data-book="${escapeHtml(b.id)}" aria-label="View ${barcodes.length} barcodes for ${escapeHtml(b.title)}">View ${barcodes.length} ${barcodes.length === 1 ? "barcode" : "barcodes"}</button>`
            : `<span class="muted">No copies</span>`;
        return `<tr><td>${escapeHtml(b.title)}</td><td>${escapeHtml(b.author)}</td><td>${escapeHtml(b.isbn)}</td><td class="avail-num">${b.avail}/${b.total}</td><td class="lib-inventory-barcode-cell">${barcodeCell}</td><td class="lib-inventory-actions"><button type="button" class="btn-deactivate btn-edit-book" data-book="${b.id}">Edit Book</button></td></tr>`;
      },
    ).join("");
    qsa("#lib-inv-table tbody").forEach((tbody) => {
      tbody.innerHTML = rows || `<tr><td colspan="6" class="muted">No books found in the catalog.</td></tr>`;
    });
    if (barcodeError) toast(`Unable to load inventory barcodes: ${barcodeError}`);
  }

  async function openBookBarcodesModal(book) {
    let copyRows;
    try {
      copyRows = await getJson(`/books/${encodeURIComponent(book.id)}/copies`);
      if (!Array.isArray(copyRows)) throw new Error("Invalid copy barcode data received from the server.");
    } catch (err) {
      toast(`Unable to load copy barcodes: ${err.message}`);
      return;
    }
    const activeCopies = copyRows.filter((copy) => copy.isActive);
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green lib-book-barcodes-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>Copy Barcodes</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <div class="lib-barcode-book-details">
            <h4>${escapeHtml(book.title)}</h4>
            <p><span>Author</span>${escapeHtml(book.author)}</p>
            <p><span>ISBN</span>${escapeHtml(book.isbn)}</p>
            <p><span>Active copies</span>${activeCopies.length}</p>
          </div>
          ${activeCopies.length
            ? `<ol class="lib-barcode-copy-list">${activeCopies.map((copy) => `<li><span>Copy ${escapeHtml(copy.id)}</span><code>${escapeHtml(copy.barcode)}</code></li>`).join("")}</ol>`
            : '<p class="muted">There are no active copy barcodes for this book.</p>'}
          <p class="small muted">Each barcode uniquely identifies one active physical copy. Barcode label printing and scanning are not available yet.</p>
          <div class="modal-foot-pdf"><button type="button" class="btn-submit-request" data-close-modal>Close</button></div>
        </div>
      </div>
    `);
  }

  async function openBookEditModal(book, values = book) {
    let copyRows;
    try {
      copyRows = await getJson(`/books/${encodeURIComponent(book.id)}/copies`);
      if (!Array.isArray(copyRows)) throw new Error("Invalid copy barcode data received from the server.");
    } catch (err) {
      toast(`Unable to load copy barcodes: ${err.message}`);
      return;
    }
    const totalValue = Number(values.total ?? book.total);
    const totalStock = Number.isInteger(totalValue) && totalValue > 0
      ? String(totalValue)
      : "";
    const activeCodes = copyRows.filter((copy) => copy.isActive);
    const inactiveCodes = copyRows.filter((copy) => !copy.isActive);
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green lib-book-edit-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>Edit Book</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form id="lib-edit-book-form" data-book-id="${escapeHtml(book.id)}">
          <div class="modal-body-pdf">
            <label for="lib-edit-book-title">Name</label>
            <input id="lib-edit-book-title" name="title" type="text" maxlength="255" value="${escapeHtml(values.title)}" required />
            <label for="lib-edit-book-author">Author</label>
            <input id="lib-edit-book-author" name="author" type="text" maxlength="255" value="${escapeHtml(values.author)}" required />
            <label for="lib-edit-book-isbn">ISBN</label>
            <input id="lib-edit-book-isbn" name="isbn" type="text" maxlength="255" value="${escapeHtml(values.isbn)}" required />
            <label for="lib-edit-book-total">Total Stock</label>
            <input id="lib-edit-book-total" name="total" type="number" min="1" step="1" value="${totalStock}" required />
            <label for="lib-edit-book-available">Available Copies</label>
            <input id="lib-edit-book-available" name="available" type="number" min="0" ${totalStock ? `max="${totalStock}"` : ""} step="1" value="${escapeHtml(values.available ?? values.avail ?? 0)}" required />
            <label for="lib-edit-book-barcodes">Active copy barcodes (${activeCodes.length})</label>
            <textarea id="lib-edit-book-barcodes" class="lib-book-barcodes" rows="5" readonly>${escapeHtml(activeCodes.map((copy) => copy.barcode).join("\n"))}</textarea>
            <p class="small muted">Each value identifies one physical copy. Barcode label rendering and scanning will be added with the circulation workflow.</p>
            ${inactiveCodes.length ? `<details class="lib-retired-barcodes"><summary>Retired copy barcodes (${inactiveCodes.length})</summary><textarea rows="3" readonly>${escapeHtml(inactiveCodes.map((copy) => copy.barcode).join("\n"))}</textarea></details>` : ""}
            <div class="modal-foot-pdf lib-book-edit-actions">
              <button type="button" class="btn-delete-book" id="lib-edit-book-delete">Delete Book</button>
              <div>
                <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
                <button type="submit" class="btn-submit-request">Save Changes</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    `);

    const form = qs("#lib-edit-book-form", els.modalBody);
    const totalInput = qs("#lib-edit-book-total", form);
    const availableInput = qs("#lib-edit-book-available", form);
    totalInput?.addEventListener("input", () => {
      if (availableInput) {
        if (totalInput.value) availableInput.max = totalInput.value;
        else availableInput.removeAttribute("max");
      }
    });
    form?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const saveButton = qs('button[type="submit"]', form);
      if (saveButton) saveButton.disabled = true;
      try {
        await putJson(`/books/${encodeURIComponent(book.id)}`, {
          title: form.elements.title.value.trim(),
          author: form.elements.author.value.trim(),
          isbn: form.elements.isbn.value.trim(),
          total: Number(form.elements.total.value),
          available: Number(form.elements.available.value),
        });
        await loadBooks();
        renderLibInventory();
        renderCatalog();
        closeModal();
        toast("Book details updated.");
      } catch (err) {
        if (saveButton) saveButton.disabled = false;
        toast(`Unable to update book: ${err.message}`);
      }
    });

    qs("#lib-edit-book-delete", els.modalBody)?.addEventListener("click", () => {
      const draft = {
        title: form.elements.title.value,
        author: form.elements.author.value,
        isbn: form.elements.isbn.value,
        total: form.elements.total.value,
        available: form.elements.available.value,
      };
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green lib-book-delete-confirm-modal">
          <div class="modal-head-pdf modal-head-green">
            <h3>Confirm Book Deletion</h3>
          </div>
          <div class="modal-body-pdf">
            <p>Remove <strong>${escapeHtml(draft.title)}</strong> from the active catalog? It will no longer appear as available to borrow, but its past transactions will be retained.</p>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" id="lib-delete-book-cancel">Cancel</button>
              <button type="button" class="btn-delete-book" id="lib-delete-book-confirm">Delete Book</button>
            </div>
          </div>
        </div>
      `);

      qs("#lib-delete-book-cancel", els.modalBody)?.addEventListener("click", () => {
        openBookEditModal(book, draft);
      });
      qs("#lib-delete-book-confirm", els.modalBody)?.addEventListener("click", async (event) => {
        const confirmButton = event.currentTarget;
        confirmButton.disabled = true;
        try {
          await deleteJson(`/books/${encodeURIComponent(book.id)}`);
          await loadBooks();
          renderLibInventory();
          renderCatalog();
          closeModal();
          toast("Book removed from the catalog. Past transactions were retained.");
        } catch (err) {
          confirmButton.disabled = false;
          toast(`Unable to delete book: ${err.message}`);
        }
      });
    });
  }

  function filterLibBorrowTable(input) {
    const tbody = qs(input.getAttribute("data-target"));
    if (!tbody) return;

    const query = input.value.trim().toLocaleLowerCase();
    tbody.querySelector("[data-lib-search-empty]")?.remove();
    let visibleCount = 0;
    tbody.querySelectorAll("tr").forEach((row) => {
      const searchText = row.getAttribute("data-search");
      const visible = !query ? true : searchText !== null && searchText.toLocaleLowerCase().includes(query);
      row.hidden = !visible;
      if (visible && searchText !== null) visibleCount += 1;
    });

    if (query && visibleCount === 0) {
      const row = document.createElement("tr");
      row.setAttribute("data-lib-search-empty", "");
      const cell = document.createElement("td");
      cell.colSpan = Number(input.getAttribute("data-colspan")) || 1;
      cell.className = "muted";
      cell.textContent = "No matching records found.";
      row.append(cell);
      tbody.append(row);
    }
  }

  function renderLibBorrowTabs(which) {
    const borrowPanel = qs("#lib-btab-borrow");
    const retPanel = qs("#lib-btab-return");
    const histPanel = qs("#lib-btab-history");
    const reservationPanel = qs("#lib-btab-reservations");
    const finesPanel = qs("#lib-btab-fines");
    const finesInstructions = qs(".lib-fines-instructions");
    const tbodyA = qs("#lib-approve-table tbody");
    const tbodyR = qs("#lib-return-table tbody");
    const reservationBody = qs("#lib-reservations-table tbody");
    const finesBody = qs("#lib-fines-table tbody");

    const activeTab =
      which ||
      qs('[data-btab].active')?.getAttribute('data-btab') ||
      'borrow';

    if (tbodyA) {
      tbodyA.innerHTML = state.pendingApprove.length
        ? state.pendingApprove
            .map(
              (r, i) =>
                `<tr data-search="${escapeHtml(`${r.sid || ""} ${r.book || ""}`)}"><td>${escapeHtml(r.sid)}</td><td>${escapeHtml(r.user)}</td><td>${escapeHtml(r.course)}</td><td>${escapeHtml(
                  r.userType,
                )}</td><td>${escapeHtml(r.book)}</td><td>${escapeHtml(
                  r.author,
                )}</td><td><div class="table-actions"><button type="button" class="btn btn-primary sm apr" data-i="${i}">Approve</button><button type="button" class="btn btn-outline sm dec" data-i="${i}">Decline</button></div></td></tr>`,
            )
            .join("")
        : `<tr><td colspan="7" class="muted">No pending borrowing requests.</td></tr>`;
    }

    if (reservationBody) {
      reservationBody.innerHTML = state.visitorReservations.length
        ? state.visitorReservations.map((reservation) => {
          const status = String(reservation.status || "").toLowerCase();
          let actions = "";
          if (status === "pending") {
            actions = `<button type="button" class="btn btn-primary sm" data-visitor-reservation-action="approve" data-reservation-id="${escapeHtml(reservation.id)}">Approve</button><button type="button" class="btn btn-outline sm" data-visitor-reservation-action="decline" data-reservation-id="${escapeHtml(reservation.id)}">Decline</button>`;
          } else if (status === "approved") {
            actions = `<button type="button" class="btn btn-primary sm" data-visitor-reservation-action="pickup" data-reservation-id="${escapeHtml(reservation.id)}">Mark Picked Up</button>`;
          }
          return `<tr data-search="${escapeHtml(`${reservation.schoolId || ""} ${reservation.userName || ""} ${reservation.title || ""}`)}">
            <td>${escapeHtml(reservation.schoolId || "N/A")}</td>
            <td>${escapeHtml(reservation.userName)}</td>
            <td>${escapeHtml(reservation.title)}</td>
            <td>${escapeHtml(String(reservation.createdAt || "").slice(0, 10))}</td>
            <td>${escapeHtml(reservation.pickupDate)}</td>
            <td>${status === "approved" ? escapeHtml(formatReservationDeadline(reservation.expiresAt)) : "—"}</td>
            <td><div class="table-actions">${actions}</div></td>
          </tr>`;
        }).join("")
        : '<tr><td colspan="7" class="muted">No pending visitor reservation requests or active holds.</td></tr>';
    }

    const pendingReturns = state.pendingReturns.map((r, i) => ({
      ...r,
      index: i,
    }));
    if (tbodyR) {
      tbodyR.innerHTML = pendingReturns.length
        ? pendingReturns
            .map(
              (r) =>
                `<tr data-search="${escapeHtml(`${r.sid || ""} ${r.book || ""}`)}"><td>${escapeHtml(r.book)}</td><td>${escapeHtml(r.isbn)}</td><td>${escapeHtml(r.author)}</td><td>${escapeHtml(r.user)}</td><td>${escapeHtml(r.course)}</td><td>${escapeHtml(r.userType)}</td><td><button type="button" class="btn btn-primary sm mark-returned" data-i="${r.index}">Mark As Returned</button></td></tr>`,
            )
            .join("")
        : `<tr><td colspan="7" class="muted">No books are currently checked out.</td></tr>`;
    }

    const histRows = qs("#lib-history-rows");
    if (histRows) {
      histRows.innerHTML = state.historyUsers.length
        ? state.historyUsers
            .map((u) => {
              const role = String(u.role || "").toLowerCase();
              const userType = String(u.userType || "").toLowerCase();
              const course =
                role === "visitor" || userType === "visitor"
                  ? "N/A (Visitor)"
                  : ["faculty", "teacher"].includes(userType)
                    ? "N/A (Faculty)"
                    : u.course || "N/A";
              const accountType = u.userType || u.role || "N/A";
              const messageButton = state.currentUser?.role === "staff"
                ? ""
                : `<button type="button" class="btn btn-primary sm hist-msg" data-user-id="${escapeHtml(u.id)}" data-user-name="${escapeHtml(u.name)}">Message</button>`;
              return `<tr data-search="${escapeHtml(`${u.sid || ""} ${u.name || ""}`)}"><td>${escapeHtml(u.sid || "N/A")}</td><td>${escapeHtml(u.name)}</td><td>${escapeHtml(course)}</td><td>${escapeHtml(accountType)}</td><td><div class="table-actions lib-history-actions"><button type="button" class="btn btn-outline sm hist-view" data-user-id="${escapeHtml(u.id)}" data-user-name="${escapeHtml(u.name)}">View History</button>${messageButton}</div></td></tr>`;
            })
            .join("")
        : `<tr><td colspan="5" class="muted">No active user or visitor accounts.</td></tr>`;
    }

    if (finesBody) {
      finesBody.innerHTML = state.outstandingFines.length
        ? state.outstandingFines.map((fine) => {
          const amount = Number(fine.amount);
          const formattedAmount = Number.isFinite(amount)
            ? amount.toLocaleString("en-PH", { style: "currency", currency: "PHP" })
            : "—";
          const daysElapsed = Math.max(0, Number(fine.daysElapsed) || 0);
          return `<tr data-search="${escapeHtml(`${fine.schoolId || ""} ${fine.userName || ""} ${fine.title || ""}`)}">
            <td>${escapeHtml(fine.schoolId || "N/A")}</td>
            <td>${escapeHtml(fine.userName || "")}</td>
            <td>${escapeHtml(fine.userType || "")}</td>
            <td>${escapeHtml(fine.title || "")}</td>
            <td>${escapeHtml(fine.dueDate || "")}</td>
            <td>${daysElapsed} ${daysElapsed === 1 ? "day" : "days"}</td>
            <td>${escapeHtml(formattedAmount)}</td>
            <td><button type="button" class="btn btn-primary sm" data-settle-fine="${escapeHtml(fine.id)}">Mark as Paid</button></td>
          </tr>`;
        }).join("")
        : '<tr><td colspan="8" class="muted">No outstanding fines.</td></tr>';
    }

    qsa("[data-lib-borrow-search]").forEach(filterLibBorrowTable);
    if (borrowPanel) borrowPanel.classList.toggle("hidden", activeTab !== "borrow");
    if (reservationPanel) reservationPanel.classList.toggle("hidden", activeTab !== "reservations");
    if (retPanel) retPanel.classList.toggle("hidden", activeTab !== "return");
    if (histPanel) histPanel.classList.toggle("hidden", activeTab !== "history");
    if (finesPanel) finesPanel.classList.toggle("hidden", activeTab !== "fines");
    if (finesInstructions) finesInstructions.classList.toggle("hidden", activeTab !== "fines");
  }

  function renderLibOverdue() {
    const tbody = qs("#lib-overdue-table tbody");
    if (!tbody) return;
    tbody.innerHTML = state.overdueRows.length
      ? state.overdueRows
          .map(
            (r, i) =>
              `<tr><td>${escapeHtml(r.sid)}</td><td>${escapeHtml(r.user)}</td><td>${escapeHtml(r.book)}</td><td>${escapeHtml(
                r.borrowed,
              )}</td><td>${escapeHtml(r.due)}</td><td><button type="button" class="btn btn-primary sm sms" data-i="${i}">Notify through SMS</button></td></tr>`,
          )
          .join("")
      : `<tr><td colspan="6" class="muted">No overdue books found.</td></tr>`;
  }

  function renderLibInbox() {
    const ul = qs("#lib-inbox");
    if (!ul) return;
    qsa(".lib-notification-tab").forEach((tab) => {
      const active = tab.getAttribute("data-librarian-notification-filter") === state.libNotificationFilter;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", String(active));
    });
    const notifications = state.libInbox.filter((notification) => (
      ["Sent", "Received", "System"].includes(notification.kind) &&
      (state.libNotificationFilter === "all" || notification.kind === state.libNotificationFilter)
    ));
    ul.innerHTML = notifications.length
      ? notifications
          .map(
            (notification) => {
              const idx = state.libInbox.indexOf(notification);
              const { date, time } = getNotificationTimestampParts(notification);
              const sender = notification.kind === "System"
                ? "Library System"
                : notification.senderType
                  ? `${notification.from || "Library User"} (${notification.senderType})`
                  : notification.from || "Library User";
              const timestamp = time ? `${date} · ${time}` : date;
              const replyButton = ["Received", "Sent"].includes(notification.kind) && notification.threadId
                ? `<button type="button" class="btn btn-outline sm btn-reply-msg" data-idx="${idx}">Reply</button>`
                : "";
              return `<li class="${state.libReadNotificationIds.has(notification.id) ? "is-read" : "is-unread"}"><div class="lib-notice-content"><div class="lib-notification-summary-meta"><span>${escapeHtml(timestamp)}</span><span>From: ${escapeHtml(sender)}</span></div><strong class="lib-notification-topic">${escapeHtml(notification.title || "Notification")}</strong></div><div class="table-actions lib-notice-actions"><button type="button" class="btn btn-outline sm btn-read-msg" data-idx="${idx}">View</button>${replyButton}</div></li>`;
            },
          )
          .join("")
      : `<li class="lib-empty-inbox">No ${state.libNotificationFilter === "all" ? "notifications" : state.libNotificationFilter.toLowerCase() + " notifications"} yet.</li>`;
    updateLibrarianNotificationBell();
  }

  function renderLibAnnouncements() {
    const ul = qs("#lib-announcements-list");
    if (!ul) return;
    const announcements = state.libInbox.filter((notification) => notification.kind === "Announcement");
    ul.innerHTML = announcements.length
      ? announcements
          .map((announcement) => {
            const idx = state.libInbox.indexOf(announcement);
            const timestamp = formatNotificationTimestamp({
              createdAt: announcement.createdAt,
              date: announcement.date,
            });
            const editButton = String(announcement.creatorId) === String(state.currentUser?.id)
              ? `<button type="button" class="btn btn-outline sm btn-edit-announcement" data-idx="${idx}">Edit</button>`
              : "";
              return `<li class="${state.libReadNotificationIds.has(announcement.id) ? "is-read" : "is-unread"}"><div class="lib-notice-content"><div class="lib-notification-summary-meta"><span>${escapeHtml(timestamp)}</span><span>From: ${escapeHtml(announcement.creatorLabel || "Library System")}</span><span>Audience: ${escapeHtml(announcement.audience || "Everyone")}</span></div><strong class="lib-notification-topic">${escapeHtml(announcement.title || "Announcement")}</strong></div><div class="table-actions lib-notice-actions"><button type="button" class="btn btn-outline sm btn-read-msg" data-idx="${idx}">View</button>${editButton}</div></li>`;
          })
          .join("")
      : `<li class="lib-empty-inbox">No announcements yet.</li>`;
    updateLibrarianNotificationBell();
  }

  function renderLibrarianNotifications() {
    const ul = qs("#lib-dashboard-notifications");
    if (!ul) return;
    const dashboardItems = state.libInbox.filter((notification) => (
      notification.kind === "Announcement" ||
      ["Received", "Sent"].includes(notification.kind) ||
      (notification.kind === "System" && notification.source === "Borrowing")
    )).slice(0, 5);
    ul.innerHTML = dashboardItems.length
      ? dashboardItems.map((notification) => {
        const destination = notification.kind === "Announcement"
          ? "lib-announcements"
          : notification.kind === "System"
            ? "lib-borrowing"
            : "lib-messages";
        const itemType = notification.kind === "Announcement"
          ? "Announcement"
          : notification.kind === "System"
            ? "Borrow Request"
            : "Message";
        const isUnread = notification.kind !== "Sent" &&
          !state.libReadNotificationIds.has(notification.id);
        const sender = notification.kind === "Announcement"
          ? notification.creatorLabel || notification.from || "Library System"
          : notification.kind === "Sent"
            ? notification.to || "Library user"
            : notification.from || "Library System";
        const senderLabel = notification.kind === "Sent" ? "To" : "From";
        const detail = notification.kind === "Announcement"
          ? `Audience: ${notification.audience || "Everyone"}`
          : notification.excerpt || "";
        return `
          <li class="${isUnread ? "is-unread" : "is-read"}">
            <button type="button" class="lib-dashboard-notification-link" data-go="${destination}" aria-label="Open ${itemType.toLowerCase()} section: ${escapeHtml(notification.title || itemType)}">
              <span class="lib-dashboard-notification-meta">${escapeHtml(itemType)} · ${escapeHtml(
                formatNotificationTimestamp({ createdAt: notification.createdAt, date: notification.createdAt || notification.date }),
              )}</span>
              <strong>${escapeHtml(notification.title || itemType)}</strong>
              <span class="lib-dashboard-notification-meta">${senderLabel}: ${escapeHtml(sender)}</span>
              ${detail ? `<span class="lib-dashboard-notification-detail">${escapeHtml(detail)}</span>` : ""}
              ${isUnread ? '<span class="lib-dashboard-notification-unread">Unread</span>' : ""}
            </button>
          </li>
        `;
      }).join("")
      : `<li class="lib-empty-notification">No announcements, messages, or borrow requests yet.</li>`;
    updateLibrarianNotificationBell();
  }

  function updateLibrarianNotificationBell() {
    const unreadCount = state.libInbox.filter(
      (notification) => ["Received", "System"].includes(notification.kind) &&
        !state.libReadNotificationIds.has(notification.id),
    ).length;
    qsa(".staff-notification-button").forEach((button) => {
      const image = qs("img", button);
      if (image) image.src = unreadCount ? "assets/notif1.png" : "assets/notif.png";
      const label = unreadCount
        ? `Notifications, ${unreadCount} unread`
        : "Notifications, no unread notifications";
      button.setAttribute("aria-label", label);
      button.title = label;
    });
  }

  function renderAdmUsers() {
    const tbody = qs("#adm-user-rows");
    const users = state.authToken && state.currentUser?.role === "admin" ? state.adminUsers : ADMIN_USERS;
    if (state.adminUserStatus === "pending" && users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="adm-empty-user-state">No account creation requests yet.</td></tr>';
      return;
    }
    tbody.innerHTML = users.map(
      (u) =>
        `<tr><td>${escapeHtml(u.schoolId || u.sid || "")}</td><td>${escapeHtml(u.username || "")}</td><td>${escapeHtml(u.name || "")}</td><td>${escapeHtml(
          u.userType || u.type || "",
        )}</td><td>${escapeHtml(u.course || "")}</td><td><span class="account-status account-status-${escapeHtml(u.status || "unknown")}">${escapeHtml(
          u.status || "",
        )}</span></td><td>${
          state.adminUserStatus === "pending"
            ? `<button type="button" class="btn btn-primary sm admin-approve-user" data-user-id="${escapeHtml(u.id)}">Approve</button>`
            : u.status === "deactivated"
              ? `<button type="button" class="btn btn-primary sm admin-activate-user" data-user-id="${escapeHtml(u.id)}">Activate</button>`
              : `<button type="button" class="btn-deactivate admin-deactivate-user" data-user-id="${escapeHtml(u.id)}">Deactivate</button>`
        }</td></tr>`,
    ).join("");
  }

  function renderAdminDirectory() {
    const tbody = qs("#adm-directory-rows");
    if (!tbody) return;

    const allUsers = state.adminDirectoryUsers;
    const activeCount = allUsers.filter((user) => user.status === "active").length;
    const deactivatedCount = allUsers.filter((user) => user.status === "deactivated").length;
    const totalUsers = qs("#adm-directory-total-users");
    const activeAccounts = qs("#adm-directory-active-accounts");
    const deactivatedAccounts = qs("#adm-directory-deactivated-accounts");
    if (totalUsers) totalUsers.textContent = allUsers.length.toLocaleString();
    if (activeAccounts) activeAccounts.textContent = activeCount.toLocaleString();
    if (deactivatedAccounts) deactivatedAccounts.textContent = deactivatedCount.toLocaleString();

    const filter = state.adminDirectoryFilter;
    const management = qs(".adm-directory-management");
    management?.classList.toggle("adm-directory-filter-librarian", filter === "librarian");
    management?.classList.toggle("adm-directory-filter-staff", filter === "staff");
    management?.classList.toggle("adm-directory-filter-faculty", filter === "faculty");
    management?.classList.toggle("adm-directory-filter-student", filter === "student");
    management?.classList.toggle("adm-directory-filter-visitor", filter === "visitor");
    const idColumnHeading = qs(".adm-directory-id-column", management);
    if (idColumnHeading) idColumnHeading.textContent = filter === "visitor" ? "ORGANIZATION" : "ID NUMBER";
    qsa("[data-directory-create]").forEach((button) => {
      button.classList.toggle("hidden", button.getAttribute("data-directory-create") !== filter);
    });
    const search = state.adminDirectorySearch.trim().toLocaleLowerCase();
    const users = state.adminDirectoryUsers.filter((user) => {
      const userType = String(user.userType || "").toLocaleLowerCase();
      const matchesFilter =
        filter === "all" ||
        (filter === "librarian" && userType === "librarian") ||
        (filter === "staff" && ["staff", "library staff"].includes(userType)) ||
        (filter === "faculty" && ["faculty", "teacher"].includes(userType)) ||
        (filter === "student" && userType === "student") ||
        (filter === "visitor" && userType === "visitor");
      if (!matchesFilter) return false;
      if (!search) return true;

      return [
        user.schoolId,
        user.username,
        user.name,
        user.userType,
        user.course,
        user.status,
        user.createdAt,
      ].some((value) => String(value || "").toLocaleLowerCase().includes(search));
    });

    if (users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="adm-empty-user-state">No accounts found.</td></tr>';
      return;
    }

    tbody.innerHTML = users.map((user) => {
      const createdDate = user.createdAt
        ? formatNotificationDate(String(user.createdAt).slice(0, 10))
        : "";
      return `<tr>
        <td class="adm-directory-id-column">${escapeHtml(user.schoolId || "")}</td>
        <td>${escapeHtml(user.username || "")}</td>
        <td class="adm-directory-name-column">${escapeHtml(user.name || "")}</td>
        <td>${escapeHtml(user.userType || "")}</td>
        <td>${escapeHtml(user.course || "")}</td>
        <td><span class="account-status account-status-${escapeHtml(user.status || "unknown")}">${escapeHtml(user.status || "")}</span></td>
        <td class="adm-directory-date-column">${escapeHtml(createdDate)}</td>
      </tr>`;
    }).join("");
  }

  function openCreateManagedAccountModal() {
    const role = state.adminDirectoryFilter;
    if (!["librarian", "staff"].includes(role)) return;
    const roleLabel = role === "librarian" ? "Librarian" : "Library Staff";
    const usernameField = role === "librarian"
      ? `<label>Username
                <input id="adm-new-librarian-username" name="username" type="text" maxlength="255" autocomplete="username" aria-describedby="adm-new-librarian-username-error" required />
                <span class="adm-field-error" id="adm-new-librarian-username-error" aria-live="polite"></span>
              </label>`
      : "";
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green">
        <div class="modal-head-pdf modal-head-green">
          <h3>Create ${roleLabel} Account</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form id="adm-create-librarian-modal-form" data-role="${role}" novalidate>
          <div class="modal-body-pdf">
            <div class="stack-form adm-create-account-form" autocomplete="off">
              ${usernameField}
              <label>ID Number
                <input id="adm-new-librarian-school-id" name="schoolId" type="text" maxlength="255" aria-describedby="adm-new-librarian-school-id-error" required />
                <span class="adm-field-error" id="adm-new-librarian-school-id-error" aria-live="polite"></span>
              </label>
              <label>Full Name
                <input id="adm-new-librarian-name" name="name" type="text" maxlength="255" autocomplete="name" aria-describedby="adm-new-librarian-name-error" required />
                <span class="adm-field-error" id="adm-new-librarian-name-error" aria-live="polite"></span>
              </label>
              <label>Email Address
                <input id="adm-new-librarian-email" name="email" type="email" maxlength="255" autocomplete="email" aria-describedby="adm-new-librarian-email-error" required />
                ${role === "staff" ? '<small class="adm-password-guidance">Username will be generated from the part before @.</small>' : ""}
                <span class="adm-field-error" id="adm-new-librarian-email-error" aria-live="polite"></span>
              </label>
              <label>Create Password
                <span class="adm-password-input-wrap">
                  <input id="adm-new-librarian-password" name="password" type="password" minlength="8" autocomplete="new-password" aria-describedby="adm-new-librarian-password-guidance adm-new-librarian-password-error" required />
                  <button type="button" class="adm-password-toggle" data-password-toggle="adm-new-librarian-password" aria-label="Show password" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg></button>
                </span>
                <small class="adm-password-guidance" id="adm-new-librarian-password-guidance">Use at least 8 characters.</small>
                <span class="adm-field-error" id="adm-new-librarian-password-error" aria-live="polite"></span>
              </label>
              <label>Confirm Password
                <span class="adm-password-input-wrap">
                  <input id="adm-new-librarian-confirm-password" name="confirmPassword" type="password" minlength="8" autocomplete="new-password" aria-describedby="adm-new-librarian-confirm-password-error" required />
                  <button type="button" class="adm-password-toggle" data-password-toggle="adm-new-librarian-confirm-password" aria-label="Show password" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg></button>
                </span>
                <span class="adm-field-error" id="adm-new-librarian-confirm-password-error" aria-live="polite"></span>
              </label>
            </div>
            <p class="adm-form-error" id="adm-create-librarian-form-error" role="alert" aria-live="polite"></p>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
              <button type="submit" class="btn-submit-request">Create Account</button>
            </div>
          </div>
        </form>
      </div>`);
  }

  async function loadActivityLog() {
    const tbody = qs("#adm-log-rows");
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="4" class="adm-empty-activity-state">Loading activity logs…</td></tr>';
    const userType = state.adminActivityFilter === "all"
      ? ""
      : state.adminActivityFilter === "staff"
        ? "Library Staff"
        : state.adminActivityFilter[0].toUpperCase() + state.adminActivityFilter.slice(1);
    const query = new URLSearchParams();
    if (userType) query.set("userType", userType);
    if (state.adminActivityDateRange !== "all") {
      query.set("dateRange", state.adminActivityDateRange);
      if (state.adminActivityDateRange === "custom") {
        const dateFrom = state.adminActivityDateFrom;
        const dateTo = state.adminActivityDateTo;
        if (!dateFrom || !dateTo || dateFrom > dateTo) {
          tbody.innerHTML = '<tr><td colspan="4" class="adm-empty-activity-state">Choose a valid start and end date.</td></tr>';
          return;
        }
        query.set("dateFrom", dateFrom);
        query.set("dateTo", dateTo);
      }
    }
    if (state.adminActivityAction !== "all") query.set("action", state.adminActivityAction);
    if (state.adminActivitySearch.trim()) query.set("search", state.adminActivitySearch.trim());
    const queryString = query.toString();
    const path = queryString ? `/activity-log?${queryString}` : "/activity-log";
    const rows = await getJson(path);
    if (!Array.isArray(rows)) throw new Error("Invalid activity log data received from the server.");
    if (rows.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4" class="adm-empty-activity-state">No activity records found.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map((row) => {
      const datetime = String(row.datetime || "");
      const dateMatch = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/.exec(datetime);
      const displayDatetime = dateMatch
        ? `${dateMatch[2]}/${dateMatch[3]}/${dateMatch[1]} ${dateMatch[4]}:${dateMatch[5]}:${dateMatch[6]}`
        : datetime;
      const details = String(row.details || "");
      const displayDetails = details ? `${details[0].toUpperCase()}${details.slice(1)}` : "";
      return `<tr>
        <td class="adm-activity-datetime">${escapeHtml(displayDatetime)}</td>
        <td class="adm-activity-user">${escapeHtml(row.user || "")}</td>
        <td class="adm-activity-action">${escapeHtml(row.action || "")}</td>
        <td class="adm-activity-details">${escapeHtml(displayDetails)}</td>
      </tr>`;
    }).join("");
  }

  async function loadAdminCatalog() {
    const tbody = qs("#adm-catalog-table tbody");
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" class="adm-empty-catalog-state">Loading catalog…</td></tr>';
    const books = await getJson("/books");
    if (!Array.isArray(books)) throw new Error("Invalid catalog data received from the server.");
    state.adminCatalogBooks = books.map((book) => ({
      id: String(book.id ?? ""),
      title: String(book.title || ""),
      author: String(book.author || ""),
      isbn: String(book.isbn || ""),
      available: Number(book.avail) || 0,
      borrowed: Number(book.borrowed) || 0,
    }));
    renderAdmCatalog();
  }

  function renderAdmCatalog() {
    const tbody = qs("#adm-catalog-table tbody");
    if (!tbody) return;
    const books = state.adminCatalogBooks;
    const totalCopies = books.reduce((sum, book) => sum + book.available + book.borrowed, 0);
    const availableCopies = books.reduce((sum, book) => sum + book.available, 0);
    qs("#adm-catalog-titles").textContent = books.length.toLocaleString();
    qs("#adm-catalog-copies").textContent = totalCopies.toLocaleString();
    qs("#adm-catalog-available").textContent = availableCopies.toLocaleString();

    const search = state.adminCatalogSearch.trim().toLocaleLowerCase();
    const filtered = books.filter((book) =>
      !search || [book.title, book.author, book.isbn]
        .some((value) => value.toLocaleLowerCase().includes(search)),
    );

    const direction = state.adminCatalogSortDirection === "asc" ? 1 : -1;
    filtered.sort((first, second) => {
      const field = state.adminCatalogSort;
      if (["available", "borrowed", "total"].includes(field)) {
        const value = (book) => field === "total" ? book.available + book.borrowed : book[field];
        return (value(first) - value(second)) * direction;
      }
      return String(first[field] || "").localeCompare(String(second[field] || ""), undefined, {
        numeric: true,
        sensitivity: "base",
      }) * direction;
    });

    qsa(".adm-catalog-head-table th[data-catalog-sort]").forEach((th) => {
      const active = th.getAttribute("data-catalog-sort") === state.adminCatalogSort;
      th.setAttribute("aria-sort", active
        ? (state.adminCatalogSortDirection === "asc" ? "ascending" : "descending")
        : "none");
    });

    if (!filtered.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="adm-empty-catalog-state">No books match the selected filters.</td></tr>';
      return;
    }
    tbody.innerHTML = filtered.map((book) => `<tr>
      <td>${escapeHtml(book.title)}</td>
      <td>${escapeHtml(book.author)}</td>
      <td>${escapeHtml(book.isbn)}</td>
      <td>${book.available}</td>
      <td>${book.borrowed}</td>
      <td>${book.available + book.borrowed}</td>
    </tr>`).join("");
  }

  function renderAdmAnnouncements() {
    const list = qs("#adm-announcements-list");
    if (!list) return;
    list.innerHTML = state.adminAnnouncements.length
      ? state.adminAnnouncements.map((announcement, index) => {
        const announcementId = String(announcement.announcementId);
        const isUnread = !state.adminReadAnnouncementIds.has(announcementId);
        return `
        <li class="${isUnread ? "is-unread" : "is-read"}">
          <div class="adm-announcement-content">
            <div class="adm-announcement-meta">
              ${isUnread ? '<span class="adm-announcement-unread-label">Unread</span>' : ""}
              <span>Publication date: ${escapeHtml(announcement.publicationDate || announcement.date || "—")}</span>
              <span>From: ${escapeHtml(announcement.creatorLabel || "Library System")}</span>
              <span>Audience: ${escapeHtml(announcement.audience || "Everyone")}</span>
            </div>
            <strong class="adm-announcement-topic">${escapeHtml(announcement.title || "Announcement")}</strong>
          </div>
          <div class="adm-announcement-actions">
            <button type="button" class="btn btn-outline sm" data-view-admin-announcement="${index}" aria-label="View ${escapeHtml(announcement.title || "announcement")}${isUnread ? ", unread" : ""}">View</button>
            ${String(announcement.creatorId) === String(state.currentUser?.id)
              ? `<button type="button" class="btn btn-outline sm" data-edit-admin-announcement="${index}">Edit</button>`
              : ""}
          </div>
        </li>
      `;
      }).join("")
      : '<li class="adm-announcement-empty">No announcements yet.</li>';
  }

  function renderAdminDashboardAnnouncements() {
    const list = qs("#adm-dashboard-announcements");
    if (!list) return;
    const announcements = state.adminAnnouncements.slice(0, 4);
    list.innerHTML = announcements.length
      ? announcements.map((announcement) => {
        const index = state.adminAnnouncements.indexOf(announcement);
        const isUnread = !state.adminReadAnnouncementIds.has(String(announcement.announcementId));
        return `
          <li class="${isUnread ? "is-unread" : "is-read"}">
            <button type="button" class="adm-dashboard-announcement-link" data-dashboard-announcement="${index}" aria-label="Open announcements section">
              <span class="adm-dashboard-announcement-meta">From: ${escapeHtml(announcement.creatorLabel || "Library System")}</span>
              <strong>${escapeHtml(announcement.title || "Announcement")}</strong>
              <span class="adm-dashboard-announcement-meta">Audience: ${escapeHtml(announcement.audience || "Everyone")} · ${escapeHtml(announcement.publicationDate || announcement.date || "—")}</span>
              ${isUnread ? '<span class="adm-dashboard-announcement-unread">Unread</span>' : ""}
            </button>
          </li>
        `;
      }).join("")
      : '<li class="adm-dashboard-announcement-empty">No announcements yet.</li>';
  }

  function markAdminAnnouncementRead(announcement) {
    const announcementId = String(announcement.announcementId);
    state.adminReadAnnouncementIds.add(announcementId);
    renderAdmAnnouncements();
    renderAdminDashboardAnnouncements();
    try {
      const readKey = `ggc-admin-announcement-read-${state.currentUser.id}`;
      localStorage.setItem(readKey, JSON.stringify([...state.adminReadAnnouncementIds]));
    } catch (err) {
      toast(`Announcement opened, but read status could not be saved: ${err.message}`);
    }
  }

  async function loadAdminAnnouncements() {
    const list = qs("#adm-announcements-list");
    if (list) list.innerHTML = '<li class="adm-announcement-empty">Loading announcements…</li>';
    const announcements = await getJson("/announcements");
    if (!Array.isArray(announcements)) {
      throw new Error("Invalid announcements data received from the server.");
    }
    const readKey = `ggc-admin-announcement-read-${state.currentUser.id}`;
    try {
      const savedReadIds = JSON.parse(localStorage.getItem(readKey) || "[]");
      state.adminReadAnnouncementIds = new Set(
        Array.isArray(savedReadIds) ? savedReadIds.map(String) : [],
      );
    } catch (err) {
      state.adminReadAnnouncementIds = new Set();
      toast(`Unable to restore announcement read status: ${err.message}`);
    }
    state.adminAnnouncements = announcements;
    renderAdmAnnouncements();
    renderAdminDashboardAnnouncements();
  }

  function openAdminAnnouncementDetails(announcement) {
    const audienceLabels = {
      everyone: "Everyone",
      students: "Students",
      faculty: "Faculty / Teachers",
      visitors: "Visitors",
    };
    const isAdminAnnouncement = announcement.creatorRole === "admin";
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green adm-announcement-detail-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>Announcement Details</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <dl class="adm-announcement-detail-meta">
            <div><dt>Title</dt><dd>${escapeHtml(announcement.title || "Announcement")}</dd></div>
            ${isAdminAnnouncement ? '<div class="adm-system-announcement-card"><dt>Announcement Type</dt><dd>System Admin Announcement</dd></div>' : ""}
            <div><dt>From</dt><dd>${escapeHtml(announcement.creatorLabel || "Library System")}</dd></div>
            <div><dt>Audience</dt><dd>${escapeHtml(audienceLabels[announcement.audience] || announcement.audience || "Everyone")}</dd></div>
            <div><dt>Publication Date</dt><dd>${escapeHtml(announcement.publicationDate || announcement.date || "—")}</dd></div>
          </dl>
          <div class="adm-announcement-detail-message">
            <span>Message</span>
            <p>${escapeHtml(announcement.body || "")}</p>
          </div>
          <div class="modal-foot-pdf">
            <button type="button" class="btn-submit-request" data-close-modal>Close</button>
          </div>
        </div>
      </div>
    `);
  }

  function initializeReportPeriodOptions(prefix) {
    const periodSelect = qs(`#${prefix}-report-period`);
    if (!periodSelect || periodSelect.options.length) return;

    const now = new Date();
    const periods = [];
    for (let offset = 0; offset < 12; offset += 1) {
      const month = new Date(now.getFullYear(), now.getMonth() - offset, 1);
      const value = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;
      const label = month.toLocaleDateString(undefined, { month: "long", year: "numeric" });
      periods.push(`<option value="${value}">${escapeHtml(label)}</option>`);
    }
    periods.push('<option value="all">All time</option>');
    periodSelect.innerHTML = periods.join("");
  }

  function reportPeriodLabel(period) {
    if (period === "all") return "All time";
    const [year, month] = period.split("-").map(Number);
    return new Date(year, month - 1, 1).toLocaleDateString(undefined, {
      month: "long",
      year: "numeric",
    });
  }

  async function loadReportPreview(prefix) {
    const viewId = prefix === "adm" ? "adm-reports" : "lib-report";
    const reportSelect = qs(`#${prefix}-report-type`);
    const periodSelect = qs(`#${prefix}-report-period`);
    const courseSelect = prefix === "adm" ? qs("#adm-report-course") : null;
    const userTypeSelect = prefix === "adm" ? qs("#adm-report-user-type") : null;
    const accountStatusSelect = prefix === "adm" ? qs("#adm-report-account-status") : null;
    const periodControl = prefix === "adm" ? qs("#adm-report-period-control") : null;
    const courseControl = prefix === "adm" ? qs("#adm-report-course-control") : null;
    const userTypeControl = prefix === "adm" ? qs("#adm-report-user-type-control") : null;
    const accountStatusControl = prefix === "adm" ? qs("#adm-report-account-status-control") : null;
    const preview = qs(`#${prefix}-report-preview`);
    const downloadButton = qs(`#${prefix}-reports-download`);
    if (!reportSelect || !periodSelect || !preview) return;

    const reportType = reportSelect.value;
    const isCourseFilteredUsersReport = prefix === "adm" && reportType === "users";
    const isAccountStatusReport = prefix === "adm" && reportType === "user-status";
    const userType = userTypeSelect?.value || "";
    const isCourseUnavailable = ["faculty", "visitor"].includes(userType);
    const period = isCourseFilteredUsersReport || isAccountStatusReport
      ? "all"
      : periodSelect.value || "all";
    const isPeriodBased = ["circulation", "popular"].includes(reportType);
    if (periodControl) periodControl.hidden = isCourseFilteredUsersReport || isAccountStatusReport;
    if (courseControl) courseControl.hidden = !isCourseFilteredUsersReport;
    if (userTypeControl) userTypeControl.hidden = !isCourseFilteredUsersReport;
    if (accountStatusControl) accountStatusControl.hidden = !isAccountStatusReport;
    const requestId = ++reportPreviewRequestId;
    periodSelect.disabled = !isPeriodBased;
    if (courseSelect) courseSelect.disabled = !isCourseFilteredUsersReport || isCourseUnavailable;
    if (userTypeSelect) userTypeSelect.disabled = !isCourseFilteredUsersReport;
    if (accountStatusSelect) accountStatusSelect.disabled = !isAccountStatusReport;
    if (downloadButton) {
      downloadButton.disabled = true;
      downloadButton.title = "Download this report as a PDF.";
    }
    preview.innerHTML = '<p class="adm-report-preview-empty adm-report-preview-loading">Loading report preview…</p>';

    let rows;
    try {
      rows = await getJson(`/reports/${encodeURIComponent(reportType)}?period=${encodeURIComponent(period)}`);
    } catch (err) {
      if (requestId === reportPreviewRequestId && state.activeView === viewId) {
        renderReportPreviewError(err.message, prefix);
      }
      return;
    }
    if (requestId !== reportPreviewRequestId || state.activeView !== viewId) return;
    if (!Array.isArray(rows)) {
      renderReportPreviewError("Invalid report data received from the server.", prefix);
      return;
    }
    if (isAccountStatusReport && accountStatusSelect?.value) {
      rows = rows.filter((row) => row.status === accountStatusSelect.value);
    }
    if (isCourseFilteredUsersReport && courseSelect) {
      const selectedCourse = courseSelect.value;
      const userTypeRows = rows.filter((row) => {
        if (!userType) return true;
        const rowType = String(row.type || "").trim().toLocaleLowerCase();
        return userType === "faculty"
          ? ["faculty", "teacher"].includes(rowType)
          : rowType === userType;
      });
      const courses = [...new Set(userTypeRows
        .map((row) => String(row.course || "").trim())
        .filter(Boolean))]
        .sort((a, b) => a.localeCompare(b));
      courseSelect.replaceChildren(new Option("All courses", ""));
      courses.forEach((course) => courseSelect.add(new Option(course, course)));
      if (isCourseUnavailable) {
        courseSelect.value = "";
        rows = userTypeRows;
      } else {
        courseSelect.value = courses.includes(selectedCourse) ? selectedCourse : "";
        rows = courseSelect.value
          ? userTypeRows.filter((row) => String(row.course || "").trim() === courseSelect.value)
          : userTypeRows;
      }
    }
    renderReportPreview(preview, reportType, period, rows, prefix);
    if (downloadButton) downloadButton.disabled = false;
  }

  function renderReportPreviewError(message, prefix) {
    const preview = qs(`#${prefix}-report-preview`);
    if (!preview) return;
    const downloadButton = qs(`#${prefix}-reports-download`);
    if (downloadButton) downloadButton.disabled = true;
    preview.innerHTML = `<p class="adm-report-preview-error" role="alert">${escapeHtml(message || "Unable to load report preview.")}</p>`;
  }

  function renderReportPreview(preview, reportType, period, rows, prefix) {
    if (!preview) return;
    const dateIsInPeriod = (value) => {
      if (!value) return false;
      if (period === "all") return true;
      const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(String(value));
      if (!match) return false;
      return `${match[3]}-${match[1].padStart(2, "0")}` === period;
    };

    const definitions = {
      users: {
        title: "Active Users",
        periodBased: false,
        metrics: [{ label: "Active accounts", value: rows.length }],
        columns: [
          ["School ID/Organization", (row) => row.sid],
          ["Username", (row) => row.username],
          ["Full Name", (row) => row.name],
          ["Email", (row) => row.email],
          ["Contact Number", (row) => row.phone],
          ["User Type", (row) => row.type],
          ["Course", (row) => row.course],
        ],
      },
      inventory: {
        title: "Book Inventory",
        periodBased: false,
        metrics: [
          { label: "Titles", value: rows.length },
          { label: "Total Copies", value: rows.reduce((sum, row) => sum + (Number(row.total) || 0), 0) },
          { label: "Available", value: rows.reduce((sum, row) => sum + (Number(row.available) || 0), 0) },
          { label: "Borrowed", value: rows.reduce((sum, row) => sum + (Number(row.borrowed) || 0), 0) },
        ],
        columns: [
          ["ISBN", (row) => row.isbn],
          ["Title", (row) => row.title],
          ["Author", (row) => row.author],
          ["Date Added", (row) => row.dateAdded],
          ["Available", (row) => row.available],
          ["Borrowed", (row) => row.borrowed],
          ["Total Copies", (row) => row.total],
        ],
      },
      overdue: {
        title: "Overdue Books",
        periodBased: false,
        metrics: [{ label: "Overdue items", value: rows.length }],
        columns: [
          ["ISBN", (row) => row.isbn],
          ["Book Title", (row) => row.title],
          ["Author", (row) => row.author],
          ["Date Borrowed", (row) => row.borrowed],
          ["Due Date", (row) => row.due],
          ["Borrower Name", (row) => row.user],
          ["Contact Number", (row) => row.phone],
        ],
      },
      borrowed: {
        title: "Currently Borrowed Books",
        periodBased: false,
        metrics: [{ label: "Active Transactions", value: rows.reduce((sum, row) => sum + (Number(row.count) || 0), 0) }],
        columns: [
          ["ISBN", (row) => row.isbn],
          ["Title", (row) => row.title],
          ["Author", (row) => row.author],
          ["Active Transactions", (row) => row.count],
          ["Overdue", (row) => row.overdue],
          ["Awaiting Return Processing", (row) => row.returnPending],
        ],
      },
      circulation: {
        title: "Borrowing & Returns",
        periodBased: true,
        metrics: [
          { label: "Transactions", value: rows.length },
          { label: "Borrowed in Period", value: rows.filter((row) => dateIsInPeriod(row.dateBorrowed)).length },
          { label: "Returned in Period", value: rows.filter((row) => dateIsInPeriod(row.dateReturned)).length },
        ],
        columns: [
          ["School ID/Organization", (row) => row.sid],
          ["Borrower Name", (row) => row.borrower],
          ["Book Title", (row) => row.title],
          ["Date Borrowed", (row) => row.dateBorrowed],
          ["Date Returned", (row) => row.dateReturned],
        ],
      },
      popular: {
        title: "Most Borrowed Books",
        periodBased: true,
        metrics: [
          { label: "Titles Borrowed", value: rows.length },
          { label: "Total Borrows Count", value: rows.reduce((sum, row) => sum + (Number(row.count) || 0), 0) },
        ],
        columns: [
          ["Rank", (_row, index) => index + 1],
          ["ISBN", (row) => row.isbn],
          ["Title", (row) => row.title],
          ["Author", (row) => row.author],
          ["Total Borrows Count", (row) => row.count],
        ],
      },
      "user-status": {
        title: "User Accounts Status",
        periodBased: false,
        metrics: [
          { label: "Active", value: rows.filter((row) => row.status === "active").length },
          { label: "Pending", value: rows.filter((row) => row.status === "pending").length },
          { label: "Deactivated", value: rows.filter((row) => row.status === "deactivated").length },
        ],
        columns: [
          ["School ID/Organization", (row) => row.sid],
          ["Username", (row) => row.username],
          ["Full Name", (row) => row.name],
          ["User Type", (row) => row.type],
          ["Course", (row) => row.course],
          ["Account Status", (row) => row.status],
          ["Registration Date", (row) => row.createdAt],
        ],
      },
    };
    const definition = definitions[reportType];
    if (!definition) {
      renderReportPreviewError("Unknown report type.", prefix);
      return;
    }

    const summary = definition.metrics.map((metric) => `
      <article class="adm-report-metric">
        <span>${escapeHtml(metric.label)}</span>
        <strong>${Number(metric.value).toLocaleString()}</strong>
      </article>
    `).join("");
    const headers = definition.columns.map(([label]) => `<th scope="col">${escapeHtml(label)}</th>`).join("");
    const body = rows.length
      ? rows.map((row, index) => `<tr>${definition.columns.map(([, value]) => (
        `<td>${escapeHtml(value(row, index) ?? "—")}</td>`
      )).join("")}</tr>`).join("")
      : `<tr><td colspan="${definition.columns.length}" class="adm-report-empty-row">No records found for this report.</td></tr>`;
    const periodDescription = definition.periodBased
      ? `Period: ${reportPeriodLabel(period)}`
      : reportType === "users" && prefix === "adm"
        ? `User Type: ${qs("#adm-report-user-type")?.selectedOptions[0]?.textContent || "All user types"}; Course: ${qs("#adm-report-course")?.selectedOptions[0]?.textContent || "All courses"}`
        : reportType === "user-status" && prefix === "adm"
          ? `Account Status: ${qs("#adm-report-account-status")?.selectedOptions[0]?.textContent || "All statuses"}`
        : "Period cannot be applied to this report.";

    preview.innerHTML = `
      <div class="adm-report-preview-heading">
        <div>
          <h3>${escapeHtml(definition.title)}</h3>
          <p>${escapeHtml(periodDescription)}</p>
        </div>
        <span class="adm-report-row-count">${rows.length.toLocaleString()} ${rows.length === 1 ? "record" : "records"}</span>
      </div>
      <div class="adm-report-summary">${summary}</div>
      <div class="adm-report-table-scroll">
        <table class="adm-report-table">
          <thead><tr>${headers}</tr></thead>
          <tbody>${body}</tbody>
        </table>
      </div>
    `;
  }

  function pdfSafeText(value) {
    return String(value ?? "")
      .replace(/[–—]/g, "-")
      .replace(/[“”]/g, '"')
      .replace(/[‘’]/g, "'")
      .replace(/…/g, "...")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\x20-\x7E]/g, "?");
  }

  function pdfEscapeText(value) {
    return pdfSafeText(value).replace(/([\\()])/g, "\\$1");
  }

  function wrapPdfCell(value, maxChars) {
    const words = pdfSafeText(value).split(/\s+/).filter(Boolean);
    if (!words.length) return [""];
    const lines = [];
    let line = "";
    words.forEach((word) => {
      if (word.length > maxChars) {
        if (line) {
          lines.push(line);
          line = "";
        }
        for (let start = 0; start < word.length; start += maxChars) {
          lines.push(word.slice(start, start + maxChars));
        }
        return;
      }
      const next = line ? `${line} ${word}` : word;
      if (next.length > maxChars && line) {
        lines.push(line);
        line = word;
      } else {
        line = next;
      }
    });
    if (line) lines.push(line);
    return lines;
  }

  function buildReportPdf(preview) {
    const heading = preview.querySelector(".adm-report-preview-heading h3")?.textContent?.trim();
    const period = preview.querySelector(".adm-report-preview-heading p")?.textContent?.trim();
    const headers = Array.from(preview.querySelectorAll(".adm-report-table thead th"))
      .map((cell) => cell.textContent.trim());
    const rows = Array.from(preview.querySelectorAll(".adm-report-table tbody tr"))
      .map((row) => Array.from(row.querySelectorAll("td")).map((cell) => cell.textContent.trim()));
    const metrics = Array.from(preview.querySelectorAll(".adm-report-metric"))
      .map((metric) => ({
        label: metric.querySelector("span")?.textContent?.trim() || "",
        value: metric.querySelector("strong")?.textContent?.trim() || "",
      }));
    if (!heading || !headers.length || !rows.length) {
      throw new Error("The report preview is not ready to export.");
    }

    const pageWidth = 792;
    const pageHeight = 612;
    const margin = 32;
    const tableWidth = pageWidth - margin * 2;
    const fontSize = headers.length > 6 ? 6.5 : headers.length > 4 ? 7 : 8;
    const lineHeight = fontSize + 3;
    const weights = headers.map((header, index) => {
      const longest = rows.reduce((max, row) => Math.max(max, (row[index] || "").length), header.length);
      return Math.max(9, Math.min(26, longest));
    });
    const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
    const columnWidths = weights.map((weight) => tableWidth * weight / totalWeight);
    const pages = [];
    let commands = [];
    let cursorTop = 0;

    const text = (value, x, top, size, color = "0.12 0.19 0.15") => {
      const baseline = pageHeight - top - size;
      commands.push(`${color} rg BT /F1 ${size} Tf 1 0 0 1 ${x.toFixed(2)} ${baseline.toFixed(2)} Tm (${pdfEscapeText(value)}) Tj ET`);
    };
    const rect = (x, top, width, height, fill, stroke = null) => {
      const y = pageHeight - top - height;
      commands.push(`${fill} rg ${x.toFixed(2)} ${y.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re f`);
      if (stroke) {
        commands.push(`${stroke} RG 0.5 w ${x.toFixed(2)} ${y.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re S`);
      }
    };

    const drawTableHeader = () => {
      const wrappedHeaders = headers.map((header, index) => (
        wrapPdfCell(header, Math.max(8, Math.floor((columnWidths[index] - 10) / (fontSize * 0.52))))
      ));
      const headerHeight = Math.max(25, Math.max(...wrappedHeaders.map((lines) => lines.length)) * lineHeight + 8);
      let x = margin;
      columnWidths.forEach((width, index) => {
        rect(x, cursorTop, width, headerHeight, "0.11 0.29 0.21", "0.75 0.82 0.78");
        wrappedHeaders[index].forEach((line, lineIndex) => {
          text(line, x + 5, cursorTop + 4 + lineIndex * lineHeight, fontSize, "1 1 1");
        });
        x += width;
      });
      cursorTop += headerHeight;
    };

    const startPage = (firstPage) => {
      commands = [];
      if (firstPage) {
        text(heading, margin, 26, 18, "0.11 0.19 0.14");
        text(period || "Report preview", margin, 50, 9, "0.32 0.39 0.35");
        text(`Generated ${new Date().toLocaleDateString()}`, pageWidth - margin - 120, 50, 8, "0.32 0.39 0.35");
        cursorTop = 70;

        if (metrics.length) {
          const gap = 8;
          const cardWidth = (tableWidth - gap * (metrics.length - 1)) / metrics.length;
          metrics.forEach((metric, index) => {
            const x = margin + index * (cardWidth + gap);
            rect(x, cursorTop, cardWidth, 34, "0.92 0.96 0.94", "0.72 0.80 0.75");
            text(metric.label, x + 6, cursorTop + 5, 7, "0.11 0.29 0.21");
            text(metric.value, x + 6, cursorTop + 17, 11, "0.11 0.19 0.14");
          });
          cursorTop += 44;
        }
      } else {
        text(`${heading} (continued)`, margin, 24, 12, "0.11 0.19 0.14");
        cursorTop = 44;
      }
      drawTableHeader();
    };

    startPage(true);
    rows.forEach((row, rowIndex) => {
      const wrapped = headers.map((_, columnIndex) => (
        wrapPdfCell(row[columnIndex] || "", Math.max(8, Math.floor((columnWidths[columnIndex] - 10) / (fontSize * 0.52))))
      ));
      const rowHeight = Math.max(22, Math.max(...wrapped.map((lines) => lines.length)) * lineHeight + 8);
      if (cursorTop + rowHeight > pageHeight - 30) {
        pages.push(commands.join("\n"));
        startPage(false);
      }

      let x = margin;
      columnWidths.forEach((width, columnIndex) => {
        rect(
          x,
          cursorTop,
          width,
          rowHeight,
          rowIndex % 2 === 0 ? "1 1 1" : "0.95 0.97 0.96",
          "0.84 0.88 0.85",
        );
        wrapped[columnIndex].forEach((line, lineIndex) => {
          text(line, x + 5, cursorTop + 4 + lineIndex * lineHeight, fontSize);
        });
        x += width;
      });
      cursorTop += rowHeight;
    });
    pages.push(commands.join("\n"));

    const objects = [];
    objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
    objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
    const pageIds = [];
    pages.forEach((content, index) => {
      const pageId = 4 + index * 2;
      const streamId = pageId + 1;
      pageIds.push(`${pageId} 0 R`);
      objects[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 3 0 R >> >> /Contents ${streamId} 0 R >>`;
      objects[streamId] = `<< /Length ${new TextEncoder().encode(content).length} >>\nstream\n${content}\nendstream`;
    });
    objects[2] = `<< /Type /Pages /Kids [${pageIds.join(" ")}] /Count ${pages.length} >>`;

    let documentText = "%PDF-1.4\n";
    const offsets = [0];
    for (let id = 1; id < objects.length; id += 1) {
      offsets[id] = new TextEncoder().encode(documentText).length;
      documentText += `${id} 0 obj\n${objects[id]}\nendobj\n`;
    }
    const xrefOffset = new TextEncoder().encode(documentText).length;
    documentText += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
    for (let id = 1; id < objects.length; id += 1) {
      documentText += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
    }
    documentText += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
    return new Blob([new TextEncoder().encode(documentText)], { type: "application/pdf" });
  }

  function downloadReportPdf(prefix) {
    const preview = qs(`#${prefix}-report-preview`);
    const reportType = qs(`#${prefix}-report-type`)?.value || "report";
    const period = qs(`#${prefix}-report-period`)?.value || "all";
    if (!preview) throw new Error("Report preview is not available.");

    const pdf = buildReportPdf(preview);
    const link = document.createElement("a");
    const periodText = preview.querySelector(".adm-report-preview-heading p")?.textContent || "";
    const periodSuffix = periodText.startsWith("Current snapshot")
      ? "snapshot"
      : period === "all" ? "all-time" : period;
    link.href = URL.createObjectURL(pdf);
    link.download = `library-${reportType}-${periodSuffix}.pdf`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /** Delegated clicks */
  document.addEventListener("click", async (e) => {
    const t = e.target;
    if (!(t instanceof Element)) return;
    const closeRegistration = t.closest("[data-close-registration]");
    if (closeRegistration) {
      closeRegistrationModal();
      return;
    }
    const closeLogin = t.closest("[data-close-login]");
    if (closeLogin) {
      closeLoginModal();
      return;
    }
    const homeSectionLink = t.closest("[data-home-section]");
    if (homeSectionLink) {
      e.preventDefault();
      const sectionId = homeSectionLink.getAttribute("data-home-section");
      closeLoginModal(false);
      closeRegistrationModal(false);
      closeModal();
      if (state.activeView !== "home") showView("home");
      window.requestAnimationFrame(() => {
        document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      return;
    }
    const openThreadReply = t.closest("[data-open-thread-reply]");
    if (openThreadReply) {
      await openContactThreadModal(openThreadReply.getAttribute("data-open-thread-reply"), true);
      return;
    }
    const librarianNotificationFilter = t.closest("[data-librarian-notification-filter]");
    if (librarianNotificationFilter) {
      state.libNotificationFilter =
        librarianNotificationFilter.getAttribute("data-librarian-notification-filter") || "all";
      renderLibInbox();
      return;
    }
    const notificationFilter = t.closest("[data-notification-filter]");
    if (notificationFilter) {
      state.notificationFilter = notificationFilter.getAttribute("data-notification-filter") || "all";
      renderMemberNotifications();
      if (state.notificationFilter === "sent") {
        loadMemberSentMessages()
          .then(() => renderMemberNotifications())
          .catch((err) => toast(`Unable to load sent messages: ${err.message}`));
      }
      return;
    }
    const menuToggle = t.closest(".member-user-avatar, .staff-user-avatar");
    if (menuToggle) {
      const menu = menuToggle.closest(".member-user-menu, .staff-user-menu");
      const isOpen = menu?.classList.toggle("is-open") || false;
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      qsa(".member-user-menu.is-open, .staff-user-menu.is-open").forEach((other) => {
        if (other !== menu) {
          other.classList.remove("is-open");
          qs(".member-user-avatar, .staff-user-avatar", other)?.setAttribute("aria-expanded", "false");
        }
      });
      return;
    }
    qsa(".member-user-menu.is-open, .staff-user-menu.is-open").forEach((menu) => {
      if (!menu.contains(t)) {
        menu.classList.remove("is-open");
        qs(".member-user-avatar, .staff-user-avatar", menu)?.setAttribute("aria-expanded", "false");
      }
    });
    const memberSidebarToggle = t.closest("[data-member-sidebar-toggle]");
    if (memberSidebarToggle) {
      state.memberSidebarCollapsed = !state.memberSidebarCollapsed;
      document.body.classList.toggle("member-sidebar-collapsed", state.memberSidebarCollapsed);
      qsa("[data-member-sidebar-toggle]").forEach((toggle) => {
        const label = state.memberSidebarCollapsed ? "Expand navigation" : "Collapse navigation";
        toggle.setAttribute("aria-label", label);
        toggle.setAttribute("title", label);
        toggle.setAttribute("aria-expanded", String(!state.memberSidebarCollapsed));
        toggle.innerHTML = state.memberSidebarCollapsed
          ? '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7"/></svg>'
          : '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 4l6 6M4 4v5M4 4h5M20 20l-6-6m6 6v-5m0 5h-5"/></svg>';
      });
      return;
    }
    const editProfile = t.closest('[data-action="lib-edit-profile"], [data-action="staff-edit-profile"]');
    if (editProfile) {
      const menu = editProfile.closest(".staff-user-menu");
      menu?.classList.remove("is-open");
      if (menu) qs(".staff-user-avatar", menu)?.setAttribute("aria-expanded", "false");
      openRoleProfileModal(editProfile.dataset.action === "staff-edit-profile" ? "staff" : "librarian");
      return;
    }
    const closer = t.closest("[data-close-modal]");
    if (closer && closer.contains(t)) closeModal();

    const categoriesToggle = t.closest("[data-catalog-categories-toggle]");
    if (categoriesToggle) {
      state.catalogCategoriesOpen = !state.catalogCategoriesOpen;
      hydrateMemberSidebars();
      return;
    }

    const catalogCategory = t.closest("[data-catalog-category]");
    if (catalogCategory && !catalogCategory.classList.contains("member-category-card")) {
      state.catalogCategory = catalogCategory.getAttribute("data-catalog-category") || "All Books";
      state.catalogCategoriesOpen = state.catalogCategory !== "All Books";
      navigate("member-catalog");
      return;
    }

    const dashboardAnnouncement = t.closest("[data-dashboard-announcement]");
    if (dashboardAnnouncement) {
      navigate("adm-announcements");
      return;
    }

    const go = t.closest("[data-go]");
    if (go) {
      e.preventDefault();
      const target = go.getAttribute("data-go");
      if (target === "register") {
        const returnFocus = go.closest("#view-login")
          ? qs('#view-home [data-go="register"]')
          : state.activeView === "home"
            ? go
            : qs('#view-home [data-go="register"]');
        closeLoginModal(false);
        if (state.activeView !== "home") navigate("home");
        openRegistrationModal(returnFocus);
        return;
      }
      if (target === "login") {
        const returnFocus = go.closest("#view-register")
          ? qs('#view-home [data-go="login"]')
          : state.activeView === "home"
            ? go
            : qs('#view-home [data-go="login"]');
        closeRegistrationModal(false);
        if (state.activeView !== "home") showView("home");
        openLoginModal(returnFocus);
        return;
      }
      if (els.modalRoot.contains(go)) closeModal();
      closeLoginModal(false);
      closeRegistrationModal(false);
      navigate(target);
    }

    const catalogToggle = t.closest("[data-catalog-toggle]");
    if (catalogToggle) {
      const sidebar = catalogToggle.closest(".member-sidebar");
      const subnav = qs("[data-catalog-subnav]", sidebar);
      const isOpen = subnav?.classList.toggle("is-open") || false;
      catalogToggle.classList.toggle("active", isOpen);
      catalogToggle.setAttribute("aria-expanded", String(isOpen));
      if (isOpen) navigate("member-catalog");
      return;
    }

    const contactToggle = t.closest("[data-contact-toggle]");
    if (contactToggle) {
      state.contactSectionsOpen = !state.contactSectionsOpen;
      hydrateMemberSidebars();
      if (state.contactSectionsOpen) navigate("member-contact");
      return;
    }

    const approveUser = t.closest(".admin-approve-user");
    if (approveUser) {
      try {
        await postJson(`/users/${approveUser.getAttribute("data-user-id")}/approve`, {});
        toast("User account approved. Approval SMS sent (demo mode).");
        await loadAdminUsers("pending");
        await loadAdminDashboardStats();
      } catch (err) {
        toast(`Unable to approve account: ${err.message}`);
      }
      return;
    }

    const deactivateUser = t.closest(".admin-deactivate-user");
    if (deactivateUser) {
      deactivateUser.disabled = true;
      try {
        await postJson(`/users/${deactivateUser.getAttribute("data-user-id")}/deactivate`, {});
        toast("Account deactivation successful.");
      } catch (err) {
        deactivateUser.disabled = false;
        toast(`Unable to deactivate account: ${err.message}`);
        return;
      }
      try {
        await loadAdminUsers("all");
        await loadAdminDashboardStats();
      } catch (err) {
        toast(`Account deactivated, but the user list could not be refreshed: ${err.message}`);
      }
      return;
    }

    const activateUser = t.closest(".admin-activate-user");
    if (activateUser) {
      activateUser.disabled = true;
      try {
        await postJson(`/users/${activateUser.getAttribute("data-user-id")}/activate`, {});
        toast("Account reactivation successful.");
      } catch (err) {
        activateUser.disabled = false;
        toast(`Unable to activate account: ${err.message}`);
        return;
      }
      try {
        await loadAdminUsers("all");
        await loadAdminDashboardStats();
      } catch (err) {
        toast(`Account reactivated, but the user list could not be refreshed: ${err.message}`);
      }
      return;
    }

    const cancelReservation = t.closest(".cancel-visitor-reservation");
    if (cancelReservation) {
      const reservationId = cancelReservation.getAttribute("data-reservation-id");
      const reservation = state.memberReservations.find(
        (row) => String(row.id) === String(reservationId),
      );
      if (!reservation) {
        toast("Unable to find this reservation. Refresh the page and try again.");
        return;
      }
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green reservation-cancel-confirm-modal">
          <div class="modal-head-pdf modal-head-green">
            <h3>Cancel Reservation?</h3>
            <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
          </div>
          <div class="modal-body-pdf">
            <p>Are you sure you want to cancel your reservation for <strong>${escapeHtml(reservation.title)}</strong>?${String(reservation.status).toLowerCase() === "approved" ? " The reserved copy will become available to other borrowers." : ""}</p>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" data-close-modal>Keep Reservation</button>
              <button type="button" class="reservation-cancel-confirm" id="confirm-cancel-visitor-reservation">Cancel Reservation</button>
            </div>
          </div>
        </div>
      `);
      qs("#confirm-cancel-visitor-reservation", els.modalBody)?.addEventListener("click", async (event) => {
        const confirmButton = event.currentTarget;
        confirmButton.disabled = true;
        let cancelled = false;
        try {
          await deleteJson(`/reservations/${encodeURIComponent(reservationId)}`);
          cancelled = true;
          closeModal();
          toast("Reservation cancelled. Any held copy is available again.");
          try {
            await loadMemberReservations();
            renderMemberReservations();
          } catch (err) {
            toast(`Reservation cancelled, but the reservation list could not refresh: ${err.message}`);
          }
        } catch (err) {
          if (!cancelled) {
            confirmButton.disabled = false;
            toast(`Unable to cancel reservation: ${err.message}`);
          }
        }
      });
      return;
    }

    const reservationAction = t.closest("[data-visitor-reservation-action]");
    if (reservationAction) {
      const action = reservationAction.getAttribute("data-visitor-reservation-action");
      const reservationId = reservationAction.getAttribute("data-reservation-id");
      const actionRoute = {
        approve: "approve",
        decline: "decline",
        pickup: "pickup",
      }[action];
      if (!actionRoute) return;
      reservationAction.disabled = true;
      let updated = false;
      try {
        const result = await postJson(`/reservations/${encodeURIComponent(reservationId)}/${actionRoute}`, {});
        updated = true;
        const approvalToast = result.smsStatus
          ? {
            sent: "Visitor reservation approved and approval SMS sent.",
            demo: "Visitor reservation approved. SMS is in demo mode and was not delivered.",
            unavailable: "Visitor reservation approved, but the visitor has no phone number on file.",
            failed: "Visitor reservation approved, but the approval SMS failed. Check the server logs.",
          }[result.smsStatus] || "Visitor reservation approved."
          : "Visitor reservation approved and one copy held.";
        toast(action === "approve" ? approvalToast : {
          approve: "Visitor reservation approved and one copy held.",
          decline: "Visitor reservation declined.",
          pickup: "Reserved book pickup recorded.",
        }[action]);
        try {
          await loadPendingTransactions("reservations");
          if (action === "approve" || action === "pickup") await loadBooks();
        } catch (err) {
          toast(`Reservation ${action} completed, but the librarian list could not refresh: ${err.message}`);
        }
      } catch (err) {
        if (!updated) {
          reservationAction.disabled = false;
          toast(`Unable to ${action} visitor reservation: ${err.message}`);
        }
      }
      return;
    }

    const settleFine = t.closest("[data-settle-fine]");
    if (settleFine) {
      const fineId = settleFine.getAttribute("data-settle-fine");
      const fine = state.outstandingFines.find((item) => String(item.id) === String(fineId));
      const amount = Number(fine?.amount);
      const amountText = Number.isFinite(amount)
        ? amount.toLocaleString("en-PH", { style: "currency", currency: "PHP" })
        : "this fine";
      if (!fineId || !window.confirm(
        `Have you reviewed the user's payment receipt and verified payment of ${amountText}? This clears this fine. Borrowing and reservation permission is restored only when all other fines are settled and no overdue books remain.`,
      )) return;
      settleFine.disabled = true;
      let settled = false;
      try {
        const result = await postJson(`/fines/${encodeURIComponent(fineId)}/settle`, {});
        settled = true;
        try {
          await loadOutstandingFines();
        } catch (err) {
          toast(`Fine settlement was recorded, but the outstanding fine list could not refresh: ${err.message}`);
          return;
        }
        toast(result.borrowingPermissionRestored
          ? "Payment receipt verified. Borrowing and reservation permission has been restored."
          : "Payment receipt verified and this fine was settled. The account remains restricted until all other fines are settled and overdue books are returned.");
      } catch (err) {
        if (!settled) {
          settleFine.disabled = false;
          toast(`Unable to record fine settlement: ${err.message}`);
        }
      }
      return;
    }

    const addCart = t.closest(".add-cart");
    if (addCart) {
      if (state.currentUser?.role === "visitor") {
        toast("Visitor accounts reserve books directly from the catalog.");
        return;
      }
      const bookId = addCart.getAttribute("data-book");
      const book = getBook(bookId);
      if (!book) return;
      if (book.avail <= 0) {
        toast("This book cannot be added to your saved for later list because it is currently unavailable.");
        return;
      }
      if (hasPendingRequest(bookId)) {
        toast("You have already sent a borrow request for this book.");
        return;
      }
      if (hasBorrowedBook(bookId)) {
        toast("This book is already in your borrowed books.");
        return;
      }
      if (state.cart.has(bookId)) {
        toast("This book is already in your saved list.");
        return;
      }
      state.cart.add(bookId);
      saveMemberCart();
      renderCatalog();
      toast("Book added to Saved For Later");
      return;
    }
    const remCart = t.closest(".remove-cart");
    if (remCart) {
      state.cart.delete(remCart.getAttribute("data-book"));
      saveMemberCart();
      renderCart();
      toast("Book removed from the list");
      return;
    }
    const bw = t.closest(".borrow-now");
    if (bw) {
      modalBorrow(bw.getAttribute("data-book"), bw.hasAttribute("data-from-cart"));
      return;
    }
    const reserve = t.closest(".reserve-now");
    if (reserve) {
      openVisitorReservationModal(reserve.getAttribute("data-book"), reserve.hasAttribute("data-from-cart"));
      return;
    }

    const borrowAll = t.closest("#borrow-all");
    if (borrowAll) {
      modalBorrowAll();
      return;
    }

    const readSent = t.closest(".read-sent-message");
    if (readSent) {
      const message = state.sentMessages[Number(readSent.getAttribute("data-si"))];
      if (!message) return;
      await openContactThreadModal(message.threadId, false);
      return;
    }

    const replySent = t.closest(".reply-sent-message");
    if (replySent) {
      const message = state.sentMessages[Number(replySent.getAttribute("data-si"))];
      if (message) await openContactThreadModal(message.threadId, true);
      return;
    }

    const replyNotification = t.closest(".reply-msg");
    if (replyNotification) {
      const notification = state.notifications[Number(replyNotification.getAttribute("data-ni"))];
      if (notification?.threadId) await openContactThreadModal(notification.threadId, true);
      return;
    }

    const read = t.closest(".read-msg");
    if (read) {
      const notification = state.notifications[Number(read.getAttribute("data-ni"))];
      if (!notification) return;
      if (!notification.read && notification.id && state.authToken) {
        try {
          await putJson(`/notifications/${encodeURIComponent(notification.id)}/read`, {});
        } catch (err) {
          toast(`Unable to mark notification as read: ${err.message}`);
          return;
        }
      }
      notification.read = true;
      renderMemberNotifications();
      if (notification.threadId) {
        await openContactThreadModal(notification.threadId, false);
        return;
      }
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green member-notification-detail-modal${notification.announcementId != null && notification.announcementCreatorRole === "admin" ? " adm-origin-announcement" : ""}">
          <div class="modal-head-pdf modal-head-green">
            <h3>${escapeHtml(notification.title)}</h3>
            <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
          </div>
          <div class="modal-body-pdf">
            <div class="notice-meta">${escapeHtml(formatNotificationDate(notification.date))}</div>
            ${notification.announcementId != null ? `
              <div class="member-announcement-origin-card">
                ${notification.announcementCreatorRole === "admin" ? "<strong>System Admin Announcement</strong>" : ""}
                <span>From: ${escapeHtml(notification.sender || "Library System")}</span>
                <span>Audience: ${escapeHtml(notification.audience || "Everyone")}</span>
              </div>` : ""}
            ${notification.repliedMessage ? `<div class="member-notification-detail-message"><strong class="member-notification-detail-label">Your Message:</strong><p>${escapeHtml(notification.repliedMessage)}</p></div>` : ""}
            <div class="member-notification-detail-message"><strong class="member-notification-detail-label">${notification.announcementId != null ? "Announcement" : "Replied"}:</strong><p>${escapeHtml(notification.body)}</p></div>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-submit-request" data-close-modal>Close</button>
            </div>
          </div>
        </div>`);
    }

    const rm = t.closest(".remove-note");
    if (rm) {
      const i = Number(rm.getAttribute("data-ni"));
      const notification = state.notifications[i];
      if (notification?.id && state.authToken) {
        try {
          await deleteJson(`/notifications/${notification.id}`);
        } catch (err) {
          toast(`Unable to remove notification: ${err.message}`);
          return;
        }
      }
      state.notifications.splice(i, 1);
      renderMemberNotifications();
    }

    const apr = t.closest(".apr");
    if (apr) {
      const i = Number(apr.getAttribute("data-i"));
      const request = state.pendingApprove.splice(i, 1)[0];
      const serverBackedRequest = request?.transactionId && state.authToken;
      let approvalDates = null;
      if (request?.transactionId && state.authToken) {
        try {
          approvalDates = await postJson(`/transactions/${request.transactionId}/approve`, {});
        } catch (err) {
          state.pendingApprove.splice(i, 0, request);
          toast(`Unable to approve request: ${err.message}`);
          renderLibBorrowTabs("borrow");
          return;
        }
      }
      if (request) {
        const borrowedDate = approvalDates?.borrowDate || new Date().toLocaleDateString("en-US");
        const dueDate = approvalDates?.dueDate || borrowedDate;
        state.borrowed.unshift({ bookId: request.bookId, borrowed: borrowedDate, due: dueDate, user: request.user });
        addNotification({
          date: borrowedDate,
          title: "Borrow Request Approved",
          body: `Your request to borrow ${request.book} was approved.`,
          read: false,
        });
      }
      if (serverBackedRequest) {
        try {
          await loadPendingTransactions("borrow");
        } catch (err) {
          toast(`Borrow request approved, but the request list could not be refreshed: ${err.message}`);
          renderLibBorrowTabs("borrow");
        }
      } else {
        renderLibBorrowTabs("borrow");
      }
      if (qs("#catalog-table")) renderCatalog();
      if (qs("#cart-table")) renderCart();
      if (qs("#txn-table")) renderTransactionsTable();
      toast("Borrow request approved");
      return;
    }
    const dec = t.closest(".dec");
    if (dec) {
      const i = Number(dec.getAttribute("data-i"));
      const request = state.pendingApprove.splice(i, 1)[0];
      const serverBackedRequest = request?.transactionId && state.authToken;
      if (request?.transactionId && state.authToken) {
        try {
          await postJson(`/transactions/${request.transactionId}/decline`, {});
        } catch (err) {
          state.pendingApprove.splice(i, 0, request);
          toast(`Unable to decline request: ${err.message}`);
          renderLibBorrowTabs("borrow");
          return;
        }
      }
      if (request) {
        addNotification({
          date: "04/16/2026",
          title: "Borrow Request Declined",
          body: `Your request to borrow ${request.book} was declined.`,
          read: false,
        });
      }
      if (serverBackedRequest) {
        try {
          await loadPendingTransactions("borrow");
        } catch (err) {
          toast(`Borrow request declined, but the request list could not be refreshed: ${err.message}`);
          renderLibBorrowTabs("borrow");
        }
      } else {
        renderLibBorrowTabs("borrow");
      }
      if (qs("#catalog-table")) renderCatalog();
      if (qs("#cart-table")) renderCart();
      if (qs("#txn-table")) renderTransactionsTable();
      toast("Borrow request declined");
    }

    const markReturned = t.closest(".mark-returned");
    if (markReturned) {
      const i = Number(markReturned.getAttribute("data-i"));
      const request = state.pendingReturns[i];
      if (!request) return;
      const serverBackedRequest = request?.transactionId && state.authToken;
      let returnResult = null;
      if (serverBackedRequest) {
        try {
          returnResult = await postJson(`/transactions/${request.transactionId}/return`, {});
        } catch (err) {
          toast(`Unable to mark book as returned: ${err.message}`);
          return;
        }
      } else {
        state.pendingReturns.splice(i, 1);
        const borrowedIndex = state.borrowed.findIndex(
          (book) => book.bookId === request.bookId && (!book.user || book.user === request.user),
        );
        if (borrowedIndex >= 0) state.borrowed.splice(borrowedIndex, 1);
        const book = getBook(request.bookId);
        if (book) book.avail += 1;
        addNotification({
          date: currentDateMMDDYYYY(),
          title: "Book Return Confirmed",
          body: `Your return of ${request.book} has been recorded.`,
          read: false,
        });
      }
      if (serverBackedRequest) {
        try {
          await loadPendingTransactions("return");
        } catch (err) {
          toast(`Book marked returned, but the list could not be refreshed: ${err.message}`);
          renderLibBorrowTabs("return");
        }
      } else {
        renderLibBorrowTabs("return");
      }
      if (qs("#txn-table")) renderTransactionsTable();
      if (returnResult?.fineIssued) {
        const amount = Number(returnResult.fineAmount);
        const formattedAmount = Number.isFinite(amount)
          ? amount.toLocaleString("en-PH", { style: "currency", currency: "PHP" })
          : "an outstanding fine";
        toast(`Book returned. ${formattedAmount} remains due before the borrower can request another book or reservation.`);
      } else {
        toast("Book marked as returned.");
      }
      return;
    }

    const sms = t.closest(".sms");
    if (sms) {
      const overdue = state.overdueRows[Number(sms.getAttribute("data-i"))];
      if (!overdue) {
        toast("Unable to send the overdue notice because the borrower record is unavailable.");
        return;
      }
      sms.disabled = true;
      try {
        const result = await postJson("/sms/overdue-notice", {
          phone: overdue.phone,
          userName: overdue.user,
          bookTitle: overdue.book,
          author: overdue.author,
          dueDate: overdue.due,
        });
        toast(result.mock ? "SMS Notification sent (SMS demo mode)." : "Overdue notice sent by SMS.");
      } catch (err) {
        sms.disabled = false;
        toast(`Unable to send overdue notice: ${err.message}`);
      }
      return;
    }

    const readL = t.closest(".btn-read-msg, .btn-reply-msg");
    if (readL) {
      const notification = state.libInbox[Number(readL.getAttribute("data-idx"))];
      const isReply = readL.classList.contains("btn-reply-msg");
      if (notification?.id && state.currentUser?.id) {
        state.libReadNotificationIds.add(notification.id);
        localStorage.setItem(
          `ggc-librarian-read-${state.currentUser.id}`,
          JSON.stringify(Array.from(state.libReadNotificationIds)),
        );
        renderLibInbox();
        renderLibAnnouncements();
        renderLibrarianNotifications();
      }
      if (["Received", "Sent"].includes(notification?.kind) && notification.threadId) {
        await openContactThreadModal(notification.threadId, isReply);
        return;
      }
      if (isReply) {
        toast("Unable to reply because this message is not linked to a conversation.");
        return;
      }
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green lib-notification-detail-modal${notification?.kind === "Announcement" && notification.announcementCreatorRole === "admin" ? " adm-origin-announcement" : ""}">
          <div class="modal-head-pdf modal-head-green">
            <h3>${notification?.kind === "Announcement" ? "Announcement Details" : "Message Details"}</h3>
            <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
          </div>
          <div class="modal-body-pdf">
            <dl class="lib-notification-detail-meta">
              <div><dt>Type</dt><dd>${escapeHtml(notification?.kind || "Notification")}${notification?.source ? ` · ${escapeHtml(notification.source)}` : ""}</dd></div>
              <div><dt>${notification?.kind === "Sent" ? "To" : "From"}</dt><dd>${escapeHtml(notification?.kind === "Sent" ? notification.to || "Library user" : notification?.from || "System")}</dd></div>
              ${notification?.kind === "Announcement" && notification.announcementCreatorRole === "admin"
                ? '<div class="adm-system-announcement-card"><dt>Announcement Type</dt><dd>System Admin Announcement</dd></div>'
                : ""}
              ${notification?.kind === "Announcement" && notification.audience
                ? `<div><dt>Audience</dt><dd>${escapeHtml(notification.audience)}</dd></div>`
                : ""}
              <div><dt>Date</dt><dd>${escapeHtml(notification ? formatNotificationTimestamp({ createdAt: notification.createdAt, date: notification.date }) : "—")}</dd></div>
            </dl>
            <div class="lib-notification-detail-message">
              <span class="lib-notification-detail-label">Message</span>
              <p>${escapeHtml(notification?.excerpt || "Notification details are unavailable.")}</p>
            </div>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-submit-request" data-close-modal>Close</button>
            </div>
          </div>
        </div>
      `);
      return;
    }

    const barcodeButton = t.closest(".lib-inventory-barcode-button");
    if (barcodeButton) {
      const book = BOOKS.find((item) => item.id === barcodeButton.getAttribute("data-book"));
      if (!book) {
        toast("Unable to view barcodes: book is no longer in the catalog.");
        return;
      }
      await openBookBarcodesModal(book);
      return;
    }

    const eb = t.closest(".btn-edit-book");
    if (eb) {
      const book = BOOKS.find((item) => item.id === eb.getAttribute("data-book"));
      if (!book) {
        toast("Unable to edit book: book is no longer in the catalog.");
        return;
      }
      openBookEditModal(book);
      return;
    }

    /* History message */
    const hm = t.closest(".hist-msg");
    if (hm) {
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green lib-message-modal">
          <div class="modal-head-pdf modal-head-green">
            <h3>Message ${escapeHtml(hm.getAttribute("data-user-name") || "User")}</h3>
            <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
          </div>
          <form id="lib-history-message-form" data-user-id="${escapeHtml(hm.getAttribute("data-user-id") || "")}">
            <div class="modal-body-pdf">
              <label for="lib-history-message-input">Message</label>
              <textarea id="lib-history-message-input" name="message" maxlength="500" rows="8" placeholder="Write your message here (maximum of 500 characters)" required></textarea>
              <p class="lib-message-count">Maximum 500 characters</p>
              <div class="modal-foot-pdf">
                <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
                <button type="submit" class="btn-submit-request">Done</button>
              </div>
            </div>
          </form>
        </div>
      `);
      return;
    }

    const hv = t.closest(".hist-view");
    if (hv) {
      const userId = hv.getAttribute("data-user-id");
      const userName = hv.getAttribute("data-user-name") || "User";
      if (!userId) {
        toast("Unable to open user history: user account is missing.");
        return;
      }
      try {
        const rows = await getJson(`/transactions/user/${encodeURIComponent(userId)}`);
        const historyModalClass = rows.length ? "lib-history-modal" : "lib-history-modal lib-history-empty-modal";
        openModal(`
          <div class="modal-sheet-pdf modal-sheet-green ${historyModalClass}">
            <div class="modal-head-pdf modal-head-green">
              <h3>Borrowing History: ${escapeHtml(userName)}</h3>
              <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
            </div>
            <div class="modal-body-pdf">
              ${
                rows.length
                  ? `<div class="table-responsive"><table class="data-table small"><thead><tr><th>BOOK</th><th>AUTHOR</th><th>BORROWED</th><th>DUE</th><th>RETURNED</th><th>STATUS</th></tr></thead><tbody>${rows
                      .map(
                        (row) =>
                          `<tr><td>${escapeHtml(row.title)}</td><td>${escapeHtml(row.author)}</td><td>${escapeHtml(
                            row.borrowDate || "—",
                          )}</td><td>${escapeHtml(row.dueDate || "—")}</td><td>${escapeHtml(
                            row.returnDate || "—",
                          )}</td><td>${escapeHtml(row.status)}</td></tr>`,
                      )
                      .join("")}</tbody></table></div>`
                  : '<p class="muted">No borrowing history found for this user.</p>'
              }
            </div>
          </div>
        `);
      } catch (err) {
        toast(`Unable to load user history: ${err.message}`);
      }
      return;
    }

    if (t.id === "btn-adm-announce") {
      openAnnouncementComposer();
      return;
    }
    const viewAdminAnnouncement = t.closest("[data-view-admin-announcement]");
    if (viewAdminAnnouncement) {
      const announcement = state.adminAnnouncements[Number(viewAdminAnnouncement.getAttribute("data-view-admin-announcement"))];
      if (announcement) {
        markAdminAnnouncementRead(announcement);
        openAdminAnnouncementDetails(announcement);
      }
      return;
    }
    const editAdminAnnouncement = t.closest("[data-edit-admin-announcement]");
    if (editAdminAnnouncement) {
      const announcement = state.adminAnnouncements[Number(editAdminAnnouncement.getAttribute("data-edit-admin-announcement"))];
      if (!announcement?.announcementId) {
        toast("Unable to edit announcement: announcement record is unavailable.");
        return;
      }
      openAnnouncementComposer({
        id: announcement.announcementId,
        title: announcement.title,
        body: announcement.body,
        audience: announcement.audience,
        publicationDate: announcement.publicationDate,
      });
      return;
    }
    if (t.id === "btn-announce") openAnnouncementComposer();
    const editAnnouncement = t.closest(".btn-edit-announcement");
    if (editAnnouncement) {
      const announcement = state.libInbox[Number(editAnnouncement.getAttribute("data-idx"))];
      if (announcement?.announcementId) {
        openAnnouncementComposer({
          id: announcement.announcementId,
          title: announcement.title,
          body: announcement.excerpt,
          audience: announcement.audience,
          publicationDate: announcement.publicationDate,
        });
      }
      return;
    }
    if (t.id === "lib-announcement-publish-confirm") {
      const button = t;
      const announcement = JSON.parse(button.getAttribute("data-announcement") || "{}");
      button.disabled = true;
      try {
        if (announcement.id) {
          await putJson(`/announcements/${announcement.id}`, announcement);
        } else {
          await postJson("/announcements", announcement);
        }
        closeModal();
        if (state.currentUser?.role === "admin") {
          await loadAdminAnnouncements();
        } else {
          await loadLibrarianInbox();
        }
        toast(announcement.id ? "Announcement updated." : "Announcement published.");
      } catch (err) {
        button.disabled = false;
        toast(`Unable to publish announcement: ${err.message}`);
      }
    }
    if (t.id === "lib-announcement-publish-cancel") {
      const announcement = JSON.parse(t.getAttribute("data-announcement") || "{}");
      openAnnouncementComposer(announcement);
    }
  });

  document.addEventListener("submit", async (e) => {
    const form = e.target;
    if (!(form instanceof HTMLFormElement)) return;
    e.preventDefault();
    if (form.id === "contact-thread-reply-form") {
      const threadId = form.getAttribute("data-thread-id");
      const reply = form.elements.reply.value.trim();
      if (!threadId || !reply) return;
      const submit = form.querySelector('button[type="submit"]');
      if (submit) submit.disabled = true;
      try {
        await postJson(`/contact-messages/${encodeURIComponent(threadId)}/reply`, {
          body: reply,
        });
        const isLibrarian = state.currentUser?.role === "librarian";
        closeModal();
        if (isLibrarian) {
          toast("Reply sent to the user.");
          try {
            await loadLibrarianInbox();
          } catch (err) {
            toast(`Reply sent, but the inbox could not be refreshed: ${err.message}`);
          }
        } else {
          toast("Reply sent to the library.");
          try {
            await Promise.all([loadMemberSentMessages(), loadMemberNotifications()]);
            renderMemberNotifications();
          } catch (err) {
            toast(`Reply sent, but the conversation list could not be refreshed: ${err.message}`);
          }
        }
      } catch (err) {
        if (submit) submit.disabled = false;
        toast(`Unable to send reply: ${err.message}`);
      }
      return;
    }
    if (form.id === "lib-announcement-form") {
      const announcement = {
        id: form.getAttribute("data-announcement-id") || "",
        title: form.elements.title.value.trim(),
        body: form.elements.body.value.trim(),
        audience: form.elements.audience.value,
        publicationDate: form.elements.publicationDate.value,
      };
      if (!announcement.title || !announcement.body || !announcement.publicationDate) return;
      const encodedAnnouncement = escapeHtml(JSON.stringify(announcement));
      const isAdmin = state.currentUser?.role === "admin";
      const audienceLabels = {
        everyone: "Everyone",
        students: "Students",
        faculty: "Faculty / Teachers",
        visitors: "Visitors",
      };
      openModal(`
        <div class="modal-sheet-pdf modal-sheet-green ${isAdmin ? "adm-announcement-detail-modal" : "lib-notification-detail-modal"}">
          <div class="modal-head-pdf modal-head-green"><h3>${announcement.id ? "Confirm Announcement Update" : "Confirm Publication"}</h3></div>
          <div class="modal-body-pdf">
            <p>${announcement.id ? "Review the changes before saving this announcement." : "Review the announcement details before publishing."}</p>
            <dl class="${isAdmin ? "adm-announcement-detail-meta" : "lib-notification-detail-meta"}">
              <div><dt>Title</dt><dd>${escapeHtml(announcement.title)}</dd></div>
              <div><dt>Audience</dt><dd>${escapeHtml(audienceLabels[announcement.audience] || announcement.audience)}</dd></div>
              <div><dt>Publication Date</dt><dd>${escapeHtml(announcement.publicationDate)}</dd></div>
            </dl>
            <div class="${isAdmin ? "adm-announcement-detail-message" : "lib-notification-detail-message"}">
              <span${isAdmin ? "" : ' class="lib-notification-detail-label"'}>Message</span>
              <p>${escapeHtml(announcement.body)}</p>
            </div>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" id="lib-announcement-publish-cancel" data-announcement="${encodedAnnouncement}">Cancel</button>
              <button type="button" class="btn-submit-request lib-announcement-confirm-button" id="lib-announcement-publish-confirm" data-announcement="${encodedAnnouncement}">${announcement.id ? "Confirm &amp; Update" : "Confirm &amp; Publish"}</button>
            </div>
          </div>
        </div>
      `);
      return;
    }
    if (form.id !== "lib-history-message-form") return;
    const userId = form.getAttribute("data-user-id");
    const message = form.elements.message.value.trim();
    if (!userId || !message) return;
    const submit = form.querySelector('button[type="submit"]');
    if (submit) submit.disabled = true;
    try {
      await postJson(`/users/${encodeURIComponent(userId)}/notifications`, {
        title: "Message from the Library",
        body: message,
      });
      closeModal();
      toast("Message sent to the user.");
    } catch (err) {
      if (submit) submit.disabled = false;
      toast(`Unable to send message: ${err.message}`);
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    qsa(".member-user-menu.is-open, .staff-user-menu.is-open").forEach((menu) => {
      menu.classList.remove("is-open");
      qs(".member-user-avatar, .staff-user-avatar", menu)?.setAttribute("aria-expanded", "false");
    });
  });

  function getLoginFormField(form, ...names) {
    const candidates = names.flatMap((name) => {
      const direct = form?.elements?.namedItem?.(name);
      if (direct && typeof direct.value === "string") return [direct.value];
      if (form && form[name] && typeof form[name].value === "string") return [form[name].value];
      return [];
    });

    const match = candidates.find((value) => typeof value === "string" && value.trim().length > 0);
    return match ? match.trim() : "";
  }

  function demoLoginResult(role, identifier, password) {
    const config = DEMO_CREDENTIALS[role];
    if (!config) return null;

    const expectedIdentifier = String(config.username || config.name || config.schoolId || "").trim();
    const expectedPassword = String(config.password || "").trim();
    if (!expectedIdentifier || !expectedPassword) return null;

    const providedIdentifier = String(identifier || "").trim().toLowerCase();
    const providedPassword = String(password || "").trim();
    const expectedIdentifierLower = expectedIdentifier.toLowerCase();

    if (role === "member") {
      const matchesName = providedIdentifier === String(config.name || "").trim().toLowerCase();
      if (matchesName && providedPassword === expectedPassword) {
        return {
          token: "demo-member-token",
          user: {
            id: 1,
            role: "member",
            name: config.name,
            schoolId: config.schoolId,
            username: config.name,
            email: `${config.name}@ggc.edu.ph`,
            phone: "+639174444444",
          },
        };
      }

      return null;
    }

    if (providedIdentifier === expectedIdentifierLower && providedPassword === expectedPassword) {
      return {
        token: `demo-${role}-token`,
        user: {
          id: 1,
          role,
          name: expectedIdentifier,
          username: expectedIdentifier,
        },
      };
    }

    return null;
  }

  function resetFreshMemberState() {
    state.cart.clear();
    state.borrowed = [];
    state.notifications = [];
    state.memberTransactions = [];
    state.txn = [];
    state.pendingApprove = [];
    state.pendingReturns = [];
  }

  /** Forms */
  async function completeLogin(result) {
    const role = String(result.user?.role || "").toLowerCase();
    const destination = ROLE_DESTINATIONS[role];
    if (!destination) {
      toast("This account role is not supported for sign-in yet.");
      return;
    }

    closeLoginModal(false);
    state.authToken = result.token;
    state.currentUser = result.user;
    state.currentMemberName = result.user.name || "Member";
    state.currentMemberPhone = result.user.phone || "";
    if (result.user.freshAccount) {
      resetFreshMemberState();
      saveMemberCart();
    } else if (role === "member" || role === "visitor") {
      restoreMemberCart();
    }
    if (!continueAfterLogin(role, destination)) return;

    if (role === "member" || role === "visitor") {
      try {
        await Promise.all([loadMemberTransactions(), loadMemberNotifications()]);
      } catch (err) {
        toast(`Unable to load account activity: ${err.message}`);
      }
    }
    if (role === "librarian" || role === "staff") {
      try {
        await loadPendingTransactions();
      } catch (err) {
        toast(`Unable to load borrowing and return records: ${err.message}`);
      }
    }
    toast(`Signed in as ${state.currentMemberName}`);
  }

  async function submitLogin(ev) {
    ev.preventDefault();
    const form = ev.currentTarget;
    const identifier = getLoginFormField(form, "identifier", "username", "Username", "userName", "name", "email");
    const password = getLoginFormField(form, "password", "Password");
    if (!identifier || !password) {
      toast("Enter your login credentials.");
      return;
    }

    let result;
    try {
      result = await postJson("/auth/login", { identifier, password });
    } catch (err) {
      result = demoLoginResult("member", identifier, password);
      if (!result) {
        toast(err.message || "Unable to sign in.");
        return;
      }
    }
    await completeLogin(result);
  }

  qs("#form-login")?.addEventListener("submit", submitLogin);

  const registerForm = qs("#form-register");
  const registerCourse = qs("#register-course");
  const registerCourseField = qs("#register-course-field");
  const registerUserType = registerForm?.elements.userType;
  const registerSchoolFields = qs("#register-school-fields");
  const registerStudentRow = qs("#register-student-row");
  const registerOrganization = qs("#register-organization");
  const registerOrganizationField = qs("#register-organization-field");
  const registerAccountLabel = qs("#register-account-label");
  const registerNote = qs("#register-note");
  const updateRegistrationCourseVisibility = () => {
    if (!registerCourse || !registerUserType || !registerForm) return;
    const accountType = registerUserType.value.trim().toLowerCase();
    const isVisitor = accountType === "visitor";
    const isFaculty = ["faculty", "teacher"].includes(accountType);
    const schoolId = registerForm.elements.sid;
    registerSchoolFields.hidden = isVisitor;
    schoolId.disabled = isVisitor;
    schoolId.required = !isVisitor;
    registerCourse.hidden = isVisitor || isFaculty;
    registerCourse.disabled = isVisitor || isFaculty;
    registerCourse.required = accountType === "student";
    registerCourseField.hidden = isVisitor || isFaculty;
    registerCourse.closest(".pill-row")?.classList.toggle("is-faculty", isFaculty);
    registerStudentRow?.classList.toggle("is-faculty", isFaculty);
    registerStudentRow?.classList.toggle("is-visitor", isVisitor);
    registerOrganizationField.hidden = !isVisitor;
    registerOrganization.disabled = !isVisitor;
    registerOrganization.required = isVisitor;
    if (registerAccountLabel) registerAccountLabel.textContent = registerUserType.value.toUpperCase() || "ACCOUNT TYPE";
    if (registerNote) {
      registerNote.textContent = isVisitor
        ? "Visitors need a referral letter. A ₱50 fee applies if their school is not an Educational Organization member."
        : "After signing up, wait for approval of your account.";
    }
  };
  registerUserType?.addEventListener("change", updateRegistrationCourseVisibility);
  updateRegistrationCourseVisibility();

  const clearRegistrationErrors = (form) => {
    qsa("input, select", form).forEach((field) => {
      field.setCustomValidity("");
      field.removeAttribute("aria-invalid");
    });
  };
  const updateRegistrationFloatingLabel = (field) => {
    const wrapper = field.closest(".register-field");
    if (!wrapper) return;
    wrapper.classList.toggle(
      "is-floating",
      field === document.activeElement || Boolean(field.value),
    );
  };
  const updateRegistrationPasswordValidation = () => {
    if (!registerForm) return;
    const password = registerForm.elements.password;
    const repeatPassword = registerForm.elements.repeatPassword;
    const matchIndicator = qs("#register-password-match");
    const tooShort = password.value.length > 0 && password.value.length < 8;
    const mismatch = repeatPassword.value.length > 0 && password.value !== repeatPassword.value;

    password.setCustomValidity(tooShort ? "Password must be at least 8 characters." : "");
    if (tooShort) password.setAttribute("aria-invalid", "true");
    else password.removeAttribute("aria-invalid");
    repeatPassword.setCustomValidity(mismatch ? "Passwords do not match." : "");
    if (mismatch) repeatPassword.setAttribute("aria-invalid", "true");
    else repeatPassword.removeAttribute("aria-invalid");
    if (matchIndicator) matchIndicator.hidden = !mismatch;
  };
  registerForm?.addEventListener("click", (event) => {
    const button = event.target.closest(".pw-eye");
    if (!button) return;
    const passwordField = button.closest(".pw-eye-wrap")?.querySelector("input");
    if (!passwordField) return;
    const showPassword = passwordField.type === "password";
    passwordField.type = showPassword ? "text" : "password";
    button.innerHTML = showPassword
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a16 16 0 0 1-3.1 3.8M6.2 6.2C3.6 8 2 12 2 12s3.6 7 10 7a10.7 10.7 0 0 0 4.2-.9"></path></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    button.setAttribute("aria-label", `${showPassword ? "Hide" : "Show"} password`);
    button.setAttribute("aria-pressed", String(showPassword));
  });
  const showRegistrationFieldErrors = (form, err, isVisitor) => {
    const fieldErrors = err.fieldErrors;
    if (!fieldErrors || typeof fieldErrors !== "object") return false;

    const fieldTargets = {
      email: form.email,
      username: form.email,
      phone: form.phone,
      schoolId: isVisitor ? form.organization : form.sid,
    };
    const messagesByField = new Map();
    Object.entries(fieldErrors).forEach(([name, message]) => {
      const field = fieldTargets[name];
      if (!field) return;
      const messages = messagesByField.get(field) || [];
      messages.push(String(message));
      messagesByField.set(field, messages);
    });
    const firstField = messagesByField.keys().next().value;
    messagesByField.forEach((messages, field) => {
      field.setCustomValidity(messages.join(" "));
      field.setAttribute("aria-invalid", "true");
    });
    if (firstField) {
      firstField.focus();
      firstField.reportValidity();
      return true;
    }
    return false;
  };

  registerForm?.addEventListener("input", (ev) => {
    const field = ev.target;
    if (field.name === "phone") {
      field.value = field.value.replace(/\D/g, "").slice(0, 11);
    }
    updateRegistrationFloatingLabel(field);
    field.setCustomValidity("");
    field.removeAttribute("aria-invalid");
    if (field.name === "password" || field.name === "repeatPassword") {
      updateRegistrationPasswordValidation();
    }
  });

  registerForm?.addEventListener("change", (ev) => {
    updateRegistrationFloatingLabel(ev.target);
  });

  registerForm?.addEventListener("focusin", (ev) => {
    updateRegistrationFloatingLabel(ev.target);
  });

  registerForm?.addEventListener("focusout", (ev) => {
    updateRegistrationFloatingLabel(ev.target);
  });

  registerForm?.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const form = ev.currentTarget;
    clearRegistrationErrors(form);
    const accountType = form.userType.value;
    const isVisitor = accountType.toLowerCase() === "visitor";
    const name = form.name.value.trim();
    const rawPhone = form.phone.value;
    if (!/^\d{11}$/.test(rawPhone)) {
      form.phone.setCustomValidity("Enter an 11-digit phone number using numbers only.");
      form.phone.reportValidity();
      return;
    }
    const phone = toE164Phone(rawPhone);
    const schoolId = isVisitor
      ? form.organization.value.trim()
      : form.sid.value.trim().replace(/\s+/g, "").toUpperCase();
    const password = form.password.value;
    const repeatPassword = form.repeatPassword.value;
    updateRegistrationPasswordValidation();

    if (!name || !phone || !schoolId || !password) {
      toast("Please complete all required fields.");
      return;
    }
    if (password.length < 8) {
      form.password.focus();
      form.password.reportValidity();
      return;
    }
    if (password !== repeatPassword) {
      form.repeatPassword.focus();
      form.repeatPassword.reportValidity();
      return;
    }

    const registration = {
      name,
      email: form.email.value.trim().toLowerCase(),
      phone,
      schoolId,
      userType: accountType,
      course: isVisitor || accountType.toLowerCase() === "faculty" ? null : form.course.value,
      role: isVisitor ? "visitor" : "member",
    };
    try {
      await postJson("/auth/register/check", registration);
    } catch (err) {
      if (!showRegistrationFieldErrors(form, err, isVisitor)) {
        toast(`Unable to check account information: ${err.message}`);
      }
      return;
    }

    try {
      const otpRes = await postJson("/sms/send-otp", {
        phone,
        name,
        templateType: "OTP (Account Creation)",
      });
      state.pendingMemberSignup = {
        ...registration,
        password,
      };
      const otpPhoneDemo = document.getElementById("otp-phone-demo");
      if (otpPhoneDemo) otpPhoneDemo.textContent = phone;
      sec = 300;
      closeRegistrationModal(false);
      navigate("otp-signup");
      toast(otpRes.mock && otpRes.devCode ? `DEV OTP: ${otpRes.devCode}` : "OTP sent via SMS.");
    } catch (err) {
      toast(`OTP send failed: ${err.message}`);
      return;
    }
  });

  qs("#otp-signup-submit")?.addEventListener("click", async () => {
    if (state.pendingMemberSignup) {
      const code = (document.getElementById("otp-signup-input")?.value || "").trim();
      if (!code) {
        toast("Please enter the OTP code.");
        return;
      }
      try {
        await postJson("/sms/verify-otp", {
          phone: state.pendingMemberSignup.phone,
          code,
        });
      } catch (err) {
        toast(`OTP verification failed: ${err.message}`);
        return;
      }
      let registrationResult;
      try {
        registrationResult = await postJson("/auth/register", {
          name: state.pendingMemberSignup.name,
          email: state.pendingMemberSignup.email,
          phone: state.pendingMemberSignup.phone,
          schoolId: state.pendingMemberSignup.schoolId,
          userType: state.pendingMemberSignup.userType,
          course: state.pendingMemberSignup.course,
          password: state.pendingMemberSignup.password,
          role: state.pendingMemberSignup.role,
        });
      } catch (err) {
        let hasFieldErrors = false;
        if (err.fieldErrors && typeof err.fieldErrors === "object") {
          navigate("home");
          openRegistrationModal();
          hasFieldErrors = showRegistrationFieldErrors(
            registerForm,
            err,
            state.pendingMemberSignup.role === "visitor",
          );
        }
        if (!hasFieldErrors) {
          toast(`Registration failed: ${err.message}`);
        }
        return;
      }
      const isVisitor = state.pendingMemberSignup.role === "visitor";
      state.currentMemberName = state.pendingMemberSignup.name;
      state.currentMemberPhone = state.pendingMemberSignup.phone;
      state.pendingMemberSignup = null;
      if (isVisitor) {
        if (registrationResult.sms === "failed") {
          toast(`Visitor account created, but the confirmation SMS failed: ${registrationResult.smsError || "Please contact the library."}`);
        } else if (registrationResult.sms === "demo") {
          toast("Visitor account created. Confirmation SMS simulated in demo mode; you can now sign in.");
        } else {
          toast("Visitor account created. Confirmation SMS sent; you can now sign in.");
        }
      } else {
        toast("Account submitted. Wait for administrator approval before signing in.");
      }
    } else {
      toast("Account verified — await librarian approval.");
    }
    navigate("login");
  });

  qs("#otp-signup-resend")?.addEventListener("click", async () => {
   const signup = state.pendingMemberSignup;
   if (!signup) return;

   if (sec > 0) {
     toast("OTP request is currently ongoing. Please wait for the timer to run out.");
     return;
   }

   const resendButton = qs("#otp-signup-resend");
   resendInProgress = true;
   if (resendButton) resendButton.hidden = true;
   try {
     const otpRes = await postJson("/sms/send-otp", {
       phone: signup.phone,
       name: signup.name,
       templateType: "OTP (Account Creation)",
     });
     sec = 300;
     resendInProgress = false;
     if (resendButton) resendButton.hidden = true;
     if (otpRes.mock && otpRes.devCode) {
       toast(`DEV OTP: ${otpRes.devCode}`);
     } else {
       toast("A new OTP was sent via SMS.");
     }
   } catch (err) {
     resendInProgress = false;
     if (resendButton) resendButton.hidden = sec > 0;
     toast(`OTP resend failed: ${err.message}`);
   }
  });

  async function requestPasswordResetOtp(button) {
    const phone = state.passwordResetPhone;
    if (!phone) {
      toast("Enter the contact number linked to your account first.");
      navigate("forgot");
      return;
    }
    if (button) button.disabled = true;
    try {
      const result = await postJson("/auth/password-reset/request", { phone });
      const input = qs("#otp-forgot-input");
      if (input) input.value = "";
      navigate("otp-forgot");
      toast(result.mock && result.devCode
        ? `DEV OTP: ${result.devCode}`
        : "If an active account matches that number, a password reset code has been sent.");
      forgotOtpSeconds = 300;
      if (button) button.disabled = true;
    } catch (err) {
      if (button) button.disabled = false;
      toast(`Unable to request a password reset code: ${err.message}`);
    }
  }

  qs("#form-forgot")?.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const contactNumber = qs("#forgot-contact-number")?.value.trim();
    const otpPhone = qs("#otp-forgot-phone");
    if (otpPhone) otpPhone.textContent = contactNumber;
    state.passwordResetPhone = contactNumber || "";
    state.passwordResetToken = "";
    await requestPasswordResetOtp();
  });

  qs("#otp-forgot-resend")?.addEventListener("click", async (ev) => {
    await requestPasswordResetOtp(ev.currentTarget);
  });

  qs("#otp-forgot-ok")?.addEventListener("click", async () => {
    const code = qs("#otp-forgot-input")?.value.trim();
    if (!state.passwordResetPhone || !code) {
      toast("Enter the password reset code.");
      return;
    }
    const button = qs("#otp-forgot-ok");
    if (button) button.disabled = true;
    try {
      const result = await postJson("/auth/password-reset/verify", {
        phone: state.passwordResetPhone,
        code,
      });
      state.passwordResetToken = result.resetToken;
      navigate("reset-password");
    } catch (err) {
      toast(`Password reset code verification failed: ${err.message}`);
    } finally {
      if (button) button.disabled = false;
    }
  });

  qs("#form-reset")?.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const form = ev.currentTarget;
    const password = form.elements.password.value;
    const confirmPassword = form.elements.confirmPassword.value;
    if (password.length < 8) {
      toast("Password must be at least 8 characters.");
      return;
    }
    if (password !== confirmPassword) {
      toast("Passwords do not match.");
      return;
    }
    if (!state.passwordResetToken) {
      toast("Verify a password reset code before changing your password.");
      navigate("forgot");
      return;
    }
    const button = form.querySelector('button[type="submit"]');
    if (button) button.disabled = true;
    try {
      await postJson("/auth/password-reset", {
        resetToken: state.passwordResetToken,
        password,
        confirmPassword,
      });
      state.passwordResetToken = "";
      state.passwordResetPhone = "";
      form.reset();
      toast("Password updated. You can now sign in with your new password.");
      navigate("login");
    } catch (err) {
      toast(`Unable to update password: ${err.message}`);
    } finally {
      if (button) button.disabled = false;
    }
  });

  qs("#member-contact-form")?.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    if (!state.composedMemberMessage) return;
    const send = qs("#send-member-message");
    if (send) send.disabled = true;
    try {
      await postJson("/contact", {
        reason: state.composedMemberReason,
        message: state.composedMemberMessage,
      });
      toast("Message sent — thank you.");
      state.composedMemberMessage = "";
      state.composedMemberReason = "";
      renderMemberMessagePreview();
      try {
        await loadMemberSentMessages();
        if (state.notificationFilter === "sent") renderMemberNotifications();
      } catch (err) {
        toast(`Message sent, but conversations could not be refreshed: ${err.message}`);
      }
    } catch (err) {
      toast(`Unable to send message: ${err.message}`);
    } finally {
      if (send) send.disabled = false;
    }
  });

  function openMemberComposeModal() {
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green member-compose-modal">
        <div class="modal-head-pdf modal-head-green">
          <h3>Compose A Message</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form id="member-compose-form">
          <div class="modal-body-pdf">
            <label for="member-contact-reason">Contact reason</label>
            <select id="member-contact-reason" required>
              <option value="">Select a reason</option>
              ${["Borrowing concern", "Returning books", "Account or profile issue", "Book availability", "Technical problem", "General inquiry"]
                .map((reason) => `<option value="${reason}"${state.composedMemberReason === reason ? " selected" : ""}>${reason}</option>`)
                .join("")}
            </select>
            <label for="member-compose-input">Message</label>
            <textarea id="member-compose-input" maxlength="500" rows="8" placeholder="Write your message here (maximum of 500 characters)" required>${escapeHtml(state.composedMemberMessage)}</textarea>
            <p class="member-compose-count">Maximum 500 characters</p>
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
              <button type="submit" class="btn-submit-request">Done</button>
            </div>
          </div>
        </form>
      </div>`);
  }

  function openRoleProfileModal(role) {
    const user = state.currentUser;
    if (!user || user.role !== role || !["librarian", "staff"].includes(role)) {
      toast(`${role === "staff" ? "Library Staff" : "Librarian"} profile is unavailable.`);
      return;
    }
    const usernameField = role === "librarian"
      ? `<label for="librarian-profile-username">Username</label>
            <input id="librarian-profile-username" name="username" type="text" maxlength="255" value="${escapeHtml(user.username || "")}" required autocomplete="username" />`
      : "";
    const usernameGuidance = role === "staff"
      ? '<small class="muted">Username is generated from the part of your email before @.</small>'
      : "";
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green">
        <div class="modal-head-pdf modal-head-green">
          <h3>Edit Profile</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <form id="managed-profile-form" data-role="${role}">
          <div class="modal-body-pdf librarian-profile-form">
            <label for="librarian-profile-name">Name</label>
            <input id="librarian-profile-name" name="name" type="text" maxlength="255" value="${escapeHtml(user.name || "")}" required />
            ${usernameField}
            <label for="librarian-profile-email">Email</label>
            <input id="librarian-profile-email" name="email" type="email" maxlength="255" value="${escapeHtml(user.email || "")}" required autocomplete="email" />
            ${usernameGuidance}
            <label for="librarian-profile-current-password">Current password</label>
            <input id="librarian-profile-current-password" name="currentPassword" type="password" autocomplete="current-password" />
            <label for="librarian-profile-new-password">New password <span class="muted">(leave blank to keep current password)</span></label>
            <input id="librarian-profile-new-password" name="newPassword" type="password" autocomplete="new-password" />
            <label for="librarian-profile-confirm-password">Confirm new password</label>
            <input id="librarian-profile-confirm-password" name="confirmPassword" type="password" autocomplete="new-password" />
            <div class="modal-foot-pdf">
              <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
              <button type="submit" class="btn-submit-request">Save Changes</button>
            </div>
          </div>
        </form>
      </div>`);
  }

  qs("#compose-member-message")?.addEventListener("click", openMemberComposeModal);
  qs("#edit-member-message")?.addEventListener("click", openMemberComposeModal);

  document.addEventListener("submit", (ev) => {
    if (ev.target.id !== "member-compose-form") return;
    ev.preventDefault();
    const reason = qs("#member-contact-reason")?.value;
    const message = qs("#member-compose-input")?.value.trim();
    if (!reason || !message) return;
    state.composedMemberReason = reason;
    state.composedMemberMessage = message;
    closeModal();
    renderMemberMessagePreview();
  });

  document.addEventListener("submit", async (ev) => {
    const form = ev.target;
    if (!(form instanceof HTMLFormElement) || form.id !== "managed-profile-form") return;
    ev.preventDefault();
    const role = form.dataset.role;
    const name = form.elements.name.value.trim();
    const username = role === "staff" ? "" : form.elements.username.value.trim();
    const email = form.elements.email.value.trim().toLowerCase();
    const currentPassword = form.elements.currentPassword.value;
    const newPassword = form.elements.newPassword.value;
    const confirmPassword = form.elements.confirmPassword.value;
    if (!name || (!username && role !== "staff") || !email) {
      toast(role === "staff" ? "Name and email are required." : "Name, username, and email are required.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast("Enter a valid email address.");
      return;
    }
    if (newPassword || confirmPassword) {
      if (!currentPassword) {
        toast("Enter your current password to change it.");
        return;
      }
      if (newPassword.length < 8) {
        toast("New password must be at least 8 characters.");
        return;
      }
      if (newPassword !== confirmPassword) {
        toast("New password and confirmation do not match.");
        return;
      }
    }
    const submit = form.querySelector('button[type="submit"]');
    if (submit) submit.disabled = true;
    try {
      const result = await postJson("/auth/profile", {
        name,
        ...(role === "staff" ? {} : { username }),
        email,
        currentPassword: currentPassword || undefined,
        newPassword: newPassword || undefined,
      });
      state.currentUser = result.user;
      state.currentMemberName = result.user.name || name;
      const saved = JSON.parse(sessionStorage.getItem("ggc-library-session") || "null");
      if (saved?.user) {
        saved.user = result.user;
        sessionStorage.setItem("ggc-library-session", JSON.stringify(saved));
      }
      closeModal();
      refreshChrome(state.activeView);
      toast("Profile updated.");
    } catch (err) {
      if (submit) submit.disabled = false;
      toast(`Unable to update profile: ${err.message}`);
    }
  });

  qs("#member-profile-form")?.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const form = ev.target;
    const name = form.elements.name.value.trim();
    const phone = form.elements.phone.value.trim();
    const email = form.elements.email.value.trim().toLowerCase();
    const currentPassword = form.elements.currentPassword.value;
    const newPassword = form.elements.newPassword.value;
    const confirmPassword = form.elements.confirmPassword.value;
    if (!name || !email) {
      toast("Name and email are required.");
      return;
    }
    if (newPassword || confirmPassword || currentPassword) {
      if (!currentPassword) {
        toast("Enter your current password to change it.");
        return;
      }
      if (newPassword.length < 8) {
        toast("New password must be at least 8 characters.");
        return;
      }
      if (newPassword !== confirmPassword) {
        toast("New password and confirmation do not match.");
        return;
      }
    }
    try {
      let updatedUser;
      if (state.authToken && !state.authToken.startsWith("demo-")) {
        const result = await postJson("/auth/profile", {
          name,
          email,
          phone,
          currentPassword: currentPassword || undefined,
          newPassword: newPassword || undefined,
        });
        updatedUser = result.user;
      } else {
        if (newPassword && (state.authToken !== "demo-member-token" || currentPassword !== DEMO_CREDENTIALS.member.password)) {
          toast("Current password is incorrect.");
          return;
        }
        if (newPassword && state.authToken === "demo-member-token") {
          DEMO_CREDENTIALS.member.password = newPassword;
        }
        updatedUser = { ...(state.currentUser || {}), name, email, phone };
      }
      state.currentUser = updatedUser;
      state.currentMemberName = name;
      state.currentMemberPhone = phone;
      const saved = JSON.parse(sessionStorage.getItem("ggc-library-session") || "null");
      if (saved?.user) {
        saved.user = updatedUser;
        sessionStorage.setItem("ggc-library-session", JSON.stringify(saved));
      }
      hydrateMemberProfiles();
      form.elements.currentPassword.value = "";
      form.elements.newPassword.value = "";
      form.elements.confirmPassword.value = "";
      toast("Profile updated.");
    } catch (err) {
      toast(`Unable to update profile: ${err.message}`);
    }
  });

  async function logout() {
    try {
      if (state.authToken) await postJson("/auth/logout", {});
    } catch (err) {
      toast(`Logout warning: ${err.message}`);
    } finally {
      qsa("#form-login").forEach((form) => {
        form.reset();
        qsa("input", form).forEach((input) => {
          input.value = "";
          input.removeAttribute("value");
        });
      });
      state.authToken = "";
      state.currentUser = null;
      state.currentMemberName = "";
      state.currentMemberPhone = "";
      state.cart.clear();
      sessionStorage.removeItem("ggc-library-session");
      if (standaloneEntryView()) {
        window.location.href = "index.html";
        return;
      }
      navigate("home");
      toast("Logged out");
    }
  }

  qs("#confirm-member-logout")?.addEventListener("click", logout);
  qs("#confirm-lib-logout")?.addEventListener("click", logout);
  qs("#confirm-staff-logout")?.addEventListener("click", logout);
  qs("#confirm-adm-logout")?.addEventListener("click", logout);

  qs("#catalog-search")?.addEventListener("input", renderCatalog);

  qsa("[data-catalog-category]").forEach((button) => {
    button.addEventListener("click", () => {
      state.catalogCategory = button.getAttribute("data-catalog-category") || "All Books";
      qsa("[data-catalog-category]").forEach((item) => {
        const active = item === button;
        item.classList.toggle("active", active);
        item.setAttribute("aria-pressed", String(active));
      });
      if (button.classList.contains("member-category-card")) {
        navigate("member-catalog", { preserveCatalogCategory: true });
      }
      renderCatalog();
    });
  });

  qs("#lib-inv-search")?.addEventListener("input", renderLibInventory);

  qs("#save-lib-borrowing-duration")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    const select = qs("#lib-borrowing-duration");
    const facultySelect = qs("#lib-faculty-borrowing-duration");
    const walkInMinimumSelect = qs("#lib-reservation-walk-in-minimum");
    const holdDaysInput = qs("#lib-reservation-hold-days");
    const penaltyCostInput = qs("#lib-penalty-cost-per-day");
    const status = qs("#lib-borrowing-duration-status");
    const duration = Number(select?.value);
    const facultyDuration = Number(facultySelect?.value);
    const reservationWalkInMinimumCopies = Number(walkInMinimumSelect?.value);
    const reservationHoldDays = Number(holdDaysInput?.value);
    const penaltyCostPerDay = Number(penaltyCostInput?.value);
    if (![duration, facultyDuration].every((value) => Number.isSafeInteger(value) && value > 0) ||
      ![1, 2, 3].includes(reservationWalkInMinimumCopies) ||
      !Number.isSafeInteger(reservationHoldDays) || reservationHoldDays < 1 || reservationHoldDays > 30 ||
      !Number.isFinite(penaltyCostPerDay) || penaltyCostPerDay < 0 || penaltyCostPerDay > 1000000 ||
      Math.round(penaltyCostPerDay * 100) !== penaltyCostPerDay * 100) {
      toast("Choose valid returning durations, a walk-in minimum of 1, 2, or 3 copies, a reservation hold period of 1 to 30 days, and a daily penalty cost from ₱0 to ₱1,000,000 with up to two decimal places.");
      return;
    }
    button.disabled = true;
    try {
      const policy = await postJson("/library-policy", {
        borrowingDurationDays: duration,
        facultyBorrowingDurationDays: facultyDuration,
        reservationWalkInMinimumCopies,
        reservationHoldDays,
        penaltyCostPerDay,
      });
      state.libraryPolicyDuration = Number(policy.borrowingDurationDays);
      state.facultyLibraryPolicyDuration = Number(policy.facultyBorrowingDurationDays);
      state.reservationWalkInMinimumCopies = Number(policy.reservationWalkInMinimumCopies);
      state.reservationHoldDays = Number(policy.reservationHoldDays);
      state.penaltyCostPerDay = Number(policy.penaltyCostPerDay);
      if (status) {
        status.textContent = `Student and Visitor returns are due in ${duration} days; Faculty and Teachers returns are due in ${facultyDuration} days. Reservations leave at least ${reservationWalkInMinimumCopies} available ${reservationWalkInMinimumCopies === 1 ? "copy" : "copies"} for walk-in borrowers; ordinary borrowing may use those copies. Late returns incur ₱${penaltyCostPerDay.toFixed(2)} per overdue day.`;
      }
      toast("Library policies saved.");
    } catch (err) {
      toast(`Unable to save borrowing policy: ${err.message}`);
    } finally {
      button.disabled = false;
    }
  });

  qsa('[data-btab]').forEach((btn) =>
    btn.addEventListener('click', () => {
      qsa('[data-btab]').forEach((b)=>b.classList.remove('active'));
      btn.classList.add('active');
      const activeTab = btn.getAttribute('data-btab');
      renderLibBorrowTabs(activeTab);
      if (activeTab === "fines") {
        loadOutstandingFines().catch((err) => toast(`Unable to load outstanding fines: ${err.message}`));
      }
    }),
  );

  qsa("[data-lib-borrow-search]").forEach((input) => {
    input.addEventListener("input", () => filterLibBorrowTable(input));
  });

  /* initial borrowing tab activation */
  const firstBtab = qs('[data-btab="borrow"]');
  firstBtab?.classList.add('active');

  qsa('[data-usersub]').forEach((btn) =>
    btn.addEventListener('click', async ()=> {
      qsa('[data-usersub]').forEach((b)=>b.classList.remove('active'));
      btn.classList.add('active');
      const status = btn.getAttribute('data-usersub') === 'confirm' ? 'pending' : 'all';
      try {
        await loadAdminUsers(status);
      } catch (err) {
        toast(`Unable to load user accounts: ${err.message}`);
      }
    }),
  );

  qsa("[data-directory-filter]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.adminDirectoryFilter = btn.getAttribute("data-directory-filter") || "all";
      qsa("[data-directory-filter]").forEach((tab) => {
        const isActive = tab === btn;
        tab.classList.toggle("active", isActive);
        tab.setAttribute("aria-pressed", String(isActive));
      });
      renderAdminDirectory();
    });
  });

  qsa("[data-directory-create]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const filter = btn.getAttribute("data-directory-create");
      if (!["librarian", "staff"].includes(filter)) return;
      state.adminDirectoryFilter = filter;
      qsa("[data-directory-filter]").forEach((tab) => {
        const isActive = tab.getAttribute("data-directory-filter") === filter;
        tab.classList.toggle("active", isActive);
        tab.setAttribute("aria-pressed", String(isActive));
      });
      renderAdminDirectory();
      openCreateManagedAccountModal();
    });
  });

  qs("#adm-activity-filter")?.addEventListener("change", (event) => {
    state.adminActivityFilter = event.currentTarget.value || "all";
    loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
  });

  qs("#adm-activity-date-range")?.addEventListener("change", (event) => {
    state.adminActivityDateRange = event.currentTarget.value || "all";
    const customDates = qs("#adm-activity-custom-dates");
    if (customDates) customDates.hidden = state.adminActivityDateRange !== "custom";
    loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
  });

  ["#adm-activity-date-from", "#adm-activity-date-to"].forEach((selector) => {
    qs(selector)?.addEventListener("change", (event) => {
      if (selector === "#adm-activity-date-from") state.adminActivityDateFrom = event.currentTarget.value;
      else state.adminActivityDateTo = event.currentTarget.value;
      if (state.adminActivityDateRange === "custom") {
        loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
      }
    });
  });

  qs("#adm-activity-action")?.addEventListener("change", (event) => {
    state.adminActivityAction = event.currentTarget.value || "all";
    loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
  });

  let activitySearchTimer;
  qs("#adm-activity-search")?.addEventListener("input", (event) => {
    state.adminActivitySearch = event.currentTarget.value;
    clearTimeout(activitySearchTimer);
    activitySearchTimer = setTimeout(() => {
      loadActivityLog().catch((err) => toast(`Unable to load user activity logs: ${err.message}`));
    }, 250);
  });

  qs("#adm-catalog-search")?.addEventListener("input", (event) => {
    state.adminCatalogSearch = event.currentTarget.value;
    renderAdmCatalog();
  });

  qsa("button[data-catalog-sort]").forEach((button) => {
    button.addEventListener("click", () => {
      const sort = button.getAttribute("data-catalog-sort");
      if (!["title", "author", "isbn", "available", "borrowed", "total"].includes(sort)) return;
      if (state.adminCatalogSort === sort) {
        state.adminCatalogSortDirection = state.adminCatalogSortDirection === "asc" ? "desc" : "asc";
      } else {
        state.adminCatalogSort = sort;
        state.adminCatalogSortDirection = "asc";
      }
      renderAdmCatalog();
    });
  });

  qs("#adm-directory-search")?.addEventListener("input", (event) => {
    state.adminDirectorySearch = event.currentTarget.value;
    renderAdminDirectory();
  });


  function validateLibrarianField(form, fieldName, markTouched = false) {
    const field = qs(`[name="${fieldName}"]`, form);
    if (!field) return true;
    const error = qs(`#${field.id}-error`, form);
    if (!error) return true;
    if (markTouched) field.dataset.touched = "true";
    if (field.dataset.touched !== "true") return true;

    let message = "";
    const value = field.value.trim();
    if (field.required && !value) {
      message = "This field is required.";
    } else if (fieldName === "email" && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      message = "Enter a valid email address.";
    } else if (fieldName === "password" && field.value.length < 8) {
      message = "Password must be at least 8 characters.";
    } else if (
      fieldName === "confirmPassword" &&
      field.value !== qs('[name="password"]', form)?.value
    ) {
      message = "Passwords do not match.";
    }

    error.textContent = message;
    field.setAttribute("aria-invalid", String(Boolean(message)));
    return !message;
  }

  document.addEventListener("focusout", (event) => {
    const field = event.target;
    const form = field.form;
    if (form?.id !== "adm-create-librarian-modal-form" || !field.name) return;
    validateLibrarianField(form, field.name, true);
    if (field.name === "password" || field.name === "confirmPassword") {
      validateLibrarianField(form, "confirmPassword", field.name === "confirmPassword");
    }
  });

  document.addEventListener("input", (event) => {
    const field = event.target;
    const form = field.form;
    if (form?.id !== "adm-create-librarian-modal-form" || !field.name) return;
    const formError = qs("#adm-create-librarian-form-error", form);
    if (formError) formError.textContent = "";
    validateLibrarianField(form, field.name);
    if (field.name === "password" || field.name === "confirmPassword") {
      validateLibrarianField(form, "confirmPassword");
    }
  });

  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-password-toggle]");
    if (!button || !els.modalBody.contains(button)) return;
    const passwordField = qs(`#${button.getAttribute("data-password-toggle")}`, els.modalBody);
    if (!passwordField) return;
    const showPassword = passwordField.type === "password";
    passwordField.type = showPassword ? "text" : "password";
    button.innerHTML = showPassword
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.9 5.2A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a16 16 0 0 1-3.1 3.8M6.2 6.2C3.6 8 2 12 2 12s3.6 7 10 7a10.7 10.7 0 0 0 4.2-.9"></path></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    button.setAttribute("aria-label", `${showPassword ? "Hide" : "Show"} password`);
    button.setAttribute("aria-pressed", String(showPassword));
  });

  document.addEventListener("submit", async (event) => {
    const form = event.target;
    if (form.id !== "adm-create-librarian-modal-form") return;
    const role = form.dataset.role;
    if (!["librarian", "staff"].includes(role)) return;
    event.preventDefault();

    const fields = [
      ...(role === "librarian" ? ["username"] : []),
      "schoolId",
      "name",
      "email",
      "password",
      "confirmPassword",
    ];
    const isValid = fields
      .map((fieldName) => validateLibrarianField(form, fieldName, true))
      .every(Boolean);
    if (!isValid) {
      qs('[aria-invalid="true"]', form)?.focus();
      return;
    }

    const schoolId = qs('[name="schoolId"]', form).value.trim();
    const name = qs('[name="name"]', form).value.trim();
    const email = qs('[name="email"]', form).value.trim().toLowerCase();
    const password = qs('[name="password"]', form).value;
    const confirmPassword = qs('[name="confirmPassword"]', form).value;

    const submitButton = qs('button[type="submit"]', form);
    if (submitButton) submitButton.disabled = true;
    try {
      await postJson(role === "staff" ? "/staff" : "/librarians", {
        ...(role === "librarian" ? { username: qs('[name="username"]', form).value.trim() } : {}),
        schoolId,
        name,
        email,
        password,
        confirmPassword,
      });
      closeModal();
      const roleLabel = role === "librarian" ? "Librarian" : "Library Staff";
      toast(`${roleLabel} account created.`);
      try {
        await loadAdminDirectory();
      } catch (err) {
        toast(`${roleLabel} account was created, but the directory could not be refreshed: ${err.message}`);
      }
    } catch (err) {
      const formError = qs("#adm-create-librarian-form-error", form);
      const fieldErrors = err.fieldErrors;
      if (fieldErrors && typeof fieldErrors === "object") {
        if (formError) formError.textContent = "";
        Object.entries(fieldErrors).forEach(([fieldName, message]) => {
          const field = qs(`[name="${fieldName}"]`, form);
          const error = field && qs(`#${field.id}-error`, form);
          if (!field || !error) return;
          field.dataset.touched = "true";
          field.setAttribute("aria-invalid", "true");
          error.textContent = message;
        });
        const firstDuplicate = Object.keys(fieldErrors)[0];
        if (firstDuplicate) qs(`[name="${firstDuplicate}"]`, form)?.focus();
      } else if (formError) {
        const roleLabel = role === "librarian" ? "librarian" : "Library Staff";
        formError.textContent = err.message || `Unable to create ${roleLabel} account.`;
      }
      if (submitButton) submitButton.disabled = false;
    }
  });

  qs("#sms-type")?.addEventListener("change", async (event) => {
    const templateType = event.currentTarget.value;
    try {
      await loadAdminSmsTemplate(templateType);
    } catch (err) {
      toast(`Unable to load the notification template: ${err.message}`);
    }
  });

  qs("#btn-save-sms")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    const typeSelect = qs("#sms-type");
    const bodyInput = qs("#sms-body");
    if (!typeSelect || !bodyInput) return;
    if (!bodyInput.value.trim()) {
      toast("Enter a message before saving the template.");
      bodyInput.focus();
      return;
    }

    button.disabled = true;
    typeSelect.disabled = true;
    bodyInput.disabled = true;
    try {
      await putJson("/sms-templates", {
        templateType: typeSelect.value,
        body: bodyInput.value,
      });
      toast("Notification template saved. Active SMS workflows will use the updated content.");
    } catch (err) {
      toast(`Unable to save the notification template: ${err.message}`);
    } finally {
      button.disabled = false;
      typeSelect.disabled = false;
      bodyInput.disabled = false;
    }
  });

  ["adm", "lib"].forEach((prefix) => {
    qs(`#${prefix}-report-type`)?.addEventListener("change", () => {
      loadReportPreview(prefix).catch((err) => renderReportPreviewError(err.message, prefix));
    });

    qs(`#${prefix}-report-period`)?.addEventListener("change", () => {
      loadReportPreview(prefix).catch((err) => renderReportPreviewError(err.message, prefix));
    });

    if (prefix === "adm") {
      qs("#adm-report-user-type")?.addEventListener("change", () => {
        loadReportPreview(prefix).catch((err) => renderReportPreviewError(err.message, prefix));
      });
      qs("#adm-report-course")?.addEventListener("change", () => {
        loadReportPreview(prefix).catch((err) => renderReportPreviewError(err.message, prefix));
      });
      qs("#adm-report-account-status")?.addEventListener("change", () => {
        loadReportPreview(prefix).catch((err) => renderReportPreviewError(err.message, prefix));
      });
    }

    qs(`#${prefix}-reports-download`)?.addEventListener("click", (event) => {
      const button = event.currentTarget;
      button.disabled = true;
      try {
        downloadReportPdf(prefix);
      } catch (err) {
        toast(`Unable to download report: ${err.message}`);
      } finally {
        button.disabled = !qs(`#${prefix}-report-preview .adm-report-table`);
      }
    });
  });

  qs('#btn-add-book-open')?.addEventListener('click', ()=> {
    openModal(`
      <div class="modal-sheet-pdf modal-sheet-green">
        <div class="modal-head-pdf modal-head-green">
          <h3>Add Book</h3>
          <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
        </div>
        <div class="modal-body-pdf">
          <div class="stack-form" autocomplete="off">
            <label>Book title<input id="nb-title" name="new-book-title" type="text" autocomplete="off"/></label>
            <label>Book author<input id="nb-author" name="new-book-author" type="text" autocomplete="off"/></label>
            <label>ISBN<input id="nb-isbn" name="new-book-isbn" type="text" inputmode="numeric" minlength="10" maxlength="17" placeholder="978-..." autocomplete="off" required /></label>
            <label>Number of copies<input id="nb-avail" name="new-book-available" type="number" min="1" max="5000" value="1" autocomplete="off" required /></label>
          </div>
          <p class="small muted">A unique barcode will be generated for each physical copy. You can review the codes after adding the book.</p>
          <div class="modal-foot-pdf">
            <button type="button" class="btn-cancel-soft" data-close-modal>Cancel</button>
            <button type="button" class="btn-submit-request" id="modal-add-save">Add Book</button>
          </div>
        </div>
      </div>
    `);
    qs('#modal-add-save', els.modalBody)?.addEventListener('click', async () => {
      const title = qs("#nb-title", els.modalBody)?.value.trim();
      const author = qs("#nb-author", els.modalBody)?.value.trim();
      const isbn = qs("#nb-isbn", els.modalBody)?.value.trim();
      const availableValue = qs("#nb-avail", els.modalBody)?.value.trim();
      const available = Number(availableValue);

      if (!title || !author || !isbn || availableValue === "" || !Number.isInteger(available) || available < 1 || available > 5000) {
        toast("Enter a title, author, ISBN, and a copy count between 1 and 5,000.");
        return;
      }

      try {
        const result = await postJson("/books", { title, author, isbn, total: available, available });
        if (!Array.isArray(result.barcodes) || result.barcodes.length !== available) {
          throw new Error("Book was added, but the server did not return all generated copy barcodes.");
        }
        let refreshError = "";
        try {
          await loadBooks();
        } catch (err) {
          refreshError = err.message;
        }
        openModal(`
          <div class="modal-sheet-pdf modal-sheet-green">
            <div class="modal-head-pdf modal-head-green">
              <h3>Book Added — Copy Barcodes</h3>
              <button type="button" class="modal-close-pdf" data-close-modal aria-label="Close">×</button>
            </div>
            <div class="modal-body-pdf">
              <p>${escapeHtml(title)} was added with ${available} individually identified ${available === 1 ? "copy" : "copies"}.</p>
              <label for="new-book-copy-barcodes">Generated barcodes</label>
              <textarea id="new-book-copy-barcodes" class="lib-book-barcodes" rows="6" readonly>${escapeHtml(result.barcodes.join("\n"))}</textarea>
              <p class="small muted">These unique identifiers are not the book's ISBN. Barcode label rendering and scanning will be added with the circulation workflow.</p>
              ${refreshError ? `<p class="modal-message-green" role="alert">The book was saved, but the catalog could not refresh: ${escapeHtml(refreshError)}</p>` : ""}
              <div class="modal-foot-pdf"><button type="button" class="btn-submit-request" data-close-modal>Done</button></div>
            </div>
          </div>
        `);
      } catch (err) {
        toast(`Unable to add book: ${err.message}`);
      }
    });
  });

  /* OTP countdown (signup view) */
  let sec = 300;
  let forgotOtpSeconds = 0;
  let resendInProgress = false;
  function signupTimerTick() {
    const el = document.getElementById('timer-signup');
    if (el) {
     const m = String(Math.floor(sec / 60)).padStart(2,'0');
     const s = String(sec % 60).padStart(2,'0');
     el.textContent = `${m}:${s}`;
     const resendButton = document.getElementById("otp-signup-resend");
     if (resendButton) {
       resendButton.hidden = sec > 0 || resendInProgress;
       resendButton.disabled = false;
     }
     if (sec > 0) sec--;
    }
    const forgotTimer = document.getElementById("otp-forgot-timer");
    if (forgotTimer) {
     const minutes = String(Math.floor(forgotOtpSeconds / 60)).padStart(2, "0");
     const seconds = String(forgotOtpSeconds % 60).padStart(2, "0");
     forgotTimer.textContent = `${minutes}:${seconds}`;
     const resendButton = document.getElementById("otp-forgot-resend");
     if (resendButton) resendButton.disabled = forgotOtpSeconds > 0;
     if (forgotOtpSeconds > 0) forgotOtpSeconds--;
    }
  }
  setInterval(signupTimerTick, 1000);
  signupTimerTick();

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) return;
    if (state.activeView === "adm-dashboard") refreshAdminDashboardStats();
  });

  loadBooks().catch((err) => {
    // The hard-coded catalog remains available when the optional API is offline.
    console.warn("Unable to load books from the library server; using the demo catalog.", err);
    renderHomeCatalog();
  });
  showView(standaloneEntryView() || "home");
})();
