OPTIONAL COPY-LEVEL RECONCILIATION

This audit is deferred for the planned reservation flow, which will use
aggregate available-copy counts and allow reservations only when copies are
available. Completing this barcode-to-loan mapping is not a prerequisite for
that flow.

Use copy-loan-reconciliation-template.csv only if the library later needs to
associate individual barcode records with physical books and active loans.
Complete one row per physical copy, plus one row for each catalog copy that
cannot be located.

Before starting:
1. Confirm the database backup is valid and keep the original unchanged.
2. Export or record the current book copy barcodes and active transactions.
3. Work title by title. Use the exact Book ID, ISBN, and GGC barcode from the
   librarian inventory/edit screens. A barcode identifies a copy, not a title.
4. Until printed barcode labels are available, match the GGC code to each book
   using a temporary, clearly removable label. Do not guess or assign the same
   code to more than one physical copy.

For each row:
- Database Copy State: Active, Retired, or Unregistered.
- Physical Finding: On Shelf, On Loan, Missing, Damaged, or Other. For a
  catalog copy that cannot be found, use Missing and explain in Notes.
- If the copy is on loan, check the physical borrower against the system and
  enter the corresponding System Transaction ID and System Borrower ID.
- Verification Result: Match, No Match, No Active Transaction, or Needs
  Follow-up. Use Needs Follow-up for uncertain identities or discrepancies.
- Leave Barcode blank only for a physical copy that has no registered barcode.
  Give that row Database Copy State "Unregistered" and note the book it belongs
  to. Do not invent a GGC barcode.
- Enter dates as YYYY-MM-DD. Do not include borrower names or contact details;
  use the system borrower ID only.

If this optional audit is performed, do not change book stock, transaction
statuses, or copy records while auditing. Keep unresolved or conflicting rows
marked Needs Follow-up. Reconcile those with library staff before treating
copy-level circulation data as authoritative.
