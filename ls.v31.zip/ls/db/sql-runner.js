const mysql = require('mysql2');

function fail(message) {
  console.error(JSON.stringify({ error: message }));
  process.exit(1);
}

const args = process.argv.slice(2);
if (args.length < 3) {
  fail('Missing required DB runner arguments.');
}

let config;
let sql;
let values;
const operation = args[3] || 'query';

try {
  config = JSON.parse(Buffer.from(args[0], 'base64').toString('utf8'));
  sql = Buffer.from(args[1], 'base64').toString('utf8');
  values = JSON.parse(Buffer.from(args[2], 'base64').toString('utf8'));
} catch (err) {
  fail(err && err.message ? err.message : 'Failed to decode runner arguments.');
}

const conn = mysql.createConnection(config);

conn.connect((connectErr) => {
  if (connectErr) {
    fail(connectErr.message || 'Database connection failed.');
  }

  if (operation === 'transaction') {
    let steps;
    try {
      steps = JSON.parse(sql);
      if (!Array.isArray(steps) || steps.length === 0) throw new Error('Transaction steps are required.');
    } catch (err) {
      conn.end(() => fail(err.message || 'Invalid transaction request.'));
      return;
    }

    conn.beginTransaction((beginErr) => {
      if (beginErr) {
        conn.end(() => fail(beginErr.message || 'Failed to begin database transaction.'));
        return;
      }

      const results = [];
      const runStep = (index) => {
        if (index >= steps.length) {
          conn.commit((commitErr) => {
            if (commitErr) {
              conn.rollback(() => conn.end(() => fail(commitErr.message || 'Failed to commit database transaction.')));
              return;
            }
            console.log(JSON.stringify({
              rows: results.map((result) => ({
                insertId: result.insertId || 0,
                affectedRows: result.affectedRows || 0,
              })),
            }));
            conn.end(() => process.exit(0));
            return;
          });
          return;
        }

        const step = steps[index];
        if (!step || typeof step.sql !== 'string' || !Array.isArray(step.values || [])) {
          conn.rollback(() => conn.end(() => fail(`Invalid transaction step at index ${index}.`)));
          return;
        }
        const stepValues = [];
        for (const value of step.values || []) {
          if (value && typeof value === 'object' && Number.isInteger(value.__lastInsertIdOf)) {
            if (value.__lastInsertIdOf < 0 || value.__lastInsertIdOf >= results.length) {
              conn.rollback(() => conn.end(() => fail(`Transaction step ${index} references an unavailable insert result.`)));
              return;
            }
            stepValues.push(results[value.__lastInsertIdOf].insertId);
          } else {
            stepValues.push(value);
          }
        }
        conn.execute(step.sql, stepValues, (stepErr, result) => {
          if (stepErr) {
            conn.rollback(() => conn.end(() => fail(stepErr.message || `Transaction step ${index} failed.`)));
            return;
          }
          if (Number.isInteger(step.expectAffectedRows) && result.affectedRows !== step.expectAffectedRows) {
            conn.rollback(() => conn.end(() => fail(
              `Expected ${step.expectAffectedRows} affected row(s) at transaction step ${index}, received ${result.affectedRows}.`,
            )));
            return;
          }
          results.push(result);
          runStep(index + 1);
        });
      };

      runStep(0);
    });
    return;
  }

  if (operation !== 'query') {
    conn.end(() => fail(`Unsupported database operation: ${operation}`));
    return;
  }

  const isSelect = /^\s*(SELECT|SHOW|DESCRIBE|EXPLAIN|WITH)\b/i.test(sql);

  const handleResult = (err, result) => {
    if (err) {
      conn.end(() => fail(err.message || 'Database query failed.'));
      return;
    }

    if (isSelect) {
      console.log(JSON.stringify({ rows: Array.isArray(result) ? result : [] }));
    } else {
      console.log(
        JSON.stringify({
          rows: {
            insertId: result && result.insertId !== undefined ? result.insertId : 0,
            affectedRows: result && result.affectedRows !== undefined ? result.affectedRows : 0,
          },
        }),
      );
    }

    conn.end(() => process.exit(0));
  };

  if (isSelect) {
    conn.query(sql, Array.isArray(values) ? values : [], handleResult);
    return;
  }

  conn.execute(sql, Array.isArray(values) ? values : [], handleResult);
});
